"""Reference solution, Lecture 5: quadrupoles, opening criteria, Ewald sum. Uses the L04 tree."""
import sys
from pathlib import Path

import numpy as np

sys.path.append(str(Path(__file__).resolve().parent.parent / "L04"))
from tree import build_tree, Node  # noqa: E402,F401


def compute_quadrupoles(root, pos, mass):
    """Set node.quad = sum_j m_j s_j s_j^T (s_j = r_j - node.com) for every node."""
    dim = pos.shape[1]

    def rec(node):
        if node.children is None:
            s = pos[node.indices] - node.com
            node.quad = (mass[node.indices, None, None] * s[:, :, None] * s[:, None, :]).sum(axis=0)
            return
        q = np.zeros((dim, dim))
        for c in node.children:
            rec(c)
            delta = c.com - node.com
            q += c.quad + c.mass * np.outer(delta, delta)     # parallel-axis theorem
        node.quad = q

    rec(root)


def quad_acceleration(dvec, M, I, G=1.0, eps=0.0):
    """Acceleration from a group: mass M, second-moment tensor I, dvec = COM - particle position."""
    D2 = dvec @ dvec + eps**2
    Id = I @ dvec
    a = M * dvec / D2**1.5
    a += -0.5 * (3 * np.trace(I) * dvec + 6 * Id) / D2**2.5 + 7.5 * (dvec @ Id) * dvec / D2**3.5
    return G * a


def accept_geometric(node, dd, theta):
    return (2 * node.half) ** 2 < theta**2 * dd


def accept_offset(node, dd, theta):
    if theta <= 0:
        return False                                          # theta = 0: never accept
    delta = np.linalg.norm(node.com - node.center)
    return np.sqrt(dd) > 2 * node.half / theta + delta


def accept_relative(node, dd, alpha, a_old, G=1.0):
    return G * node.mass * (2 * node.half) ** 2 <= alpha * a_old * dd**2


def tree_acceleration_multipole(pos, mass, G=1.0, eps=0.0, theta=0.5, criterion="geometric",
                                alpha=0.005, acc_old=None, use_quad=True, root=None, stats=None):
    pos = np.asarray(pos, dtype=float)
    if root is None:
        root = build_tree(pos, mass)
    if use_quad and root.quad is None:
        compute_quadrupoles(root, pos, mass)
    a_mag = None if acc_old is None else np.linalg.norm(acc_old, axis=1)
    if criterion == "relative" and a_mag is None:
        criterion = "geometric"                               # first step: no previous acceleration
    N = len(mass)
    acc = np.zeros_like(pos)
    eps2 = eps**2
    count = 0
    for i in range(N):
        p = pos[i]
        a = np.zeros(pos.shape[1])
        stack = [root]
        while stack:
            node = stack.pop()
            if node.children is None:
                for j in node.indices:
                    if j != i:
                        d = pos[j] - p
                        a += mass[j] * d / (d @ d + eps2) ** 1.5
                        count += 1
                continue
            d = node.com - p
            dd = d @ d
            inside = np.all(np.abs(p - node.center) <= node.half)
            if inside:
                ok = False
            elif criterion == "geometric":
                ok = accept_geometric(node, dd, theta)
            elif criterion == "offset":
                ok = accept_offset(node, dd, theta)
            else:
                ok = accept_relative(node, dd, alpha, a_mag[i], G)
            if ok:
                a += (quad_acceleration(d, node.mass, node.quad, 1.0, eps) if use_quad
                      else node.mass * d / (dd + eps2) ** 1.5)
                count += 1
            else:
                stack.extend(node.children)
        acc[i] = G * a
    if stats is not None:
        stats["interactions"] = stats.get("interactions", 0) + count
    return acc


# ---------------- Ewald summation (cubic box of side L, unit source at the origin) ----------------
def _erfc(x):
    from math import erfc
    return np.vectorize(erfc)(x)


def ewald_potential(r, L=1.0, alpha=None, n_real=2, n_k=5):
    """Potential per unit G*m of a point mass in a periodic cube plus uniform background: phi(r).

    Newtonian limit: phi -> 1/r (potential energy is -G m phi).
    """
    alpha = 2.0 / L if alpha is None else alpha
    r = np.asarray(r, dtype=float)
    rng = np.arange(-n_real, n_real + 1)
    nx = np.array(np.meshgrid(rng, rng, rng, indexing="ij")).reshape(3, -1).T * L
    u = np.linalg.norm(r[None, :] + nx, axis=1)
    real = np.sum(_erfc(alpha * u) / u)
    km = np.arange(-n_k, n_k + 1)
    m = np.array(np.meshgrid(km, km, km, indexing="ij")).reshape(3, -1).T
    m = m[np.any(m != 0, axis=1)]
    m2 = (m**2).sum(axis=1)
    recip = np.sum(np.exp(-np.pi**2 * m2 / (alpha * L) ** 2) / m2 * np.cos(2 * np.pi * (m @ r) / L)) / (np.pi * L)
    return real + recip - np.pi / (alpha**2 * L**3)


def ewald_acceleration(r, L=1.0, alpha=None, n_real=2, n_k=5):
    """Acceleration per unit G*m: a = grad(phi). Newtonian limit -r/|r|^3."""
    alpha = 2.0 / L if alpha is None else alpha
    r = np.asarray(r, dtype=float)
    rng = np.arange(-n_real, n_real + 1)
    nx = np.array(np.meshgrid(rng, rng, rng, indexing="ij")).reshape(3, -1).T * L
    w = r[None, :] + nx
    u = np.linalg.norm(w, axis=1)
    fr = _erfc(alpha * u) / u**3 + 2 * alpha / np.sqrt(np.pi) * np.exp(-((alpha * u) ** 2)) / u**2
    a = -np.sum(fr[:, None] * w, axis=0)
    km = np.arange(-n_k, n_k + 1)
    m = np.array(np.meshgrid(km, km, km, indexing="ij")).reshape(3, -1).T
    m = m[np.any(m != 0, axis=1)]
    m2 = (m**2).sum(axis=1)
    c = np.exp(-np.pi**2 * m2 / (alpha * L) ** 2) / m2 * np.sin(2 * np.pi * (m @ r) / L)
    a += -(2.0 / L**2) * np.sum(c[:, None] * m, axis=0)
    return a
