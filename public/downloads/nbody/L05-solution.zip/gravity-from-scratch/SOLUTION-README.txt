Gravity from Scratch -- reference solution
===========================================

This is the reference implementation for this lecture's homework. Open it only
after your own attempt passes the checker in the hints zip -- that comparison is
most of the point of the exercise. Later lectures build on your own code, not on
this file, so copying it in place of your own work will make later checkers fail
in confusing ways.
