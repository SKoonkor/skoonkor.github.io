"""Reference solution, Lecture 3."""
import numpy as np


def _softened_r2(pos, eps):
    d = pos[None, :, :] - pos[:, None, :]             # d[i, j] = r_j - r_i, shape (N, N, 3)
    r2 = (d**2).sum(axis=2) + eps**2
    return d, r2


def acceleration_np(pos, mass, G=1.0, eps=0.0):
    d, r2 = _softened_r2(pos, eps)
    np.fill_diagonal(r2, 1.0)                          # avoid 0/0 on the diagonal
    w = mass[None, :] / r2**1.5
    np.fill_diagonal(w, 0.0)                           # no self-force
    return G * (w[:, :, None] * d).sum(axis=1)


def kinetic_energy_np(vel, mass):
    return 0.5 * np.sum(mass * (vel**2).sum(axis=1))


def potential_energy_np(pos, mass, G=1.0, eps=0.0):
    _, r2 = _softened_r2(pos, eps)
    np.fill_diagonal(r2, 1.0)
    inv_r = 1.0 / np.sqrt(r2)
    np.fill_diagonal(inv_r, 0.0)
    return -0.5 * G * np.sum(mass[:, None] * mass[None, :] * inv_r)


def total_energy_np(pos, vel, mass, G=1.0, eps=0.0):
    return kinetic_energy_np(vel, mass) + potential_energy_np(pos, mass, G, eps)


def acceleration_chunked(pos, mass, G=1.0, eps=0.0, chunk=100):
    N = len(mass)
    acc = np.zeros((N, 3))
    for i0 in range(0, N, chunk):
        i1 = min(i0 + chunk, N)
        d = pos[None, :, :] - pos[i0:i1, None, :]      # (chunk, N, 3)
        r2 = (d**2).sum(axis=2) + eps**2
        rows = np.arange(i1 - i0)
        r2[rows, rows + i0] = 1.0
        w = mass[None, :] / r2**1.5
        w[rows, rows + i0] = 0.0
        acc[i0:i1] = G * (w[:, :, None] * d).sum(axis=1)
    return acc


def _random_directions(rng, n):
    cost = rng.uniform(-1, 1, n)
    phi = rng.uniform(0, 2 * np.pi, n)
    sint = np.sqrt(1 - cost**2)
    return np.stack([sint * np.cos(phi), sint * np.sin(phi), cost], axis=1)


def plummer_sphere(N, a=1.0, seed=None, G=1.0, M=1.0):
    rng = np.random.default_rng(seed)
    u = rng.uniform(1e-12, 1.0, N)
    r = a / np.sqrt(u ** (-2 / 3) - 1)                  # invert M(<r)/M = r^3 / (r^2 + a^2)^(3/2)
    pos = r[:, None] * _random_directions(rng, N)
    q = np.empty(0)
    while len(q) < N:                                   # rejection sampling of q = v / v_esc
        x = rng.random(N)
        y = 0.1 * rng.random(N)
        q = np.concatenate([q, x[y < x**2 * (1 - x**2) ** 3.5]])
    q = q[:N]
    v_esc = np.sqrt(2 * G * M) * (r**2 + a**2) ** (-0.25)
    vel = (q * v_esc)[:, None] * _random_directions(rng, N)
    mass = np.full(N, M / N)
    pos = pos - np.average(pos, axis=0, weights=mass)
    vel = vel - np.average(vel, axis=0, weights=mass)
    return pos, vel, mass


def uniform_sphere(N, R=1.0, seed=None, M=1.0):
    rng = np.random.default_rng(seed)
    r = R * rng.random(N) ** (1 / 3)
    pos = r[:, None] * _random_directions(rng, N)
    return pos, np.zeros((N, 3)), np.full(N, M / N)


def lagrangian_radii(pos, mass, fractions=(0.1, 0.25, 0.5, 0.75, 0.9)):
    com = np.average(pos, axis=0, weights=mass)
    r = np.linalg.norm(pos - com, axis=1)
    order = np.argsort(r)
    cum = np.cumsum(mass[order]) / mass.sum()
    return np.array([r[order][np.searchsorted(cum, f)] for f in fractions])


def evolve_kdk(pos, vel, mass, dt, n_steps, G=1.0, eps=0.0, force=acceleration_np):
    pos, vel = pos.copy(), vel.copy()
    acc = force(pos, mass, G, eps)
    for _ in range(n_steps):
        vel = vel + 0.5 * dt * acc
        pos = pos + dt * vel
        acc = force(pos, mass, G, eps)
        vel = vel + 0.5 * dt * acc
    return pos, vel
