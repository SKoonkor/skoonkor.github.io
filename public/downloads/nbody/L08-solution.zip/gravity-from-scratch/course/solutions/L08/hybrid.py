"""Reference solution, Lecture 8: P3M and TreePM force splitting in a periodic box.

Force split (Gaussian, as in GADGET-2): the mesh gets exp(-k^2 rs^2) times the Poisson kernel,
the particle-particle / tree part gets the complementary short-range force
    F_short(r) = G m / r^2 * S(r),  S(r) = erfc(r / 2rs) + r / (rs sqrt(pi)) exp(-r^2 / 4rs^2),
which is negligible beyond rcut ~ 4.5 rs.
"""
import math
import sys
from pathlib import Path

import numpy as np

_here = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_here / "L06"))
sys.path.insert(0, str(_here / "L04"))
sys.path.insert(0, str(_here / "L07"))
import pm  # noqa: E402
import tree as T  # noqa: E402

_erfc = np.frompyfunc(math.erfc, 1, 1)


def erfc(x):
    return np.asarray(_erfc(np.asarray(x, dtype=float)), dtype=float)


# ---------------- 8.1 the split ----------------
def short_range_factor(r, rs):
    """S(r): fraction of the Newtonian force left to the short-range part."""
    r = np.asarray(r, dtype=float)
    x = r / (2.0 * rs)
    return erfc(x) + r / (rs * math.sqrt(math.pi)) * np.exp(-x * x)


def gaussian_smooth(field, box, rs):
    """Multiply the Fourier transform of a periodic field by exp(-k^2 rs^2)."""
    n = field.shape[0]
    k1 = 2 * np.pi * np.fft.fftfreq(n, d=box / n)
    kx, ky, kz = np.meshgrid(k1, k1, k1, indexing="ij")
    return np.fft.ifftn(np.fft.fftn(field) * np.exp(-(kx**2 + ky**2 + kz**2) * rs * rs)).real


def cell_window(ngrid, box, scheme):
    """Fourier transform of the assignment kernel (one factor per axis, sinc^p(k h / 2)), as an (n,n,n) array."""
    h = box / ngrid
    k1 = 2 * np.pi * np.fft.fftfreq(ngrid, d=h)
    p = {"ngp": 1, "cic": 2, "tsc": 3}[scheme]
    w1 = np.sinc(k1 * h / (2 * np.pi)) ** p
    return w1[:, None, None] * w1[None, :, None] * w1[None, None, :]


def long_range_acceleration(pos, mass, G, box, ngrid, rs, scheme="tsc", deriv="fd4", deconvolve=True):
    """Mesh part: density -> exp(-k^2 rs^2) / W^2 (Gaussian split, window deconvolved for assign + interpolate)
    -> ordinary PM potential and force."""
    rho = pm.assign_density(pos, mass, ngrid, box, scheme)
    k1 = 2 * np.pi * np.fft.fftfreq(ngrid, d=box / ngrid)
    kx, ky, kz = np.meshgrid(k1, k1, k1, indexing="ij")
    filt = np.exp(-(kx**2 + ky**2 + kz**2) * rs * rs)
    if deconvolve:
        filt = filt / cell_window(ngrid, box, scheme) ** 2
    rho_f = np.fft.ifftn(np.fft.fftn(rho) * filt).real
    phi = pm.solve_potential(rho_f, box, G, "spectral")
    return pm.interpolate(pm.grid_force(phi, box, deriv), pos, box, scheme)


# ---------------- 8.2 short-range particle-particle sum (chaining mesh) ----------------
def find_pairs(pos, box, rcut):
    """All pairs (i < j) closer than rcut (periodic minimum image). -> i, j, d = x_j - x_i (min image)."""
    N = len(pos)
    nc = max(1, min(int(box / rcut), int(round(N ** (1 / 3))) + 1))
    cs = box / nc
    c = np.floor((pos % box) / cs).astype(int) % nc
    flat = (c[:, 0] * nc + c[:, 1]) * nc + c[:, 2]
    order = np.argsort(flat, kind="stable")
    fs = flat[order]
    cells = np.arange(nc**3)
    start = np.searchsorted(fs, cells)
    cnt = np.searchsorted(fs, cells, side="right") - start
    cx, cy, cz = cells // (nc * nc), (cells // nc) % nc, cells % nc
    seen = set()
    I, J = [], []
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for dz in (-1, 0, 1):
                nb = (((cx + dx) % nc) * nc + (cy + dy) % nc) * nc + (cz + dz) % nc
                n1, n2 = cnt, cnt[nb]
                npair = n1 * n2
                tot = int(npair.sum())
                if tot == 0:
                    continue
                cell_of = np.repeat(cells, npair)
                local = np.arange(tot) - np.repeat(np.cumsum(npair) - npair, npair)
                n2r = np.maximum(n2[cell_of], 1)
                a = order[start[cell_of] + local // n2r]
                b = order[start[nb[cell_of]] + local % n2r]
                keep = a < b
                a, b = a[keep], b[keep]
                d = pos[b] - pos[a]
                d -= box * np.rint(d / box)
                m = (d * d).sum(axis=1) < rcut * rcut
                I.append(a[m]); J.append(b[m])   # noqa: E702
    if not I:
        return np.zeros(0, int), np.zeros(0, int), np.zeros((0, 3))
    I, J = np.concatenate(I), np.concatenate(J)
    # with nc < 3 the same pair can arrive through several neighbour offsets: keep each pair once
    key = I * N + J
    _, u = np.unique(key, return_index=True)
    I, J = I[u], J[u]
    d = pos[J] - pos[I]
    d -= box * np.rint(d / box)
    return I, J, d


def short_range_pp(pos, mass, G, eps, box, rs, rcut):
    """Softened, split-weighted pair sum over all pairs closer than rcut."""
    I, J, d = find_pairs(pos, box, rcut)
    r2 = (d * d).sum(axis=1)
    r = np.sqrt(r2)
    w = short_range_factor(r, rs) / (r2 + eps * eps) ** 1.5
    f = G * w[:, None] * d
    acc = np.zeros_like(pos)
    for k in range(3):
        acc[:, k] += np.bincount(I, weights=f[:, k] * mass[J], minlength=len(pos))
        acc[:, k] -= np.bincount(J, weights=f[:, k] * mass[I], minlength=len(pos))
    return acc


def p3m_acceleration(pos, mass, G=1.0, eps=0.0, box=1.0, ngrid=32, rs=None, rcut=None, scheme="tsc", deriv="fd4"):
    h = box / ngrid
    rs = 1.25 * h if rs is None else rs
    rcut = 4.5 * rs if rcut is None else rcut
    pos = np.asarray(pos, dtype=float) % box
    return long_range_acceleration(pos, mass, G, box, ngrid, rs, scheme, deriv) + short_range_pp(pos, mass, G, eps, box, rs, rcut)


# ---------------- 8.3 TreePM: the short-range part from a tree ----------------
def tree_short_range(pos, mass, G, eps, box, rs, rcut, theta=0.5, root=None, stats=None):
    pos = np.asarray(pos, dtype=float)
    if root is None:
        root = T.build_tree(pos, mass)
    N = len(mass)
    acc = np.zeros_like(pos)
    eps2, rc2, th2 = eps * eps, rcut * rcut, theta * theta
    count = 0
    for i in range(N):
        p = pos[i]
        a = np.zeros(3)
        stack = [root]
        while stack:
            node = stack.pop()
            big = node.half * 4 >= box                      # cell larger than box/2: minimum image unreliable
            dc = node.center - p
            dc -= box * np.rint(dc / box)
            if not big:
                gap = np.maximum(np.abs(dc) - node.half, 0.0)
                if (gap * gap).sum() > rc2:                   # whole cell beyond the cutoff
                    continue
            if node.children is None:
                for j in node.indices:
                    if j != i:
                        d = pos[j] - p
                        d -= box * np.rint(d / box)
                        r2 = d @ d
                        if r2 < rc2:
                            a += mass[j] * short_range_factor(math.sqrt(r2), rs) * d / (r2 + eps2) ** 1.5
                        count += 1
                continue
            d = node.com - p
            d -= box * np.rint(d / box)
            dd = d @ d
            inside = np.all(np.abs(dc) <= node.half) if not big else True
            if not inside and T.accept(node, dd, theta):
                if dd < rc2:
                    a += node.mass * short_range_factor(math.sqrt(dd), rs) * d / (dd + eps2) ** 1.5
                count += 1
            else:
                stack.extend(node.children)
        acc[i] = G * a
    if stats is not None:
        stats["interactions"] = stats.get("interactions", 0) + count
    return acc


def treepm_acceleration(pos, mass, G=1.0, eps=0.0, box=1.0, ngrid=32, theta=0.5, rs=None, rcut=None,
                        scheme="tsc", deriv="fd4", stats=None):
    h = box / ngrid
    rs = 1.25 * h if rs is None else rs
    rcut = 4.5 * rs if rcut is None else rcut
    pos = np.asarray(pos, dtype=float) % box
    return (long_range_acceleration(pos, mass, G, box, ngrid, rs, scheme, deriv)
            + tree_short_range(pos, mass, G, eps, box, rs, rcut, theta, stats=stats))


# ---------------- 8.6 comoving evolution with a hybrid force ----------------
def evolve_hybrid(pos, mom, a_start, a_end, nsteps, box, ngrid, Om=0.3, OL=0.7, method="p3m", theta=0.5, eps=0.0):
    """KDK in ln a as in Lecture 7, but with the P3M or TreePM force. Uses your Lecture 7 kick/drift factors."""
    import cosmo as C
    N = len(pos)
    G = 3 * Om * C.H0**2 * box**3 / (8 * np.pi * N)
    m = np.ones(N)

    def acc(p):
        if method == "p3m":
            return p3m_acceleration(p, m, G, eps, box, ngrid)
        return treepm_acceleration(p, m, G, eps, box, ngrid, theta)

    ae = np.geomspace(a_start, a_end, nsteps + 1)
    pos, mom = pos.copy(), mom.copy()
    for a0, a1 in zip(ae[:-1], ae[1:]):
        am = np.sqrt(a0 * a1)
        mom += acc(pos) * C.kick_factor(a0, am, Om, OL)
        pos = (pos + mom * C.drift_factor(a0, a1, Om, OL)) % box
        mom += acc(pos) * C.kick_factor(am, a1, Om, OL)
    return pos, mom
