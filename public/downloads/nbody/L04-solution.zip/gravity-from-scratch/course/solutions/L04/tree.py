"""Reference solution, Lecture 4: Barnes-Hut tree (quadtree in 2D, octree in 3D)."""
import numpy as np


class Node:
    __slots__ = ("center", "half", "mass", "com", "children", "indices", "quad")

    def __init__(self, center, half):
        self.center = center      # (dim,) centre of the cubic cell
        self.half = half          # half the side length
        self.mass = 0.0
        self.com = None           # centre of mass
        self.children = None      # list of child nodes, or None for a leaf
        self.indices = None       # particle indices held by a leaf
        self.quad = None          # quadrupole moment (used from Lecture 5)


def build_tree(pos, mass, leaf_size=1, max_depth=40):
    pos = np.asarray(pos, dtype=float)
    dim = pos.shape[1]
    lo, hi = pos.min(axis=0), pos.max(axis=0)
    center = 0.5 * (lo + hi)
    half = 0.5 * (hi - lo).max() * (1 + 1e-9) + 1e-12
    weights = 1 << np.arange(dim)                       # 1, 2, 4: bit k set if x_k > centre_k
    signs = np.array([[1.0 if (c >> k) & 1 else -1.0 for k in range(dim)] for c in range(2**dim)])

    def build(indices, center, half, depth):
        node = Node(center, half)
        m = mass[indices]
        node.mass = m.sum()
        node.com = (m[:, None] * pos[indices]).sum(axis=0) / node.mass
        if len(indices) <= leaf_size or depth >= max_depth:
            node.indices = indices
            return node
        which = ((pos[indices] > center) @ weights).astype(int)
        node.children = []
        for c in range(2**dim):
            sub = indices[which == c]
            if len(sub):
                node.children.append(build(sub, center + 0.5 * half * signs[c], 0.5 * half, depth + 1))
        return node

    return build(np.arange(len(mass)), center, half, 0)


def accept(node, dd, theta):
    """May this cell be used as a point mass? dd = squared distance to its centre of mass."""
    return (2 * node.half) ** 2 < theta**2 * dd


def tree_acceleration(pos, mass, G=1.0, eps=0.0, theta=0.5, root=None, stats=None):
    pos = np.asarray(pos, dtype=float)
    if root is None:
        root = build_tree(pos, mass)
    N = len(mass)
    acc = np.zeros_like(pos)
    eps2 = eps**2
    theta2 = theta**2
    count = 0
    for i in range(N):
        p = pos[i]
        a = np.zeros(pos.shape[1])
        stack = [root]
        while stack:
            node = stack.pop()
            if node.children is None:                     # leaf: direct sum over its particles
                for j in node.indices:
                    if j != i:
                        d = pos[j] - p
                        a += mass[j] * d / (d @ d + eps2) ** 1.5
                        count += 1
                continue
            d = node.com - p
            dd = d @ d
            inside = np.all(np.abs(p - node.center) <= node.half)
            if not inside and accept(node, dd, theta):        # far enough: use the monopole
                a += node.mass * d / (dd + eps2) ** 1.5
                count += 1
            else:
                stack.extend(node.children)
        acc[i] = G * a
    if stats is not None:
        stats["interactions"] = stats.get("interactions", 0) + count
    return acc
