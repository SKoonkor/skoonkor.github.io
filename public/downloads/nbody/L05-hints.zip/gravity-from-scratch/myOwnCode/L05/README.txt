Copy course/codeHints/L05/hw5_multipole_skeleton.py here and rename it to match the module
the checker imports (see that file's own docstring for the exact name).
If codeHints/L05 has a *_run_experiments.py file, copy that here too, next to
your own code, before running it.
