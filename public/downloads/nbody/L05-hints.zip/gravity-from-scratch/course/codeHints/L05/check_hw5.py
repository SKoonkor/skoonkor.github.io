"""Checker for HW5. Run from the project folder:

    python course/codeHints/L05/check_hw5.py [--l03 DIR] [--l04 DIR] [--l05 DIR]

Defaults: myOwnCode/L03, myOwnCode/L04, myOwnCode/L05.
"""
import argparse
import sys
from pathlib import Path

import numpy as np

root_dir = Path(__file__).resolve().parents[3]
ap = argparse.ArgumentParser()
for name in ("l03", "l04", "l05"):
    ap.add_argument(f"--{name}", default=str(root_dir / "myOwnCode" / name.upper()))
args = ap.parse_args()
for d in (args.l03, args.l04, args.l05):
    sys.path.insert(0, d)
sys.setrecursionlimit(5000)

results, optional_results = [], []


def check(name, fn, optional=False):
    try:
        ok, msg = fn()
    except NotImplementedError:
        ok, msg = False, "not implemented yet"
    except Exception as e:  # noqa: BLE001
        ok, msg = False, f"{type(e).__name__}: {e}"
    (optional_results if optional else results).append(ok)
    tag = "PASS" if ok else ("SKIP" if optional and "not implemented" in msg else "FAIL")
    print(f"{tag}  {name}{' (optional)' if optional else ''}" + ("" if ok else f"   <- {msg}"))


try:
    import multipole as MP
except ImportError as e:
    sys.exit(f"Cannot import multipole.py from {args.l05}: {e}")
try:
    import tree as T4
    import vectorised as V
except ImportError as e:
    sys.exit(f"Cannot import your Lecture 3/4 code: {e}")


def walk(node):
    yield node
    if node.children is not None:
        for c in node.children:
            yield from walk(c)


def subtree(node):
    if node.children is None:
        return list(node.indices)
    out = []
    for c in node.children:
        out += subtree(c)
    return out


def plummer(N, seed):
    """Test cluster generated here (not with your sampler): Plummer positions by inverse transform."""
    rng = np.random.default_rng(seed)
    u = rng.uniform(1e-9, 1.0, N)
    r = 1.0 / np.sqrt(u ** (-2 / 3) - 1)
    c = rng.uniform(-1, 1, N)
    ph = rng.uniform(0, 2 * np.pi, N)
    st = np.sqrt(1 - c**2)
    return r[:, None] * np.stack([st * np.cos(ph), st * np.sin(ph), c], axis=1), np.full(N, 1.0 / N)


def errors(a, ref):
    e = np.linalg.norm(a - ref, axis=1) / np.linalg.norm(ref, axis=1)
    return np.median(e), np.percentile(e, 99), e.max()


# a fixed far-field test group
_rng = np.random.default_rng(0)
GX = _rng.normal(0, 0.2, (6, 3))
GM = _rng.random(6) + 0.5
GM_TOT = GM.sum()
GCOM = (GM[:, None] * GX).sum(axis=0) / GM_TOT
_s = GX - GCOM
GI = (GM[:, None, None] * _s[:, :, None] * _s[:, None, :]).sum(axis=0)
U = np.array([1, 0.3, -0.5]) / np.linalg.norm([1, 0.3, -0.5])


def group_direct(p, eps):
    d = GX - p
    return (GM[:, None] * d / ((d**2).sum(axis=1) + eps**2)[:, None] ** 1.5).sum(axis=0)


def group_errors(dist, eps=0.0):
    p = GCOM + U * dist
    dv = GCOM - p
    a_dir = group_direct(p, eps)
    a_mono = GM_TOT * dv / (dv @ dv + eps**2) ** 1.5
    a_quad = np.asarray(MP.quad_acceleration(dv, GM_TOT, GI, 1.0, eps))
    return np.linalg.norm(a_mono - a_dir), np.linalg.norm(a_quad - a_dir), np.linalg.norm(a_dir)


# ---------------- 5.1 quadrupoles in the tree ----------------
def t_quadrupoles():
    rng = np.random.default_rng(1)
    for dim in (2, 3):
        pos = rng.random((100, dim))
        m = rng.random(100) + 0.5
        for ls in (1, 4):
            root = T4.build_tree(pos, m, leaf_size=ls)
            MP.compute_quadrupoles(root, pos, m)
            bad = _bad_quad(root, pos, m)
            if bad:
                return False, f"dim={dim}, leaf_size={ls}: a node has the wrong second-moment tensor (leaf sum or parallel-axis step)"
    return True, ""


def _bad_quad(root, pos, m):
    if True:
        for n in walk(root):
            ids = subtree(n)
            s = pos[ids] - n.com
            exp = (m[ids, None, None] * s[:, :, None] * s[:, None, :]).sum(axis=0)
            if n.quad is None or not np.allclose(n.quad, exp, atol=1e-12):
                return True
    return False


# ---------------- 5.2 quadrupole force of one group ----------------
def t_quad_far():
    mono, quad, _ = group_errors(4.0)
    return quad < mono / 4, f"d=4: monopole error {mono:.1e}, with quadrupole {quad:.1e} (expect about 1.7e-3 and 2.5e-4)"


def t_quad_scaling():
    e = [group_errors(d) for d in (4.0, 8.0, 16.0)]
    f_mono = e[0][0] / e[1][0]
    f_quad = e[0][1] / e[1][1]
    ok = 12 < f_mono < 22 and 22 < f_quad < 45
    return ok, (f"error factor per doubling of the distance: monopole {f_mono:.1f} (expect ~16 = d^-4), "
                f"with quadrupole {f_quad:.1f} (expect ~32 = d^-5)")


def t_quad_soft():
    mono, quad, _ = group_errors(3.0, eps=0.3)
    return quad < mono / 5, f"eps=0.3, d=3: monopole error {mono:.1e}, with quadrupole {quad:.1e}: softening must enter through D^2 = d^2 + eps^2 everywhere"


def t_quad_basic():
    dv = np.array([2.0, 1.0, -0.5])
    a0 = np.asarray(MP.quad_acceleration(dv, 3.0, np.zeros((3, 3)), 1.0, 0.1))
    mono = 3.0 * dv / (dv @ dv + 0.01) ** 1.5
    a2 = np.asarray(MP.quad_acceleration(dv, 3.0, GI, 2.0, 0.1))
    a1 = np.asarray(MP.quad_acceleration(dv, 3.0, GI, 1.0, 0.1))
    return bool(np.allclose(a0, mono) and np.allclose(a2, 2 * a1)), "with I=0 the result is the monopole; the result scales with G"


# ---------------- 5.3 criteria (unit tests) ----------------
def _node(com, center=(0.0, 0.0, 0.0), half=0.5, mass=2.0):
    n = T4.Node(np.array(center, dtype=float), half)
    n.com = np.array(com, dtype=float)
    n.mass = mass
    return n


def t_accept_geometric():
    n = _node([0, 0, 0])
    return bool(MP.accept_geometric(n, 4.0, 0.6)) and not MP.accept_geometric(n, 4.0, 0.4), "side s=1, d=2: s/d = 0.5 < 0.6 is True, < 0.4 is False"


def t_accept_offset():
    n = _node([1.3, 1.0, 1.0], center=(1.0, 1.0, 1.0))      # COM offset 0.3 from the cell centre
    yes = MP.accept_offset(n, 2.5**2, 0.5)                  # d=2.5 > 1/0.5 + 0.3
    no = MP.accept_offset(n, 2.2**2, 0.5)                   # d=2.2 < 2.3 (geometric would accept: 1/2.2 = 0.45 < 0.5)
    return bool(yes) and not no and not MP.accept_offset(n, 25.0, 0.0), "offset: accept only if d > s/theta + delta (s=1, delta=0.3, theta=0.5: threshold 2.3)"


def t_accept_relative():
    n = _node([0, 0, 0], mass=2.0)
    yes = MP.accept_relative(n, 16.0, 0.005, 2.0, 1.0)     # 2*1 = 2 <= 0.005*2*256 = 2.56
    no = MP.accept_relative(n, 16.0, 0.005, 1.0, 1.0)      # 2 <= 1.28 false
    g2 = MP.accept_relative(n, 16.0, 0.005, 2.0, 2.0)      # G=2: 4 <= 2.56 false
    return bool(yes) and not no and not g2, "relative: accept if G M s^2 <= alpha |a_old| d^4 (M=2, s=1, d=4)"


# ---------------- 5.4 the tree with quadrupoles ----------------
NP = 400


def setup():
    p, m = plummer(NP, 41)
    eps = 0.05
    ref = np.asarray(V.acceleration_np(p, m, 1.0, eps))
    root = T4.build_tree(p, m)
    return p, m, eps, ref, root


_cache = {}


def get():
    if not _cache:
        _cache["s"] = setup()
    return _cache["s"]


def run(**kw):
    p, m, eps, ref, root = get()
    st = {}
    a = MP.tree_acceleration_multipole(p, m, 1.0, eps, root=root, stats=st, **kw)
    return a, st.get("interactions", 0) / len(m)


def t_theta0():
    p, m = plummer(150, 42)
    ref = np.asarray(V.acceleration_np(p, m, 1.5, 0.05))
    for crit in ("geometric", "offset"):
        a = MP.tree_acceleration_multipole(p, m, 1.5, 0.05, 0.0, crit, use_quad=True)
        e = np.abs(a - ref).max() / np.abs(ref).max()
        if e > 1e-10:
            return False, f"theta=0 ({crit}, quadrupoles on) must reproduce direct summation: relative difference {e:.1e}"
    return True, ""


def t_monopole_same_as_l04():
    p, m = plummer(150, 43)
    a1 = MP.tree_acceleration_multipole(p, m, 1.0, 0.05, 0.6, "geometric", use_quad=False)
    a2 = T4.tree_acceleration(p, m, 1.0, 0.05, 0.6)
    e = np.abs(a1 - a2).max() / np.abs(a2).max()
    return e < 1e-10, f"use_quad=False with the geometric criterion must equal your Lecture 4 walk: difference {e:.1e}"


def t_quad_accuracy():
    _, _, _, ref, _ = get()
    am, im = run(theta=0.5, use_quad=False)
    aq, iq = run(theta=0.5, use_quad=True)
    em, eq = errors(am, ref), errors(aq, ref)
    ok = abs(im - iq) < 1e-9 and eq[0] < em[0] / 2.5 and eq[1] < em[1] / 2.2
    return ok, (f"theta=0.5: interactions {im:.0f} vs {iq:.0f} (must be equal); median error {em[0]:.1e} -> {eq[0]:.1e} "
                f"(expect ~3e-3 -> 8e-4), 99th percentile {em[1]:.1e} -> {eq[1]:.1e} (expect ~2e-2 -> 3e-3)")


def t_quad_theta():
    _, _, _, ref, _ = get()
    e = [errors(run(theta=t, use_quad=True)[0], ref)[0] for t in (0.3, 0.5, 0.8)]
    slope = np.log(e[1] / e[0]) / np.log(0.5 / 0.3)
    return e[0] < e[1] < e[2] and slope > 3.0, f"median errors {e[0]:.1e} {e[1]:.1e} {e[2]:.1e} at theta 0.3/0.5/0.8; local slope {slope:.1f} (expect ~4: error ~ theta^4)"


def t_offset():
    _, _, _, ref, _ = get()
    ag, ig = run(theta=0.5, criterion="geometric")
    ao, io = run(theta=0.5, criterion="offset")
    eg, eo = errors(ag, ref), errors(ao, ref)
    return io > ig and eo[2] < 1.15 * eg[2], f"offset opens more cells (interactions {io:.0f} vs {ig:.0f}) and its maximum error must not be worse than the geometric criterion's ({eo[2]:.1e} vs {eg[2]:.1e})"


def t_relative():
    p, m, eps, ref, root = get()
    a0, _ = run(theta=0.5, use_quad=False)
    res = []
    for al in (0.02, 0.005, 0.001):
        a, i = run(criterion="relative", alpha=al, acc_old=a0, use_quad=True)
        res.append((i, errors(a, ref)))
    inc = res[0][0] < res[1][0] < res[2][0]
    dec = res[0][1][2] > res[1][1][2] > res[2][1][2]
    ok = inc and dec and res[1][1][1] < 4e-2 and 100 < res[1][0] < 500
    return ok, (f"alpha 0.02/0.005/0.001: interactions {res[0][0]:.0f}/{res[1][0]:.0f}/{res[2][0]:.0f} (must increase), "
                f"maximum errors {res[0][1][2]:.1e}/{res[1][1][2]:.1e}/{res[2][1][2]:.1e} (must decrease); 99th percentile at 0.005: {res[1][1][1]:.1e} (expect 2e-3 to 2e-2)")


def t_relative_fallback():
    p, m = plummer(60, 44)
    a = MP.tree_acceleration_multipole(p, m, 1.0, 0.05, 0.5, "relative", acc_old=None)
    b = MP.tree_acceleration_multipole(p, m, 1.0, 0.05, 0.5, "geometric")
    return bool(np.allclose(a, b)), "criterion='relative' without acc_old must fall back to the geometric criterion (same result as criterion='geometric' with the same theta)"


def t_contains_still():
    rng = np.random.default_rng(45)
    p = rng.random((50, 3))
    m = np.ones(50)
    root = T4.build_tree(p, m, leaf_size=1)
    expected = 0
    for i in range(50):
        node = root
        while node.children is not None:
            expected += len(node.children) - 1
            node = next(c for c in node.children if i in subtree(c))
        expected += len(node.indices) - 1
    st = {}
    MP.tree_acceleration_multipole(p, m, 1.0, 0.0, 1e3, "geometric", root=root, stats=st)
    return st.get("interactions") == expected, f"a cell containing the particle must still be opened (theta=1000): expected {expected} interactions, got {st.get('interactions')}"


# ---------------- 5.7 Ewald (optional) ----------------
R0 = np.array([0.13, 0.21, -0.07])


def t_ewald_alpha():
    v = [MP.ewald_potential(R0, 1.0, al, 3, 8) for al in (1.5, 2.0, 3.0)]
    a = [np.asarray(MP.ewald_acceleration(R0, 1.0, al, 3, 8)) for al in (1.5, 2.0, 3.0)]
    ok = max(v) - min(v) < 1e-8 and np.abs(a[0] - a[2]).max() < 1e-7
    return ok, f"the result must not depend on the splitting parameter alpha: potentials {v}"


def t_ewald_limit():
    r = 1e-3
    c = (MP.ewald_potential(np.array([r, 0, 0]), 1.0) - 1 / r)
    a = np.asarray(MP.ewald_acceleration(np.array([0.02, 0.01, 0.0]), 1.0))
    an = -np.array([0.02, 0.01, 0.0]) / np.linalg.norm([0.02, 0.01, 0.0]) ** 3
    return abs(c + 2.8373) < 2e-3 and np.abs(a - an).max() / np.abs(an).max() < 0.02, \
        f"phi - 1/r -> -2.8373/L for small r (got {c:.4f}); a -> Newton at small r"


def t_ewald_grad():
    h = 1e-5
    g = np.array([(MP.ewald_potential(R0 + h * e) - MP.ewald_potential(R0 - h * e)) / (2 * h) for e in np.eye(3)])
    a = np.asarray(MP.ewald_acceleration(R0))
    return np.abs(g - a).max() / np.abs(a).max() < 1e-5, "ewald_acceleration must be the gradient of ewald_potential"


def t_ewald_sym():
    a = np.asarray(MP.ewald_acceleration(R0))
    ok = np.abs(np.asarray(MP.ewald_acceleration(-R0)) + a).max() < 1e-8
    ok &= np.abs(np.asarray(MP.ewald_acceleration(R0 + np.array([1.0, 0, 0]))) - a).max() < 1e-4 * np.abs(a).max()
    for pt in ([.5, 0, 0], [.5, .5, 0], [.5, .5, .5]):
        ok &= np.abs(np.asarray(MP.ewald_acceleration(np.array(pt)))).max() < 1e-6
    return bool(ok), "a(-r) = -a(r); periodic with period L; zero force at (L/2,0,0), (L/2,L/2,0), (L/2,L/2,L/2)"


check("5.1 second-moment tensor in every node (2D and 3D)", t_quadrupoles)
check("5.2 quadrupole force of a group: far field", t_quad_far)
check("5.2 quadrupole force: error scaling d^-5", t_quad_scaling)
check("5.2 quadrupole force with softening", t_quad_soft)
check("5.2 quad_acceleration: monopole limit and G", t_quad_basic)
check("5.3 accept_geometric", t_accept_geometric)
check("5.3 accept_offset", t_accept_offset)
check("5.3 accept_relative", t_accept_relative)
check("5.4 theta = 0 reproduces direct summation", t_theta0)
check("5.4 monopole mode equals your Lecture 4 walk", t_monopole_same_as_l04)
check("5.4 quadrupoles improve accuracy at equal cost", t_quad_accuracy)
check("5.4 quadrupole error falls like theta^4", t_quad_theta)
check("5.5 offset criterion", t_offset)
check("5.5 relative criterion", t_relative)
check("5.5 relative without acc_old", t_relative_fallback)
check("5.5 containing cell is still opened", t_contains_still)
check("5.7 Ewald: independent of alpha", t_ewald_alpha, optional=True)
check("5.7 Ewald: small-r limit", t_ewald_limit, optional=True)
check("5.7 Ewald: acceleration = gradient of potential", t_ewald_grad, optional=True)
check("5.7 Ewald: symmetry and periodicity", t_ewald_sym, optional=True)

print(f"\n{sum(results)}/{len(results)} required checks passed"
      + (f"; optional: {sum(optional_results)}/{len(optional_results)}" if optional_results else ""))
sys.exit(0 if all(results) else 1)
