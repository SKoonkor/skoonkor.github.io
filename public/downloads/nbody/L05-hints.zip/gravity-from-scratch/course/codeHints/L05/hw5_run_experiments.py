"""HW5 experiment scaffold. Copy to myOwnCode/L05/ next to multipole.py."""
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

sys.path.append(str(Path(__file__).resolve().parent.parent / "L03"))
sys.path.append(str(Path(__file__).resolve().parent.parent / "L04"))
from vectorised import acceleration_np, plummer_sphere  # your L03 code
from tree import build_tree                              # your L04 code
from multipole import (compute_quadrupoles, quad_acceleration,  # noqa: F401
                       tree_acceleration_multipole)


def error_summary(acc, acc_ref):
    """(median, 99th percentile, maximum) of |a - a_ref| / |a_ref|."""
    e = np.linalg.norm(acc - acc_ref, axis=1) / np.linalg.norm(acc_ref, axis=1)
    return np.median(e), np.percentile(e, 99), e.max()


if __name__ == "__main__":
    pos, vel, mass = plummer_sphere(1000, a=1.0, seed=1)
    eps = 0.05
    acc_ref = acceleration_np(pos, mass, 1.0, eps)
    # HW 5.2: far-field error of one group, monopole vs monopole + quadrupole, vs distance
    # TODO
    # HW 5.4: error vs theta, monopole and quadrupole (median and 99th percentile)
    # TODO
    # HW 5.5: error vs interactions per particle for geometric / offset / relative criteria
    # TODO
    # HW 5.7 (optional): Ewald potential is independent of alpha; small-r limit
    # TODO
    plt.show()
