"""HW5 skeleton. Copy to myOwnCode/L05/multipole.py and fill in.

Builds on your own Lecture 4 tree (myOwnCode/L04/tree.py).
"""
import sys
from pathlib import Path

import numpy as np

sys.path.append(str(Path(__file__).resolve().parent.parent / "L04"))
from tree import build_tree, Node  # noqa: F401  (your L04 code)


def compute_quadrupoles(root, pos, mass):
    """Set node.quad = sum_j m_j s_j s_j^T (s_j = r_j - node.com) for EVERY node.

    Leaves from their particles; internal nodes from their children.
    """
    # TODO: post-order recursion; parallel-axis theorem for internal nodes
    raise NotImplementedError


def quad_acceleration(dvec, M, I, G=1.0, eps=0.0):
    """Acceleration on a particle from a group (3D).

    dvec = COM - particle position, M = mass, I = second-moment tensor (3,3).
    Monopole + quadrupole; softening enters as D^2 = |dvec|^2 + eps^2.
    """
    raise NotImplementedError


def accept_geometric(node, dd, theta):
    """Barnes-Hut: side s = 2*half; True if s/d < theta (dd = d^2)."""
    raise NotImplementedError


def accept_offset(node, dd, theta):
    """True if d > s/theta + delta, delta = |node.com - node.center|."""
    raise NotImplementedError


def accept_relative(node, dd, alpha, a_old, G=1.0):
    """True if G M s^2 <= alpha |a_old| d^4 (a_old: size of the particle's previous acceleration)."""
    raise NotImplementedError


def tree_acceleration_multipole(pos, mass, G=1.0, eps=0.0, theta=0.5, criterion="geometric",
                                alpha=0.005, acc_old=None, use_quad=True, root=None, stats=None):
    """Your L04 walk with (1) a choice of opening criterion and (2) quadrupole interactions.

    criterion: "geometric" | "offset" | "relative" (needs acc_old (N,3); if None, use geometric).
    root: a tree from build_tree; compute quadrupoles if root.quad is None and use_quad.
    """
    raise NotImplementedError


# ---- Ewald summation (optional, HW 5.7): cubic box of side L, unit source at the origin ----
def ewald_potential(r, L=1.0, alpha=None, n_real=2, n_k=5):
    """phi(r) per unit G*m (Newtonian limit 1/r). alpha=None means 2/L."""
    raise NotImplementedError


def ewald_acceleration(r, L=1.0, alpha=None, n_real=2, n_k=5):
    """a(r) = grad phi per unit G*m (Newtonian limit -r/|r|^3)."""
    raise NotImplementedError
