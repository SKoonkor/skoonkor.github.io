Gravity from Scratch -- Lecture 5 hints
========================================

Requires Python 3 with numpy (and matplotlib for the experiment scripts).

1. Read course/codeHints/L05/ -- it has a skeleton with the functions you
   need to write, and small scripts for plots and timing.
2. Follow myOwnCode/L05/README.txt to set up your own copy.
3. Check your work:
       cd gravity-from-scratch
       python course/codeHints/L05/check_hw5.py
   (pass folders explicitly with --l03 DIR --l04 DIR --l05 DIR)
   Each line prints PASS or FAIL. Aim for all PASS before moving on.
4. Only once you're all green, get the reference-solution zip from the lecture
   page and compare it with your own code.
