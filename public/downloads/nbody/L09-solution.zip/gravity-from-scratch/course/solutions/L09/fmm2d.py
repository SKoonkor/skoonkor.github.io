"""Reference solution, Lecture 9: 2D fast multipole method (uniform quadtree, complex variables).

The field of masses q_j at z_j is f(z) = sum_j q_j / (z - z_j)  (complex).  The 2D gravitational acceleration
(force ~ 1/r) on a point at z is a = -G conj(f(z)).
Expansions (p terms, k = 0..p-1):
    multipole about z_c : f(z) = sum_k c_k / (z - z_c)^(k+1),   c_k = sum_j q_j (z_j - z_c)^k
    local about z_t     : f(z) = sum_l L_l (z - z_t)^l
"""
from math import comb

import numpy as np


# ---------------- 9.1 the five operators ----------------
def p2m(z, q, zc, p):
    """Multipole coefficients c_k = sum q (z - zc)^k, k = 0..p-1."""
    return (q[:, None] * (z[:, None] - zc) ** np.arange(p)).sum(axis=0)


def m2m(c, d):
    """Shift a multipole expansion: d = (old centre) - (new centre). c'_k = sum_{j<=k} C(k,j) c_j d^(k-j)."""
    p = len(c)
    out = np.zeros(p, dtype=complex)
    for k in range(p):
        for j in range(k + 1):
            out[k] += comb(k, j) * c[j] * d ** (k - j)
    return out


def m2l_matrix(d, p):
    """T[l, k] = (-1)^l C(k+l, l) / d^(k+l+1): local coefficients L = T @ c; d = (target centre) - (source centre)."""
    T = np.zeros((p, p), dtype=complex)
    for l in range(p):
        for k in range(p):
            T[l, k] = (-1) ** l * comb(k + l, l) / d ** (k + l + 1)
    return T


def m2l(c, d):
    return m2l_matrix(d, len(c)) @ c


def l2l(L, s):
    """Shift a local expansion: s = (new centre) - (old centre). L'_m = sum_{l>=m} C(l,m) L_l s^(l-m)."""
    p = len(L)
    out = np.zeros(p, dtype=complex)
    for m in range(p):
        for l in range(m, p):
            out[m] += comb(l, m) * L[l] * s ** (l - m)
    return out


def l2p(L, w):
    """Evaluate the local expansion at offsets w = z - centre (array)."""
    return sum(L[l] * w**l for l in range(len(L)))


def m2p(c, w):
    """Evaluate the multipole expansion at offsets w = z - centre (array)."""
    return sum(c[k] / w ** (k + 1) for k in range(len(c)))


def direct_field(zt, z, q, skip_self=False):
    """f(zt) = sum_j q_j / (zt - z_j); with skip_self, zt is z and the term j = i is omitted."""
    d = zt[:, None] - z[None, :]
    if skip_self:
        np.fill_diagonal(d, np.inf)
    return (q[None, :] / d).sum(axis=1)


def acceleration(z, q, G=1.0, f=None):
    """2D gravity a = -G conj(f), as a complex number per particle."""
    if f is None:
        f = direct_field(z, z, q, skip_self=True)
    return -G * np.conj(f)


# ---------------- 9.2 / 9.3 the FMM on a uniform quadtree ----------------
def box_centres(level):
    n = 2**level
    x = (np.arange(n) + 0.5) / n
    return x[:, None] + 1j * x[None, :]                  # centre[ix, iy]


def leaf_index(z, level):
    n = 2**level
    ix = np.clip((z.real * n).astype(int), 0, n - 1)
    iy = np.clip((z.imag * n).astype(int), 0, n - 1)
    return ix, iy


def interaction_offsets(ix, iy):
    """Offsets (dx, dy) of the interaction list of box (ix, iy): children of the parent's neighbours that are not neighbours."""
    out = []
    for dx in range(-3, 4):
        for dy in range(-3, 4):
            if max(abs(dx), abs(dy)) <= 1:
                continue
            if abs((ix + dx) // 2 - ix // 2) <= 1 and abs((iy + dy) // 2 - iy // 2) <= 1:
                out.append((dx, dy))
    return out


def interaction_list(ix, iy, level):
    """Boxes (jx, jy) of the interaction list of box (ix, iy) at `level` (inside the domain)."""
    n = 2**level
    return [(ix + dx, iy + dy) for dx, dy in interaction_offsets(ix, iy) if 0 <= ix + dx < n and 0 <= iy + dy < n]


def bh_field(z, q, theta=0.5, stats=None):
    """Barnes-Hut in 2D with the 1/r law: f(z_i) = sum q_j / (z_i - z_j), monopoles from your Lecture 4 tree."""
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "L04"))
    import tree as T
    z = np.asarray(z, dtype=complex)
    pos = np.stack([z.real, z.imag], axis=1)
    root = T.build_tree(pos, q)
    f = np.zeros(len(z), dtype=complex)
    count = 0
    for i in range(len(z)):
        stack = [root]
        acc = 0j
        while stack:
            node = stack.pop()
            if node.children is None:
                for j in node.indices:
                    if j != i:
                        acc += q[j] / (z[i] - z[j])
                        count += 1
                continue
            zc = node.com[0] + 1j * node.com[1]
            d = z[i] - zc
            inside = np.all(np.abs(pos[i] - node.center) <= node.half)
            if not inside and T.accept(node, abs(d) ** 2, theta):
                acc += node.mass / d
                count += 1
            else:
                stack.extend(node.children)
        f[i] = acc
    if stats is not None:
        stats["interactions"] = count
    return f


def fmm_field(z, q, p=10, levels=4, stats=None):
    """f(z_i) = sum_{j != i} q_j / (z_i - z_j) for particles in the unit square. Uniform quadtree with 4^levels leaves."""
    if levels < 2:
        raise ValueError("levels must be at least 2")
    z = np.asarray(z, dtype=complex)
    q = np.asarray(q, dtype=float)
    N = len(z)
    Lv = levels
    ixs, iys = leaf_index(z, Lv)
    n = 2**Lv
    order = np.argsort(ixs * n + iys, kind="stable")
    key = (ixs * n + iys)[order]
    start = np.searchsorted(key, np.arange(n * n))
    end = np.searchsorted(key, np.arange(n * n), side="right")
    members = lambda ix, iy: order[start[ix * n + iy]:end[ix * n + iy]]     # noqa: E731

    M = {l: np.zeros((2**l, 2**l, p), dtype=complex) for l in range(2, Lv + 1)}
    Lc = {l: np.zeros((2**l, 2**l, p), dtype=complex) for l in range(2, Lv + 1)}
    # upward pass: P2M at the leaves, M2M to the parents
    cen = {l: box_centres(l) for l in range(0, Lv + 1)}
    for ix in range(n):
        for iy in range(n):
            idx = members(ix, iy)
            if len(idx):
                M[Lv][ix, iy] = p2m(z[idx], q[idx], cen[Lv][ix, iy], p)
    for l in range(Lv - 1, 1, -1):
        for ix in range(2**l):
            for iy in range(2**l):
                acc = np.zeros(p, dtype=complex)
                for cx in (0, 1):
                    for cy in (0, 1):
                        child = (2 * ix + cx, 2 * iy + cy)
                        acc += m2m(M[l + 1][child], cen[l + 1][child] - cen[l][ix, iy])
                M[l][ix, iy] = acc
    # downward pass: M2L from the interaction list, L2L from the parent
    Tcache = {}
    n_m2l = 0
    for l in range(2, Lv + 1):
        nl = 2**l
        size = 1.0 / nl
        for ix in range(nl):
            for iy in range(nl):
                acc = np.zeros(p, dtype=complex)
                if l > 2:
                    par = (ix // 2, iy // 2)
                    acc += l2l(Lc[l - 1][par], cen[l][ix, iy] - cen[l - 1][par])
                for dx, dy in interaction_offsets(ix, iy):
                    sx, sy = ix + dx, iy + dy
                    if 0 <= sx < nl and 0 <= sy < nl:
                        key_ = (l, dx, dy)
                        if key_ not in Tcache:
                            Tcache[key_] = m2l_matrix(-(dx + 1j * dy) * size, p)      # d = target centre - source centre
                        acc += Tcache[key_] @ M[l][sx, sy]
                        n_m2l += 1
                Lc[l][ix, iy] = acc
    # leaves: L2P for the far field, direct sums for the near field
    f = np.zeros(N, dtype=complex)
    n_pp = 0
    for ix in range(n):
        for iy in range(n):
            idx = members(ix, iy)
            if len(idx) == 0:
                continue
            f[idx] = l2p(Lc[Lv][ix, iy], z[idx] - cen[Lv][ix, iy])
            near = np.concatenate([members(jx, jy) for jx in range(max(ix - 1, 0), min(ix + 2, n))
                                   for jy in range(max(iy - 1, 0), min(iy + 2, n))])
            d = z[idx][:, None] - z[near][None, :]
            d[d == 0] = np.inf                                # the particle itself
            f[idx] += (q[near][None, :] / d).sum(axis=1)
            n_pp += len(idx) * len(near)
    if stats is not None:
        stats["m2l"] = n_m2l
        stats["pp"] = n_pp
    return f
