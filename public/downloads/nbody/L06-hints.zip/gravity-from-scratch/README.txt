Gravity from Scratch -- Lecture 6 hints
========================================

Requires Python 3 with numpy (and matplotlib for the experiment scripts).

1. Read course/codeHints/L06/ -- it has a skeleton with the functions you
   need to write, and small scripts for plots and timing.
2. Follow myOwnCode/L06/README.txt to set up your own copy.
3. Check your work:
       cd gravity-from-scratch
       python course/codeHints/L06/check_hw6.py
   (pass folders explicitly with --l03 DIR --l06 DIR)
   Each line prints PASS or FAIL. Aim for all PASS before moving on.
4. Only once you're all green, get the reference-solution zip from the lecture
   page and compare it with your own code.
