"""Checker for HW6. Run from the project folder:

    python course/codeHints/L06/check_hw6.py [--l03 DIR] [--l06 DIR]

Defaults: myOwnCode/L03 (vectorised.py) and myOwnCode/L06 (pm.py).
"""
import argparse
import sys
import time
from math import erfc
from pathlib import Path

import numpy as np

root_dir = Path(__file__).resolve().parents[3]
ap = argparse.ArgumentParser()
ap.add_argument("--l03", default=str(root_dir / "myOwnCode" / "L03"))
ap.add_argument("--l06", default=str(root_dir / "myOwnCode" / "L06"))
args = ap.parse_args()
sys.path.insert(0, args.l03)
sys.path.insert(0, args.l06)

results = []


def check(name, fn):
    try:
        ok, msg = fn()
    except NotImplementedError:
        ok, msg = False, "not implemented yet"
    except Exception as e:  # noqa: BLE001
        ok, msg = False, f"{type(e).__name__}: {e}"
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"   <- {msg}"))


try:
    import pm as P
except ImportError as e:
    sys.exit(f"Cannot import pm.py from {args.l06}: {e}")
try:
    import vectorised as V
except ImportError as e:
    sys.exit(f"Cannot import your Lecture 3 code: {e}")

SCHEMES = ("ngp", "cic", "tsc")


def ewald_acc(r, L=1.0, alpha=None, n_real=2, n_k=5):
    """Periodic acceleration per unit G*m of a point source at the origin (reference; see Lecture 5)."""
    alpha = 2.0 / L if alpha is None else alpha
    rng = np.arange(-n_real, n_real + 1)
    nx = np.array(np.meshgrid(rng, rng, rng, indexing="ij")).reshape(3, -1).T * L
    w = r[None, :] + nx
    u = np.linalg.norm(w, axis=1)
    fr = np.vectorize(erfc)(alpha * u) / u**3 + 2 * alpha / np.sqrt(np.pi) * np.exp(-((alpha * u) ** 2)) / u**2
    a = -np.sum(fr[:, None] * w, axis=0)
    km = np.arange(-n_k, n_k + 1)
    m = np.array(np.meshgrid(km, km, km, indexing="ij")).reshape(3, -1).T
    m = m[np.any(m != 0, axis=1)]
    m2 = (m**2).sum(axis=1)
    c = np.exp(-np.pi**2 * m2 / (alpha * L) ** 2) / m2 * np.sin(2 * np.pi * (m @ r) / L)
    return a - (2.0 / L**2) * np.sum(c[:, None] * m, axis=0)


# ---------------- 6.1 mass assignment ----------------
def t_mass():
    rng = np.random.default_rng(0)
    pos, m = rng.random((40, 3)) * 2.0, rng.random(40) + 0.5
    for sc in SCHEMES:
        rho = np.asarray(P.assign_density(pos, m, 12, 2.0, sc))
        if rho.shape != (12, 12, 12) or not np.isclose(rho.sum() * (2.0 / 12) ** 3, m.sum()):
            return False, f"{sc}: shape {rho.shape}, mass {rho.sum() * (2.0 / 12) ** 3:.6f} instead of {m.sum():.6f}"
    return True, ""


def t_nodes():
    n, box = 8, 1.0
    h = box / n
    one = np.array([1.0])

    def dep(p, sc):
        return np.asarray(P.assign_density(np.array([[p[0] * h, p[1] * h, p[2] * h]]), one, n, box, sc)) * h**3

    r = dep((2.3, 3.4, 5.1), "ngp")
    if not (np.isclose(r[2, 3, 5], 1.0) and np.isclose(r.sum(), 1.0)):
        return False, "NGP at (2.3,3.4,5.1)h: all the mass belongs on node (2,3,5) (and the density is divided by h^3)"
    r = dep((2.7, 3.6, 5.4), "ngp")
    if not np.isclose(r[3, 4, 5], 1.0):
        return False, "NGP at (2.7,3.6,5.4)h: the NEAREST node is (3,4,5), not the node to the left"
    c = dep((2, 3, 5), "cic")
    if not np.isclose(c[2, 3, 5], 1.0):
        return False, "CIC with the particle exactly on node (2,3,5): weight 1 there"
    c = dep((2.5, 3.5, 5.5), "cic")
    if not (np.allclose(c[2:4, 3:5, 5:7], 1 / 8) and np.isclose(c.sum(), 1.0)):
        return False, "CIC at the centre of a cell: 1/8 on each of the eight surrounding nodes"
    c = dep((2.25, 3, 5), "cic")
    if not (np.isclose(c[2, 3, 5], 0.75) and np.isclose(c[3, 3, 5], 0.25)):
        return False, "CIC per-axis weights (1-d, d) with index order [ix,iy,iz]"
    t = dep((2, 3, 5), "tsc")
    if not (np.isclose(t[2, 3, 5], 0.75**3) and np.isclose(t[1, 3, 5], 0.125 * 0.75 * 0.75) and np.isclose(t.sum(), 1.0)):
        return False, "TSC on a node: per-axis weights (1/8, 3/4, 1/8)"
    t = dep((2.6, 3, 5), "tsc")
    if not (np.allclose([t[2, 3, 5], t[3, 3, 5], t[4, 3, 5]], np.array([0.405, 0.59, 0.005]) * 0.5625, atol=1e-9)):
        return False, "TSC at x=2.6h: central node is the NEAREST node (3), weights 0.405, 0.59, 0.005 on nodes 2,3,4"
    return True, ""


def t_wrap():
    n, box = 8, 1.0
    h = box / n
    c = np.asarray(P.assign_density(np.array([[0.99 * box, 0.5 * h, 0.2]]), np.array([1.0]), n, box, "cic")) * h**3
    ok = c[7, 0, 1] + c[0, 0, 1] > 0 and np.isclose(c.sum(), 1.0)
    c2 = np.asarray(P.assign_density(np.array([[0.99 * box + 3 * box, 0.5 * h, 0.2 - 2 * box]]), np.array([1.0]), n, box, "cic")) * h**3
    return bool(ok and np.allclose(c, c2)), "positions and grid indices must wrap (periodic box; particles may lie outside [0, box))"


def t_moment():
    rng = np.random.default_rng(1)
    n, box = 16, 1.0
    h = box / n
    pos = 0.3 + 0.4 * rng.random((10, 3))
    m = rng.random(10) + 0.5
    for sc in ("cic", "tsc"):
        rho = np.asarray(P.assign_density(pos, m, n, box, sc)) * h**3
        x = np.arange(n) * h
        com = np.array([(rho.sum(axis=(1, 2)) * x).sum(), (rho.sum(axis=(0, 2)) * x).sum(), (rho.sum(axis=(0, 1)) * x).sum()])
        if not np.allclose(com, (m[:, None] * pos).sum(axis=0), atol=1e-12):
            return False, f"{sc}: the first moment (centre of mass) of the grid mass must equal that of the particles"
    return True, ""


def t_adjoint():
    rng = np.random.default_rng(2)
    n, box = 10, 1.5
    h = box / n
    pos, m = rng.random((30, 3)) * box, rng.random(30) + 0.5
    for sc in SCHEMES:
        f = rng.normal(size=(n, n, n))
        lhs = (np.asarray(P.assign_density(pos, m, n, box, sc)) * f).sum() * h**3
        rhs = (m * np.asarray(P.interpolate(f, pos, box, sc))).sum()
        if not np.isclose(lhs, rhs):
            return False, f"{sc}: assignment and interpolation must use the same weights: sum(rho f) h^3 = {lhs:.6f} but sum(m f(x)) = {rhs:.6f}"
    return True, ""


# ---------------- 6.2 potential ----------------
def cos_mode(n=32, m_wave=3, amp=0.5, axis=0):
    h = 1.0 / n
    x = np.arange(n) * h
    grid = np.meshgrid(x, x, x, indexing="ij")
    k = 2 * np.pi * m_wave
    return 1.0 + amp * np.cos(k * grid[axis]), k, grid


def t_poisson_spectral():
    n, box = 32, 2.0
    x = np.arange(n) * box / n
    Y = np.meshgrid(x, x, x, indexing="ij")[1]
    k = 2 * np.pi * 3 / box
    rho = 1.0 + 0.5 * np.cos(k * Y)
    phi = np.asarray(P.solve_potential(rho, box, 2.0, "spectral"))
    err = np.abs(phi + 4 * np.pi * 2.0 * 0.5 * np.cos(k * Y) / k**2).max()
    return err < 1e-10 and abs(phi.mean()) < 1e-10, f"phi must equal -4 pi G delta cos(kx)/k^2 with the mean of rho dropped; error {err:.1e}"


def t_poisson_fd():
    n = 32
    rho, k, grid = cos_mode(n, 3, 0.5, axis=2)
    h = 1.0 / n
    keff2 = (2 / h * np.sin(k * h / 2)) ** 2
    phi = np.asarray(P.solve_potential(rho, 1.0, 1.0, "fd"))
    err = np.abs(phi + 4 * np.pi * 0.5 * np.cos(k * grid[2]) / keff2).max()
    return err < 1e-10, f"kernel 'fd': k^2 -> (2/h sin(k h/2))^2 per axis; error {err:.1e}"


# ---------------- 6.3 force on the grid ----------------
def t_grid_force_spectral():
    n = 32
    box = 2.0
    x = np.arange(n) * box / n
    X = np.meshgrid(x, x, x, indexing="ij")[0]
    k = 2 * np.pi * 3 / box
    phi = np.cos(k * X) * 2.0
    a = np.asarray(P.grid_force(phi, box, "spectral"))
    ok = a.shape == (3, n, n, n) and np.abs(a[0] - 2.0 * k * np.sin(k * X)).max() < 1e-9 and np.abs(a[1]).max() < 1e-9 and np.abs(a[2]).max() < 1e-9
    return bool(ok), "a = -grad phi with shape (3,n,n,n); component 0 is x"


def t_grid_force_fd():
    n = 32
    h = 1.0 / n
    x = np.arange(n) * h
    X, Y, Z = np.meshgrid(x, x, x, indexing="ij")
    k = 2 * np.pi * 3
    phi = np.cos(k * Y)
    a = np.asarray(P.grid_force(phi, 1.0, "fd4"))
    exp = (8 * np.sin(k * h) - np.sin(2 * k * h)) / (6 * h) * np.sin(k * Y)
    return bool(np.abs(a[1] - exp).max() < 1e-8 and np.abs(a[0]).max() < 1e-9), "4-point difference: a_y = -(8(f[+1]-f[-1]) - (f[+2]-f[-2]))/(12 h) along axis 1"


# ---------------- 6.4 interpolation ----------------
def t_interp():
    n, box = 16, 1.0
    h = box / n
    x = np.arange(n) * h
    X, Y, Z = np.meshgrid(x, x, x, indexing="ij")
    rng = np.random.default_rng(3)
    pos = 0.3 + 0.4 * rng.random((20, 3))
    for sc in ("cic", "tsc"):
        v = np.asarray(P.interpolate(np.ones((n, n, n)) * 2.5, pos, box, sc))
        r = np.asarray(P.interpolate(X + 2 * Y - Z, pos, box, sc))
        if not (np.allclose(v, 2.5) and np.allclose(r, pos[:, 0] + 2 * pos[:, 1] - pos[:, 2])):
            return False, f"{sc}: a constant and a linear ramp must be reproduced exactly"
    vec = np.asarray(P.interpolate(np.stack([X, Y, Z]), pos, box, "cic"))
    return vec.shape == (20, 3) and np.allclose(vec, pos), "a vector field (3,n,n,n) gives (N,3)"


# ---------------- 6.5 the full force ----------------
def t_momentum_self():
    rng = np.random.default_rng(4)
    pos, m = rng.random((60, 3)), rng.random(60) + 0.5
    for sc in SCHEMES:
        for dv in ("fd4", "spectral"):
            a = np.asarray(P.pm_acceleration(pos, m, 1.0, 0.0, 1.0, 16, sc, dv, "fd"))
            if np.abs((m[:, None] * a).sum(axis=0)).max() > 1e-9 * np.abs(m[:, None] * a).max():
                return False, f"{sc}/{dv}: total momentum change must vanish (same kernel for assignment and interpolation)"
    s = np.asarray(P.pm_acceleration(np.array([[0.31, 0.62, 0.17]]), np.array([1.0]), 1.0, 0.0, 1.0, 16, "cic", "fd4"))
    return bool(np.abs(s).max() < 1e-9), f"a single particle must feel no force on itself (got {np.abs(s).max():.1e})"


def t_pipeline():
    rng = np.random.default_rng(11)
    box, n = 1.7, 16
    pos, m = rng.random((25, 3)) * box, rng.random(25) + 0.5
    for sc in ("ngp", "cic", "tsc"):
        for dv in ("fd4", "spectral"):
            for kn in ("spectral", "fd"):
                a = np.asarray(P.pm_acceleration(pos, m, 1.3, 0.0, box, n, sc, dv, kn))
                rho = P.assign_density(pos, m, n, box, sc)
                b = np.asarray(P.interpolate(P.grid_force(P.solve_potential(rho, box, 1.3, kn), box, dv), pos, box, sc))
                if not np.allclose(a, b, rtol=1e-9, atol=1e-12):
                    return False, f"pm_acceleration must chain assign -> solve -> grid_force -> interpolate ({sc}, deriv={dv}, kernel={kn}); pass every argument through"
    return True, ""


def t_symmetry():
    rng = np.random.default_rng(5)
    pos, m = rng.random((30, 3)), rng.random(30) + 0.5
    a = np.asarray(P.pm_acceleration(pos, m, 1.0, 0.0, 1.0, 16, "cic", "fd4"))
    a2 = np.asarray(P.pm_acceleration(pos + np.array([1.0, -2.0, 3.0]), m, 1.0, 0.0, 1.0, 16, "cic", "fd4"))
    a3 = np.asarray(P.pm_acceleration(pos, m, 3.0, 0.7, 1.0, 16, "cic", "fd4"))
    return bool(np.allclose(a, a2) and np.allclose(a3, 3 * a)), "shifting every position by a multiple of the box changes nothing; the result scales with G and does not depend on eps"


def pair_errors(scheme, deriv, n, r_over_h, ntr=40, seed=6, kernel="spectral"):
    rng = np.random.default_rng(seed)
    h = 1.0 / n
    e = []
    for _ in range(ntr):
        d = rng.normal(size=3)
        d /= np.linalg.norm(d)
        x0 = rng.random(3)
        r = r_over_h * h
        a = np.asarray(P.pm_acceleration(np.array([x0, x0 + r * d]), np.array([1.0, 1e-6]), 1.0, 0.0, 1.0, n, scheme, deriv, kernel))[1]
        aE = ewald_acc(r * d)
        e.append(np.linalg.norm(a - aE) / np.linalg.norm(aE))
    return np.median(e), np.max(e)


def t_pair_cic():
    med, mx = pair_errors("cic", "fd4", 32, 6)
    return med < 0.03 and mx < 0.08, f"CIC + 4-point gradient, pair at r = 6h: median error {med:.3f} (expect ~0.007), maximum {mx:.3f} (expect ~0.04)"


def t_pair_cic_fdkernel():
    med, mx = pair_errors("cic", "fd4", 32, 6, kernel="fd")
    return med < 0.03 and mx < 0.08, f"CIC + 4-point gradient + finite-difference Laplacian, r = 6h: median {med:.3f} (expect ~0.015), maximum {mx:.3f} (expect ~0.04)"


def t_pair_tsc():
    med, mx = pair_errors("tsc", "fd4", 32, 6)
    return med < 0.03 and mx < 0.06, f"TSC + 4-point gradient, pair at r = 6h: median error {med:.3f} (expect ~0.002), maximum {mx:.3f} (expect ~0.007)"


def t_pair_spectral():
    med, _ = pair_errors("cic", "spectral", 32, 6)
    return med < 0.03, f"CIC + spectral gradient, pair at r = 6h: median error {med:.3f} (expect ~0.008; its maxima can be large: that is the lesson of the lecture)"


def t_pair_close():
    med, mx = pair_errors("cic", "fd4", 32, 3)
    return med < 0.1 and mx < 0.3, f"CIC + 4-point gradient, pair at r = 3h: median {med:.3f} (expect ~0.045), maximum {mx:.3f} (expect 0.14-0.18): the grid smooths the force below ~3h"


# ---------------- 6.6 dynamics ----------------
def t_dynamics():
    box, n = 8.0, 32
    h = box / n
    pos, vel, m = V.plummer_sphere(300, a=1.0, seed=7)
    pos, vel, m = np.asarray(pos) + box / 2, np.asarray(vel), np.asarray(m)
    force = lambda p, mm, G, e: P.pm_acceleration(p, mm, G, 0.0, box, n, "cic", "fd4", "spectral")  # noqa: E731
    p1, v1 = V.evolve_kdk(pos, vel, m, 0.02, 100, 1.0, 0.0, force=force)
    p2, v2 = V.evolve_kdk(pos, vel, m, 0.02, 100, 1.0, 0.5 * h)
    dP = np.abs((m[:, None] * v1).sum(axis=0) - (m[:, None] * vel).sum(axis=0)).max()
    r1 = np.asarray(V.lagrangian_radii(p1, m, (0.25, 0.5, 0.9)))
    r2 = np.asarray(V.lagrangian_radii(p2, m, (0.25, 0.5, 0.9)))
    ok = dP < 1e-10 and np.all(np.abs(r1 / r2 - 1) < 0.08)
    return bool(ok), f"after t=2: momentum change {dP:.1e} (expect <1e-10); Lagrangian radii PM/direct {np.round(r1 / r2, 3).tolist()} (expect within 8%, typically 2%)"


def t_speed():
    rng = np.random.default_rng(8)
    p, m = rng.random((20000, 3)), np.ones(20000) / 20000
    t0 = time.perf_counter()
    P.pm_acceleration(p, m, 1.0, 0.0, 1.0, 32, "cic", "fd4")
    t = time.perf_counter() - t0
    return t < 1.0, f"N=20000, 32^3 grid: {t:.2f} s (reference ~0.01 s): are there Python loops over particles or grid cells?"


check("6.1 mass assignment: shapes and mass conservation", t_mass)
check("6.1 NGP / CIC / TSC weights on nodes", t_nodes)
check("6.1 periodic wrapping", t_wrap)
check("6.1 CIC and TSC preserve the centre of mass", t_moment)
check("6.1 assignment and interpolation are adjoint", t_adjoint)
check("6.2 Poisson solver, spectral kernel", t_poisson_spectral)
check("6.2 Poisson solver, finite-difference kernel", t_poisson_fd)
check("6.3 grid force, spectral gradient", t_grid_force_spectral)
check("6.3 grid force, 4-point gradient", t_grid_force_fd)
check("6.4 interpolation (constants, ramps, vectors)", t_interp)
check("6.5 momentum conservation and no self-force", t_momentum_self)
check("6.5 pm_acceleration chains your own functions (all options)", t_pipeline)
check("6.5 periodicity, G scaling, eps ignored", t_symmetry)
check("6.5 pair force at 6h: CIC + 4-point gradient", t_pair_cic)
check("6.5 pair force at 6h: with the finite-difference Laplacian", t_pair_cic_fdkernel)
check("6.5 pair force at 6h: TSC + 4-point gradient", t_pair_tsc)
check("6.5 pair force at 6h: CIC + spectral gradient", t_pair_spectral)
check("6.5 pair force at 3h: CIC + 4-point gradient", t_pair_close)
check("6.6 leapfrog with the PM force", t_dynamics)
check("6.7 speed", t_speed)

print(f"\n{sum(results)}/{len(results)} checks passed")
sys.exit(0 if all(results) else 1)
