"""HW6 experiment scaffold. Copy to myOwnCode/L06/ next to pm.py."""
import sys
import time
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

sys.path.append(str(Path(__file__).resolve().parent.parent / "L03"))
from vectorised import acceleration_np, plummer_sphere, evolve_kdk, lagrangian_radii  # your L03 code
from pm import assign_density, solve_potential, grid_force, interpolate, pm_acceleration  # noqa: F401


def pair_setup(r_over_h, ngrid, rng):
    """Two particles a distance r apart in a unit box: a heavy source and a light probe."""
    d = rng.normal(size=3)
    d /= np.linalg.norm(d)
    x0 = rng.random(3)
    r = r_over_h / ngrid
    return np.array([x0, x0 + r * d]), np.array([1.0, 1e-6]), r, d


def newton(r, d, G=1.0, m=1.0):
    """Newtonian acceleration of the probe (pointing to the source); fine for r < 0.1 box."""
    return -G * m * d / r**2


def relative_error(a, a_ref):
    return np.linalg.norm(a - a_ref) / np.linalg.norm(a_ref)


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    # HW 6.2: Poisson test with a cosine density mode; error of both kernels
    # TODO
    # HW 6.5: pair force error vs r/h for NGP, CIC, TSC and the two gradients
    # TODO
    # HW 6.5: force error vs fractional position of the pair inside a cell
    # TODO
    # HW 6.6: Plummer sphere in a box of 8, PM vs direct sum with eps = h/2
    # TODO
    # HW 6.7: time pm_acceleration for N = 1e3 ... 1e5 and ngrid = 32, 64
    # TODO
    plt.show()
