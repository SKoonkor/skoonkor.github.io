"""HW6 skeleton. Copy to myOwnCode/L06/pm.py and fill in.

Periodic cube of side `box`; grid nodes at i*h (h = box/ngrid); arrays index [ix, iy, iz].
"""
import numpy as np


def assign_density(pos, mass, ngrid, box, scheme="cic"):
    """-> rho (ngrid, ngrid, ngrid), mass per volume. scheme: "ngp" | "cic" | "tsc".

    Positions are wrapped into the box; grid indices wrap (periodic).
    """
    # TODO: weights per axis, product over x, y, z, add to nodes, divide by h^3
    raise NotImplementedError


def solve_potential(rho, box, G=1.0, kernel="spectral"):
    """-> phi (ngrid, ngrid, ngrid) from  nabla^2 phi = 4 pi G rho  (mean of rho ignored).

    kernel "spectral": k^2 = kx^2 + ky^2 + kz^2.
    kernel "fd": k^2 = sum_i (2/h sin(k_i h/2))^2.
    """
    # TODO: FFT, divide by -k^2 / (4 pi G), k = 0 mode to zero, inverse FFT
    raise NotImplementedError


def grid_force(phi, box, method="spectral"):
    """-> a (3, ngrid, ngrid, ngrid) = -grad phi.

    method "spectral": multiply by -i k in Fourier space (drop the Nyquist mode).
    method "fd4": (8 (f[+1] - f[-1]) - (f[+2] - f[-2])) / (12 h) along each axis.
    """
    raise NotImplementedError


def interpolate(field, pos, box, scheme="cic"):
    """field (n,n,n) -> (N,);  field (3,n,n,n) -> (N,3). Same kernel as assign_density."""
    raise NotImplementedError


def pm_acceleration(pos, mass, G=1.0, eps=0.0, box=1.0, ngrid=32, scheme="cic", deriv="fd4", kernel="spectral"):
    """The whole pipeline: assign, solve (kernel), gradient (deriv), interpolate.

    eps is ignored (the grid softens the force); it is there so the signature
    matches force(pos, mass, G, eps).
    """
    raise NotImplementedError
