Gravity from Scratch -- Lecture 8 hints
========================================

Requires Python 3 with numpy (and matplotlib for the experiment scripts).

1. Read course/codeHints/L08/ -- it has a skeleton with the functions you
   need to write, and small scripts for plots and timing.
2. Follow myOwnCode/L08/README.txt to set up your own copy.
3. Check your work:
       cd gravity-from-scratch
       python course/codeHints/L08/check_hw8.py
   (pass folders explicitly with --l04 DIR --l06 DIR --l07 DIR --l08 DIR)
   Each line prints PASS or FAIL. Aim for all PASS before moving on.
4. Only once you're all green, get the reference-solution zip from the lecture
   page and compare it with your own code.
