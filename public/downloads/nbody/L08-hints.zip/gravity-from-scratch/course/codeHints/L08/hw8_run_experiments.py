"""Scaffold for the HW8 experiments (plotting only). Copy next to your hybrid.py; fill in the TODOs."""
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.append(str(Path(__file__).resolve().parents[1] / "L06"))
import hybrid as H  # noqa: E402

BOX, NGRID = 1.0, 32
h = BOX / NGRID


def pair_setup(r_over_h, ntr=100, seed=1):
    """Random probe/source pairs: positions of the source, unit vectors, separations."""
    rng = np.random.default_rng(seed)
    x0 = rng.random((ntr, 3)) * BOX
    d = rng.normal(size=(ntr, 3))
    d /= np.linalg.norm(d, axis=1)[:, None]
    return x0, d, r_over_h * h


def clustered(N=400, blobs=8, sigma=0.03, seed=1):
    rng = np.random.default_rng(seed)
    cen = rng.random((blobs, 3))
    return (cen[rng.integers(0, blobs, N)] + rng.normal(0, sigma, (N, 3))) % BOX, np.ones(N) / N


def plot_split(rs=1.0):
    r = np.linspace(0.01, 8, 300)
    # TODO: plot S(r) and 1 - S(r) from your short_range_factor
    raise NotImplementedError


def pair_errors():
    # TODO: Ewald reference (your Lecture 5 optional 5.7, or copy ewald_many from check_hw8.py) for pairs at several r/h; compare PM only, P3M CIC, P3M TSC
    raise NotImplementedError


def count_interactions():
    # TODO: for uniform and clumped particles, PP pairs per particle vs stats["interactions"] / N of tree_short_range
    raise NotImplementedError


def tradeoff():
    # TODO: clustered set, several r_s and r_cut/r_s: median error vs Ewald, and pairs per particle from find_pairs
    raise NotImplementedError


def cosmo_compare():
    # TODO: PM and P3M runs of your Lecture 7 box (evolve_hybrid), then |a_PM| / |a_P3M| against local density
    raise NotImplementedError


if __name__ == "__main__":
    t = time.time()
    # TODO: call the functions above
    print(f"done in {time.time() - t:.1f} s")
