"""Checker for HW8. Run from the project folder:

    python course/codeHints/L08/check_hw8.py [--l04 DIR] [--l06 DIR] [--l07 DIR] [--l08 DIR]

Defaults: myOwnCode/L04 (tree.py), L06 (pm.py), L07 (cosmo.py), L08 (hybrid.py).
"""
import argparse
import math
import sys
import time
from pathlib import Path

import numpy as np

root_dir = Path(__file__).resolve().parents[3]
ap = argparse.ArgumentParser()
for k in ("l04", "l06", "l07", "l08"):
    ap.add_argument("--" + k, default=str(root_dir / "myOwnCode" / k.upper()))
args = ap.parse_args()
for d in (args.l04, args.l06, args.l07, args.l08):
    sys.path.insert(0, d)

results = []


def check(name, fn):
    try:
        ok, msg = fn()
    except NotImplementedError:
        ok, msg = False, "not implemented yet"
    except Exception as e:  # noqa: BLE001
        ok, msg = False, f"{type(e).__name__}: {e}"
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"   <- {msg}"))


for mod, d, what in (("pm", args.l06, "Lecture 6 pm.py"), ("tree", args.l04, "Lecture 4 tree.py"), ("cosmo", args.l07, "Lecture 7 cosmo.py")):
    try:
        __import__(mod)
    except ImportError as e:
        sys.exit(f"Cannot import your {what} from {d}: {e}")
try:
    import hybrid as H
except ImportError as e:
    sys.exit(f"Cannot import hybrid.py from {args.l08}: {e}")
import cosmo as C  # noqa: E402
import pm  # noqa: E402

_erfc = np.frompyfunc(math.erfc, 1, 1)
BOX = 1.0


# ---------------- checker-internal references ----------------
def S_ref(r, rs):
    x = np.asarray(r, float) / (2 * rs)
    return np.asarray(_erfc(x), float) + np.asarray(r, float) / (rs * math.sqrt(math.pi)) * np.exp(-x * x)


def ewald_many(R, L=1.0, alpha=None, n_real=2, n_k=5):
    """Periodic acceleration per unit G m at separation R (target - source), shape (P,3) (Lecture 5)."""
    alpha = 2.0 / L if alpha is None else alpha
    rng = np.arange(-n_real, n_real + 1)
    nx = np.array(np.meshgrid(rng, rng, rng, indexing="ij")).reshape(3, -1).T * L
    km = np.arange(-n_k, n_k + 1)
    m = np.array(np.meshgrid(km, km, km, indexing="ij")).reshape(3, -1).T
    m = m[np.any(m != 0, axis=1)]
    m2 = (m**2).sum(1)
    damp = np.exp(-np.pi**2 * m2 / (alpha * L) ** 2) / m2
    out = np.zeros_like(R)
    for s in range(0, len(R), 400):
        Rb = R[s:s + 400]
        w = Rb[:, None, :] + nx[None]
        u = np.linalg.norm(w, axis=2)
        fr = np.asarray(_erfc(alpha * u), float) / u**3 + 2 * alpha / np.sqrt(np.pi) * np.exp(-((alpha * u) ** 2)) / u**2
        a = -(fr[:, :, None] * w).sum(1)
        a += -(2.0 / L**2) * ((damp[None] * np.sin(2 * np.pi * (Rb @ m.T) / L)) @ m)
        out[s:s + 400] = a
    return out


def wrap(d, box=BOX):
    return d - box * np.rint(d / box)


def clustered(seed, N=400, blobs=8, sigma=0.03):
    rng = np.random.default_rng(seed)
    cen = rng.random((blobs, 3))
    return (cen[rng.integers(0, blobs, N)] + rng.normal(0, sigma, (N, 3))) % BOX, np.ones(N) / N


def ewald_forces(pos, mass, T=60):
    N = len(pos)
    R = wrap(pos[:T, None, :] - pos[None, :, :]).reshape(-1, 3)
    mask = np.ones((T, N), bool)
    mask[np.arange(T), np.arange(T)] = False
    A = ewald_many(R[mask.reshape(-1)]).reshape(T, N - 1, 3)
    m2 = np.repeat(mass[None, :], T, 0)[mask].reshape(T, N - 1)
    return (A * m2[:, :, None]).sum(1)


def rel_err(a, ex):
    return np.linalg.norm(a[: len(ex)] - ex, axis=1) / np.linalg.norm(ex, axis=1)


def brute_pp(pos, mass, G, eps, box, rs, rcut):
    N = len(pos)
    d = wrap(pos[None, :, :] - pos[:, None, :], box)          # d[i, j] = x_j - x_i
    r2 = (d**2).sum(-1)
    r = np.sqrt(r2)
    w = np.where((r < rcut) & (r > 0), S_ref(r, rs) / (r2 + eps**2) ** 1.5, 0.0)
    return G * ((w * mass[None, :])[:, :, None] * d).sum(1)


def brute_pairs(pos, box, rcut):
    d = wrap(pos[None, :, :] - pos[:, None, :], box)
    r2 = (d**2).sum(-1)
    i, j = np.nonzero(np.triu(r2 < rcut**2, 1))
    return {(a, b) for a, b in zip(i, j)}


# ---------------- 8.1 the split ----------------
def t_split_values():
    r = np.array([0.0, 1.0, 2.0, 4.5])
    S = np.asarray(H.short_range_factor(r, 1.0))
    if S.shape != r.shape or not np.allclose(S, [1.0, 0.918891, 0.572404, 0.017533], atol=2e-5):
        return False, f"S(r) at r = 0, 1, 2, 4.5 (rs = 1) should be 1, 0.9189, 0.5724, 0.01753; got {np.round(S, 5)}"
    r2 = np.array([0.3, 1.7, 3.1])
    if not np.allclose(H.short_range_factor(r2 * 0.4, 0.4), H.short_range_factor(r2, 1.0), atol=1e-8):
        return False, "S depends only on r / rs"
    return bool(abs(float(H.short_range_factor(0.5, 1.0)) - float(S_ref(0.5, 1.0))) < 1e-5), "scalars must work too"


def t_split_identity():
    rs = 0.6
    for r in (0.7, 1.9, 3.3):
        e = 1e-5
        pot = lambda x: math.erfc(x / (2 * rs)) / x                 # noqa: E731
        f = -(pot(r + e) - pot(r - e)) / (2 * e) * r**2
        if abs(float(H.short_range_factor(r, rs)) - f) > 2e-5:
            return False, f"S(r) must be r^2 * (-d/dr) of erfc(r/2rs)/r: at r = {r} expected {f:.6f}"
    return True, ""


# ---------------- 8.2 mesh force ----------------
def t_long_basic():
    rng = np.random.default_rng(3)
    pos, m = rng.random((150, 3)) * 1.7 - 0.3, rng.random(150) + 0.5
    a = np.asarray(H.long_range_acceleration(pos, m, 1.0, 1.0, 16, 0.06, "tsc", "fd4", True))
    if a.shape != (150, 3):
        return False, "shape must be (N, 3)"
    mom = np.abs((m[:, None] * a).sum(0)).max()
    if mom > 1e-9 * np.abs(m[:, None] * a).max() * len(m):
        return False, f"total momentum change {mom:.2e}: assign and interpolate with the same weights, and a symmetric filter"
    a2 = np.asarray(H.long_range_acceleration(pos + np.array([1.0, -2.0, 3.0]), m, 3.0, 1.0, 16, 0.06, "tsc", "fd4", True))
    return bool(np.allclose(a2, 3 * a, rtol=1e-8, atol=1e-10)), "shifting by a box length changes nothing; the result scales with G"


def t_long_pairs():
    rng = np.random.default_rng(5)
    n = 32
    h = BOX / n
    rs = 1.25 * h
    worst = {}
    for scheme, rl, tol in (("tsc", (0.5, 1.0, 2.0, 4.0, 8.0), 0.05), ("cic", (1.0, 2.0, 4.0, 8.0), 0.06)):
        for rh in rl:
            ntr = 40
            x0 = rng.random((ntr, 3))
            d = rng.normal(size=(ntr, 3))
            d /= np.linalg.norm(d, axis=1)[:, None]
            R = rh * h * d
            E = ewald_many(R)
            exp = -(E * d).sum(1) * (rh * h) ** 2 - float(S_ref(rh * h, rs))          # expected long-range r^2 F
            got = np.zeros(ntr)
            for t in range(ntr):
                P = np.array([x0[t], x0[t] + R[t]])
                a = np.asarray(H.long_range_acceleration(P, np.array([1.0, 1e-6]), 1.0, BOX, n, rs, scheme, "fd4", True))[1]
                got[t] = -(a @ d[t]) * (rh * h) ** 2
            e = np.abs(np.median(got) / np.median(exp) - 1)
            worst[(scheme, rh)] = e
            if e > tol:
                return False, f"{scheme.upper()}, r = {rh} h: mesh force {np.median(got):.4f} vs expected {np.median(exp):.4f} (Ewald minus short range); check the exp(-k^2 rs^2) filter and the window deconvolution (divide rho_k by W^2)"
    return True, ""


# ---------------- 8.3 short-range sum ----------------
def t_find_pairs():
    rng = np.random.default_rng(2)
    for box, rcut, N in ((3.0, 0.7, 300), (3.0, 1.2, 60), (1.0, 0.45, 40)):          # last two: fewer than 3 cells per axis
        pos = rng.random((N, 3)) * box
        pos[:5] = np.array([[0.02, 1, 1], [box - 0.03, 1, 1], [1, 0.01, 1], [1, box - 0.02, 1.1], [0.05, 0.05, 0.05]])
        out = H.find_pairs(pos, box, rcut)
        i, j, d = (np.asarray(v) for v in out[:3])
        pairs = [tuple(sorted((int(a), int(b)))) for a, b in zip(i, j)]
        ref = brute_pairs(pos, box, rcut)
        if len(pairs) != len(set(pairs)):
            return False, f"box {box}, rcut {rcut}: some pairs are listed twice (few cells: neighbours found through several offsets)"
        if set(pairs) != ref:
            return False, f"box {box}, rcut {rcut}: {len(set(pairs) ^ ref)} pairs differ from a brute-force search (periodic minimum image, < rcut)"
        if not np.allclose(d, wrap(pos[j] - pos[i], box), atol=1e-12):
            return False, "d must be pos[j] - pos[i] wrapped to the minimum image"
    return True, ""


def t_pp_force():
    rng = np.random.default_rng(4)
    box = 2.0
    pos = rng.random((250, 3)) * box
    pos[:4] += 0.0
    m = rng.random(250) + 0.5
    rs = 0.09
    rcut = 4.5 * rs
    a = np.asarray(H.short_range_pp(pos, m, 1.3, 0.01, box, rs, rcut))
    ref = brute_pp(pos, m, 1.3, 0.01, box, rs, rcut)
    if not np.allclose(a, ref, rtol=1e-4, atol=1e-8):
        return False, f"short-range sum differs from the brute-force sum (largest difference {np.abs(a - ref).max():.2e}); softening: (r^2 + eps^2)^(3/2) in the denominator, S(r) with the true r"
    mom = np.abs((m[:, None] * a).sum(0)).max()
    return bool(mom < 1e-9 * np.abs(m[:, None] * a).sum(0).max() + 1e-12), f"Newton's third law: total momentum change {mom:.2e}"


def t_pp_speed():
    rng = np.random.default_rng(6)
    pos = rng.random((20000, 3))
    m = np.ones(20000) / 20000
    t = time.time()
    a = np.asarray(H.short_range_pp(pos, m, 1.0, 1e-3, 1.0, 0.03, 0.1))
    dt = time.time() - t
    return bool(a.shape == (20000, 3) and dt < 12), f"N = 20000 took {dt:.1f} s (limit 12 s): no loops over particles or pairs"


# ---------------- 8.3 P3M ----------------
def t_p3m_ewald_tsc():
    for seed in (1, 2):
        pos, mass = clustered(seed)
        ex = ewald_forces(pos, mass)
        e = rel_err(np.asarray(H.p3m_acceleration(pos, mass, 1.0, 0.0, 1.0, 32, None, None, "tsc", "fd4")), ex)
        if not (np.median(e) < 0.006 and np.percentile(e, 90) < 0.015 and e.max() < 0.04):
            return False, f"clustered particles vs Ewald (TSC): median {np.median(e):.4f}, 90% {np.percentile(e, 90):.4f}, max {e.max():.3f}; expected ~0.002 / 0.003 / 0.008 or better"
    return True, ""


def t_p3m_ewald_64():
    pos, mass = clustered(2)
    ex = ewald_forces(pos, mass)
    e = rel_err(np.asarray(H.p3m_acceleration(pos, mass, 1.0, 0.0, 1.0, 64, None, None, "tsc", "fd4")), ex)
    return bool(np.median(e) < 0.004 and np.percentile(e, 90) < 0.008 and e.max() < 0.03), f"64^3 mesh: median {np.median(e):.4f}, 90% {np.percentile(e, 90):.4f}, max {e.max():.3f} (expected ~0.0018 / 0.0026 / 0.003); the default r_cut = 4.5 r_s and r_s = 1.25 h matter"


def t_p3m_ewald_cic():
    pos, mass = clustered(3)
    ex = ewald_forces(pos, mass)
    e = rel_err(np.asarray(H.p3m_acceleration(pos, mass, 1.0, 0.0, 1.0, 32, None, None, "cic", "fd4")), ex)
    return bool(np.median(e) < 0.012 and np.percentile(e, 90) < 0.03 and e.max() < 0.08), f"CIC: median {np.median(e):.4f}, 90% {np.percentile(e, 90):.4f}, max {e.max():.3f} (expected ~0.003 / 0.007 / 0.02)"


def t_p3m_pairs():
    rng = np.random.default_rng(7)
    n = 32
    h = BOX / n
    for rh in (0.5, 1.0, 2.0, 4.0, 6.0, 9.0):
        ntr = 40
        x0 = rng.random((ntr, 3))
        d = rng.normal(size=(ntr, 3))
        d /= np.linalg.norm(d, axis=1)[:, None]
        R = rh * h * d
        ex = ewald_many(R)
        got = np.zeros((ntr, 3))
        for t in range(ntr):
            P = np.array([x0[t], x0[t] + R[t]])
            got[t] = np.asarray(H.p3m_acceleration(P, np.array([1.0, 1e-6]), 1.0, 0.0, BOX, n, None, None, "tsc", "fd4"))[1]
        e = np.linalg.norm(got - ex, axis=1) / np.linalg.norm(ex, axis=1)
        if e.max() > 0.04:
            return False, f"pair at r = {rh} h: largest error {e.max():.3f} (expected ~0.01); PM alone is at 100% below h. Check the smoothing and the match between mesh and short-range parts"
    return True, ""


def t_p3m_invariance():
    rng = np.random.default_rng(8)
    pos = rng.random((200, 3))
    m = rng.random(200) + 0.5
    a = np.asarray(H.p3m_acceleration(pos, m, 1.0, 0.01, 1.0, 16))
    a2 = np.asarray(H.p3m_acceleration(pos + np.array([1.0, -2.0, 3.0]), m, 2.5, 0.01, 1.0, 16))
    if not np.allclose(a2, 2.5 * a, rtol=1e-8, atol=1e-10):
        return False, "shifting positions by a box length changes nothing; the result scales with G"
    a0 = np.asarray(H.p3m_acceleration(pos, m, 1.0, 0.0, 1.0, 16))
    a1 = np.asarray(H.p3m_acceleration(pos, m, 1.0, 0.03, 1.0, 16))
    if np.allclose(a0, a1, rtol=1e-3):
        return False, "eps must soften the short-range force"
    mom = np.abs((m[:, None] * a1).sum(0)).max()
    return bool(mom < 1e-9 * np.abs(m[:, None] * a1).sum(0).max()), f"total momentum change {mom:.2e}"


# ---------------- 8.4 TreePM ----------------
def t_treepm_vs_p3m():
    pos, mass = clustered(1, N=300)
    ref = np.asarray(H.p3m_acceleration(pos, mass, 1.0, 0.0, 1.0, 32))
    a = np.asarray(H.treepm_acceleration(pos, mass, 1.0, 0.0, 1.0, 32, 0.1))
    d = np.linalg.norm(a - ref, axis=1) / np.linalg.norm(ref, axis=1)
    return bool(np.median(d) < 2e-3 and d.max() < 2e-2), f"TreePM with a small opening angle must reproduce P3M: median difference {np.median(d):.1e}, max {d.max():.1e}. Check the minimum image in the walk and the cutoff pruning"


def t_treepm_ewald():
    pos, mass = clustered(1)
    ex = ewald_forces(pos, mass)
    st5, st1 = {}, {}
    e = rel_err(np.asarray(H.treepm_acceleration(pos, mass, 1.0, 0.0, 1.0, 32, 0.5, stats=st5)), ex)
    if not (np.median(e) < 0.01 and np.percentile(e, 90) < 0.03 and e.max() < 0.12):
        return False, f"theta = 0.5 vs Ewald: median {np.median(e):.4f}, 90% {np.percentile(e, 90):.4f}, max {e.max():.3f} (expected ~0.004 / 0.013 / 0.03)"
    e1 = rel_err(np.asarray(H.treepm_acceleration(pos, mass, 1.0, 0.0, 1.0, 32, 1.0, stats=st1)), ex)
    if not (np.median(e1) > np.median(e)):
        return False, "a larger opening angle must give a larger error"
    return bool(st1["interactions"] < st5["interactions"]), "a larger opening angle must use fewer interactions"


def t_treepm_cost():
    N = 1600
    rng = np.random.default_rng(N)
    cen = rng.random((8, 3))
    pos = (cen[rng.integers(0, 8, N)] + rng.normal(0, 0.02, (N, 3))) % BOX
    m = np.ones(N) / N
    rs = 1.25 / 32
    rc = 4.5 * rs
    I, J, _ = H.find_pairs(pos, BOX, rc)
    st = {}
    H.tree_short_range(pos, m, 1.0, 0.0, BOX, rs, rc, 0.5, stats=st)
    ratio = st["interactions"] / (2 * len(I))
    if not ratio < 0.9:
        return False, f"clumped particles: tree interactions / pair interactions = {ratio:.2f}; the tree should need fewer than the chaining-mesh sum (~0.55)"
    Nu = 1000
    pu = np.random.default_rng(0).random((Nu, 3))
    su = {}
    H.tree_short_range(pu, np.ones(Nu) / Nu, 1.0, 0.0, BOX, rs, rc, 0.5, stats=su)
    per = su["interactions"] / Nu
    return bool(per < 100), f"uniform particles: {per:.0f} tree interactions per particle (expected ~50); cells beyond r_cut must be pruned, not opened or accepted"


def t_tree_eps():
    rng = np.random.default_rng(12)
    pos = rng.random((250, 3)) * 1.0
    m = rng.random(250) + 0.5
    m /= m.sum()
    rs = 0.05
    rc = 4.5 * rs
    a = np.asarray(H.tree_short_range(pos, m, 1.3, 0.02, 1.0, rs, rc, 0.03))
    ref = brute_pp(pos, m, 1.3, 0.02, 1.0, rs, rc)
    d = np.linalg.norm(a - ref, axis=1) / (np.linalg.norm(ref, axis=1) + 1e-30)
    return bool(np.median(d) < 1e-3 and d.max() < 3e-2), f"tree short-range force vs brute force at a very small theta with softening 0.02: median difference {np.median(d):.1e}, max {d.max():.1e} (softening (r^2 + eps^2)^(3/2); S(r) with the true r; sharp cut at r_cut)"


# ---------------- 8.5 evolution ----------------
def t_evolve():
    n, box = 8, 100.0
    d0 = C.gaussian_field(n, box, C.bbks_pk, 5)
    psi = C.displacement_field(d0, box)
    pos, mom = C.zeldovich_ics(psi, box, 0.05)
    p3, m3 = H.evolve_hybrid(pos, mom, 0.05, 0.12, 4, box, 16, method="p3m", eps=0.5)
    tp, mt = H.evolve_hybrid(pos, mom, 0.05, 0.12, 4, box, 16, method="treepm", theta=0.2, eps=0.5)
    p3, m3, tp, mt = (np.asarray(v) for v in (p3, m3, tp, mt))
    if not (np.all(np.isfinite(p3)) and np.all((p3 >= -1e-9) & (p3 <= box + 1e-9))):
        return False, "positions must stay in the box"
    if np.abs(m3.sum(0)).max() > 1e-8 * np.abs(m3).sum():
        return False, f"total momentum should stay zero: {np.abs(m3.sum(0)).max():.2e}"
    disp = np.abs(wrap(p3 - pos, box)).max()
    dif = np.abs(wrap(p3 - tp, box)).max()
    if not dif < 0.02 * disp + 1e-9:
        return False, f"P3M and TreePM (theta = 0.2) runs should agree: max position difference {dif:.3g} vs displacement {disp:.3g}"
    zel = np.asarray(C.zeldovich_ics(psi, box, 0.12)[0])
    dz = np.abs(wrap(p3 - zel, box)).max() / disp
    if dz > 0.2:
        return False, f"at early times the run must follow the Zel'dovich solution: deviation {100 * dz:.0f}% of the displacement (expected ~10%); check kick/drift factors and G"
    tp15 = np.asarray(H.evolve_hybrid(pos, mom, 0.05, 0.12, 4, box, 16, method="treepm", theta=1.5, eps=0.5)[0])
    if np.abs(wrap(tp15 - p3, box)).max() < 1e-6 * disp:
        return False, "method='treepm' must use the tree force (a wide opening angle changes the result slightly)"
    pe = np.asarray(H.evolve_hybrid(pos, mom, 0.05, 0.12, 4, box, 16, method="p3m", eps=6.0)[0])
    return bool(np.abs(wrap(pe - p3, box)).max() > 0.02 * disp), "eps must be passed to the short-range force (a large softening must change the result)"


def t_evolve_pancake():
    box, n = 100.0, 16
    x = np.arange(n) * box / n
    X = np.meshgrid(x, x, x, indexing="ij")[0]
    kw = 2 * np.pi / box
    psi = np.asarray(C.displacement_field(0.6 * np.cos(kw * X + 0.7), box))
    pos, mom = C.zeldovich_ics(psi, box, 0.05, 1.0, 0.0)
    p, _ = H.evolve_hybrid(np.asarray(pos), np.asarray(mom), 0.05, 0.5, 12, box, 32, 1.0, 0.0, "p3m", 0.5, 0.5)
    q = np.stack(np.meshgrid(x, x, x, indexing="ij"), -1).reshape(-1, 3)
    disp = wrap(np.asarray(p) - q, box)
    ana = 0.5 * psi.reshape(3, -1).T
    amp = (disp[:, 0] * ana[:, 0]).sum() / (ana[:, 0] ** 2).sum()
    return bool(0.98 < amp < 1.02), f"Einstein-de Sitter plane wave (Zel'dovich pancake), a = 0.05 -> 0.5: the displacement should grow by D(0.5)/D(0.05); fitted amplitude ratio {amp:.3f} (expected ~0.994); check the kick/drift factors of both half steps"


check("8.1 split function S(r): values and scaling", t_split_values)
check("8.1 S(r) is the force of the erfc potential", t_split_identity)
check("8.2 mesh force: momentum, periodicity, G", t_long_basic)
check("8.2 mesh force = Ewald minus short range (TSC, CIC)", t_long_pairs)
check("8.3 chaining mesh finds exactly the pairs of a brute-force search", t_find_pairs)
check("8.3 short-range sum vs brute force, Newton's third law", t_pp_force)
check("8.3 short-range sum speed", t_pp_speed)
check("8.3 P3M vs Ewald, clustered particles (TSC)", t_p3m_ewald_tsc)
check("8.3 P3M vs Ewald (CIC)", t_p3m_ewald_cic)
check("8.3 P3M vs Ewald on a 64^3 mesh (default r_s, r_cut)", t_p3m_ewald_64)
check("8.3 P3M pair forces across the split", t_p3m_pairs)
check("8.3 P3M periodicity, G, softening, momentum", t_p3m_invariance)
check("8.4 TreePM reproduces P3M for small theta", t_treepm_vs_p3m)
check("8.4 TreePM accuracy vs Ewald and vs theta", t_treepm_ewald)
check("8.4 tree short-range vs brute force with softening", t_tree_eps)
check("8.4 TreePM needs fewer interactions than the pair sum in clumps", t_treepm_cost)
check("8.5 comoving P3M / TreePM leapfrog", t_evolve)
check("8.5 P3M run reproduces the Zel'dovich pancake (EdS)", t_evolve_pancake)

print(f"\n{sum(results)}/{len(results)} checks passed")
sys.exit(0 if all(results) else 1)
