"""HW8 skeleton. Copy to myOwnCode/L08/hybrid.py and fill in.

Periodic cube of side `box`, softened Newtonian gravity, Gaussian force split with scale rs:
    long range (mesh):   density -> exp(-k^2 rs^2) -> Poisson -> force
    short range (pairs): F = G m / r^2 * S(r), S(r) = erfc(r/2rs) + r/(rs sqrt(pi)) exp(-r^2/4rs^2), zero beyond rcut
Uses YOUR pm.py (L06), tree.py (L04) and cosmo.py (L07).
"""
import math  # noqa: F401
import sys
from pathlib import Path

import numpy as np

_p = Path(__file__).resolve().parents[1]
for _d in ("L06", "L04", "L07"):
    sys.path.append(str(_p / _d))
import pm  # noqa: E402,F401
import tree as T  # noqa: E402,F401
import cosmo as C  # noqa: E402,F401   (kick_factor, drift_factor, H0 for evolve_hybrid)


# ---- 8.1 the split ----
def short_range_factor(r, rs):
    """S(r) for scalar or array r. numpy has no erfc: use math.erfc (np.frompyfunc) or a table + np.interp."""
    raise NotImplementedError


# ---- 8.2 mesh force ----
def long_range_acceleration(pos, mass, G, box, ngrid, rs, scheme="tsc", deriv="fd4", deconvolve=True):
    """Mesh part: assign, multiply rho_k by exp(-k^2 rs^2) [/ W^2 if deconvolve], Poisson, gradient, interpolate."""
    raise NotImplementedError


# ---- 8.3 short-range sum with a chaining mesh ----
def find_pairs(pos, box, rcut):
    """All pairs closer than rcut (periodic, minimum image), each pair once.

    -> i, j (index arrays) and d = pos[j] - pos[i] wrapped to the minimum image, shape (P, 3).
    Cells at least rcut wide; cells per axis may be < 3 (beware of counting a pair twice).
    """
    raise NotImplementedError


def short_range_pp(pos, mass, G, eps, box, rs, rcut):
    """-> acc (N,3): sum over pairs within rcut of G m_j S(r) d / (r^2 + eps^2)^(3/2), Newton's third law."""
    raise NotImplementedError


def p3m_acceleration(pos, mass, G=1.0, eps=0.0, box=1.0, ngrid=32, rs=None, rcut=None, scheme="tsc", deriv="fd4"):
    """Defaults: rs = 1.25 box/ngrid, rcut = 4.5 rs. Positions may lie outside the box."""
    raise NotImplementedError


# ---- 8.4 TreePM ----
def tree_short_range(pos, mass, G, eps, box, rs, rcut, theta=0.5, root=None, stats=None):
    """Short-range force from your Lecture 4 tree: skip cells entirely beyond rcut, minimum image, S(r) on every
    interaction. stats["interactions"] counts interactions as in Lecture 4."""
    raise NotImplementedError


def treepm_acceleration(pos, mass, G=1.0, eps=0.0, box=1.0, ngrid=32, theta=0.5, rs=None, rcut=None,
                        scheme="tsc", deriv="fd4", stats=None):
    raise NotImplementedError


# ---- 8.5 comoving run ----
def evolve_hybrid(pos, mom, a_start, a_end, nsteps, box, ngrid, Om=0.3, OL=0.7, method="p3m", theta=0.5, eps=0.0):
    """Your Lecture 7 KDK in ln a with unit-mass particles, but with the P3M ("p3m") or TreePM ("treepm") force; eps is the softening."""
    raise NotImplementedError
