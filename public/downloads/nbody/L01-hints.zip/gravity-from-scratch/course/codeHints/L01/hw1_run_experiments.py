"""HW1 experiment scaffold. Copy to myOwnCode/L01/ next to direct.py.

Initial conditions and plotting are given; the time loop is yours.
"""
import time
import numpy as np
import matplotlib.pyplot as plt

from direct import acceleration, total_energy, euler_step  # your code


def circular_orbit():
    """Two unit masses, d = 1, G = 1. Returns pos, vel, mass, period."""
    v = np.sqrt(0.5)
    pos = np.array([[-0.5, 0, 0], [0.5, 0, 0]])
    vel = np.array([[0, -v, 0], [0, v, 0]])
    return pos, vel, np.ones(2), np.pi * np.sqrt(2)


def figure_eight():
    """Three unit masses, G = 1. Returns pos, vel, mass, period."""
    r1 = np.array([0.97000436, -0.24308753, 0.0])
    v3 = np.array([-0.93240737, -0.86473146, 0.0])
    pos = np.array([r1, -r1, np.zeros(3)])
    vel = np.array([-v3 / 2, -v3 / 2, v3])
    return pos, vel, np.ones(3), 6.32591398


def run(pos, vel, mass, dt, n_steps):
    """Return trajectory (n_steps+1, N, 3) and final (pos, vel)."""
    # TODO: loop n_steps times with euler_step, store positions
    raise NotImplementedError


def plot_orbit(traj, ax, title=""):
    for k in range(traj.shape[1]):
        ax.plot(traj[:, k, 0], traj[:, k, 1], lw=0.8)
    ax.set_aspect("equal")
    ax.set(title=title, xlabel="x", ylabel="y")


if __name__ == "__main__":
    # HW 1.4: energy error vs dt (log-log)
    # TODO
    # HW 1.5: figure-8 with 2000 and 20000 steps, two panels
    # TODO
    # HW 1.6: time acceleration() for N = 60, 120, 240; fit slope
    # TODO (use time.perf_counter, keep the best of a few runs)
    plt.show()
