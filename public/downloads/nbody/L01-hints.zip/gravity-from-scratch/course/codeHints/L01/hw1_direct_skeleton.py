"""HW1 skeleton. Copy to myOwnCode/L01/direct.py and fill in.

Rules: loops over particles i and j; no vectorising over particles yet.
See lecture 1.
"""
import numpy as np


def acceleration(pos, mass, G=1.0, eps=0.0):
    """pos (N,3), mass (N,) -> acc (N,3) NumPy array. Softened."""
    # TODO 1: acc = zeros (N,3)
    # TODO 2: for each i, sum over j != i
    # TODO 3: add each pair's contribution to acc[i]
    raise NotImplementedError


def kinetic_energy(vel, mass):
    """-> float."""
    raise NotImplementedError


def potential_energy(pos, mass, G=1.0, eps=0.0):
    """-> float. Each pair once (i < j), softened."""
    raise NotImplementedError


def total_energy(pos, vel, mass, G=1.0, eps=0.0):
    """-> float."""
    raise NotImplementedError


def euler_step(pos, vel, mass, dt, G=1.0, eps=0.0):
    """-> (new_pos, new_vel). Do not modify pos or vel."""
    raise NotImplementedError
