"""Checker for HW1. Run from the project folder:

    python course/codeHints/L01/check_hw1.py [folder_with_direct.py]

Default folder: myOwnCode/L01. Prints PASS/FAIL per task.
"""
import sys
import time
from pathlib import Path

import numpy as np

root = Path(__file__).resolve().parents[3]
folder = Path(sys.argv[1]) if len(sys.argv) > 1 else root / "myOwnCode" / "L01"
sys.path.insert(0, str(folder))

results = []


def check(name, fn):
    try:
        ok, msg = fn()
    except NotImplementedError:
        ok, msg = False, "not implemented yet"
    except Exception as e:  # noqa: BLE001
        ok, msg = False, f"{type(e).__name__}: {e}"
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"   <- {msg}"))


try:
    import direct as d
except ImportError as e:
    sys.exit(f"Cannot import direct.py from {folder}: {e}")

f8_pos = np.array([[0.97000436, -0.24308753, 0], [-0.97000436, 0.24308753, 0], [0, 0, 0]])
_v3 = np.array([-0.93240737, -0.86473146, 0])
f8_vel = np.array([-_v3 / 2, -_v3 / 2, _v3])
F8_T = 6.32591398
CIRC_POS = np.array([[-0.5, 0, 0], [0.5, 0, 0]])
CIRC_VEL = np.array([[0, -np.sqrt(0.5), 0], [0, np.sqrt(0.5), 0]])
CIRC_T = np.pi * np.sqrt(2)


def run_euler(pos, vel, mass, dt, n):
    pos, vel = np.array(pos, dtype=float), np.array(vel, dtype=float)
    for _ in range(n):
        pos, vel = d.euler_step(pos.copy(), vel.copy(), mass, dt)
        pos, vel = np.asarray(pos, dtype=float), np.asarray(vel, dtype=float)
    return pos, vel


# ---------------- 1.1 acceleration ----------------
def t_two_body():
    a = np.asarray(d.acceleration(np.array([[0., 0, 0], [1, 0, 0]]), np.ones(2)))
    ok = a.shape == (2, 3) and np.allclose(a, [[1, 0, 0], [-1, 0, 0]])
    return ok, f"expected [[1,0,0],[-1,0,0]], got {a.tolist()}"


def t_softened():
    a = np.asarray(d.acceleration(np.array([[0., 0, 0], [1, 0, 0]]), np.ones(2), 1.0, 0.5))
    exp = np.array([[1.25 ** -1.5, 0, 0], [-1.25 ** -1.5, 0, 0]])
    return a.shape == (2, 3) and np.allclose(a, exp), f"expected 0.7155 along x (opposite signs), got {a.tolist()}"


def t_single():
    a = np.asarray(d.acceleration(np.zeros((1, 3)), np.ones(1), 1.0, 0.1))
    return np.allclose(a, 0), f"single particle must feel 0, got {a.tolist()}"


def t_coincident():
    a = np.asarray(d.acceleration(np.zeros((2, 3)), np.ones(2), 1.0, 0.1))
    return np.all(np.isfinite(a)) and np.allclose(a, 0), f"got {a.tolist()}"


def t_collinear():
    pos = np.array([[0., 0, 0], [1, 0, 0], [3, 0, 0]])
    a = np.asarray(d.acceleration(pos, np.array([1., 2, 3])))[:, 0]
    exp = [2 + 3 / 9, -1 + 3 / 4, -1 / 9 - 2 / 4]
    return np.allclose(a, exp), f"expected {np.round(exp, 4).tolist()}, got {np.round(a, 4).tolist()}"


def t_momentum():
    rng = np.random.default_rng(3)
    pos, m = rng.random((8, 3)), rng.random(8) + 0.5
    a = np.asarray(d.acceleration(pos, m, 1.0, 0.05))
    p = (m[:, None] * a).sum(axis=0)
    scale = np.abs(m[:, None] * a).max()
    return np.allclose(p, 0, atol=1e-6 * scale), f"sum m*a should be 0 (vector), got {p}"


def t_symmetries():
    rng = np.random.default_rng(5)
    pos, m = rng.random((6, 3)), rng.random(6) + 0.5
    a = np.asarray(d.acceleration(pos, m, 1.0, 0.1))
    th = 0.5
    R = np.array([[np.cos(th), -np.sin(th), 0], [np.sin(th), np.cos(th), 0], [0, 0, 1]])
    a_rot = np.asarray(d.acceleration(pos @ R.T, m, 1.0, 0.1))
    ok_rot = np.allclose(a_rot, a @ R.T)
    ok_G = np.allclose(d.acceleration(pos, m, 2.0, 0.1), 2 * a)
    ok_m = np.allclose(d.acceleration(pos, 2 * m, 1.0, 0.1), 2 * a)
    ok_scale = np.allclose(d.acceleration(2 * pos, m, 1.0, 0.2), a / 4)
    ok = ok_rot and ok_G and ok_m and ok_scale
    return ok, f"rotation:{ok_rot} G:{ok_G} mass:{ok_m} length-scaling:{ok_scale}"


def t_no_mutation():
    pos, m = np.random.default_rng(1).random((4, 3)), np.ones(4)
    p0, m0 = pos.copy(), m.copy()
    d.acceleration(pos, m)
    return np.array_equal(pos, p0) and np.array_equal(m, m0), "acceleration changed its inputs"


# ---------------- 1.2 energies ----------------
def t_kinetic():
    k = d.kinetic_energy(np.array([[1., 2, 2]]), np.array([2.0]))
    return np.isclose(k, 9.0), f"expected 9, got {k}"


def t_potential():
    two = d.potential_energy(np.array([[0., 0, 0], [2, 0, 0]]), np.ones(2))
    soft = d.potential_energy(np.array([[0., 0, 0], [2, 0, 0]]), np.ones(2), 1.0, 1.5)
    three = d.potential_energy(np.array([[0., 0, 0], [1, 0, 0], [3, 0, 0]]), np.array([1., 2, 3]))
    ok = np.isclose(two, -0.5) and np.isclose(soft, -0.4) and np.isclose(three, -6.0)
    return ok, f"expected -0.5, -0.4, -6 ; got {two}, {soft}, {three}"


def t_total():
    e1 = d.total_energy(CIRC_POS, CIRC_VEL, np.ones(2))
    e2 = d.total_energy(f8_pos, f8_vel, np.ones(3))
    return np.isclose(e1, -0.5) and np.isclose(e2, -1.28714, atol=2e-5), f"got {e1}, {e2}"


# ---------------- 1.3 Euler step ----------------
def t_euler():
    pos, vel, m = np.array([[0., 0, 0], [1, 0, 0]]), np.array([[0., 1, 0], [0, -1, 0]]), np.ones(2)
    p0, v0 = pos.copy(), vel.copy()
    p1, v1 = d.euler_step(pos, vel, m, 0.1)
    p1, v1 = np.asarray(p1), np.asarray(v1)
    exp_p = p0 + 0.1 * v0                       # moved with the OLD velocity
    exp_v = v0 + 0.1 * np.array([[1., 0, 0], [-1, 0, 0]])
    if not (np.array_equal(pos, p0) and np.array_equal(vel, v0)):
        return False, "euler_step modified its input arrays"
    return np.allclose(p1, exp_p) and np.allclose(v1, exp_v), "new_pos = pos + vel*dt and new_vel = vel + acc*dt, both from the OLD state"


# ---------------- 1.4 circular orbit ----------------
def circ_err(n):
    p, v = run_euler(CIRC_POS, CIRC_VEL, np.ones(2), CIRC_T / n, n)
    return abs(d.total_energy(p, v, np.ones(2)) + 0.5) / 0.5, np.linalg.norm(p[1] - p[0])


def t_circ():
    e1, sep = circ_err(2000)
    ok = 0.02 < e1 < 0.06 and abs(sep - 1) < 0.06
    return ok, f"with dt=T/2000, after one orbit expected dE/E ~3.7% and separation ~1.04; got {e1:.3%}, {sep:.3f}"


def t_order():
    e1, e2 = circ_err(1000)[0], circ_err(2000)[0]
    return 1.6 < e1 / e2 < 2.4, f"halving dt should halve the error (first order); ratio {e1 / e2:.2f}"


# ---------------- 1.5 figure-8 ----------------
def t_fig8():
    m = np.ones(3)
    p, v = run_euler(f8_pos, f8_vel, m, F8_T / 20000, 20000)
    dev = np.abs(p - f8_pos).max()
    ok = dev < 0.1 and np.allclose((m[:, None] * v).sum(axis=0), 0, atol=1e-8)
    return ok, f"20000 Euler steps: expected start-return within 0.1 (about 0.04); got {dev:.3f}"


# ---------------- 1.6 scaling ----------------
def t_scaling():
    rng, Ns, ts = np.random.default_rng(0), [60, 120, 240], []
    for N in Ns:
        pos, m, best = rng.random((N, 3)), np.ones(N), 1e9
        for _ in range(2):
            t0 = time.perf_counter()
            d.acceleration(pos, m, 1.0, 0.05)
            best = min(best, time.perf_counter() - t0)
        ts.append(best)
    s = np.polyfit(np.log(Ns), np.log(ts), 1)[0]
    return 1.6 < s < 2.5, f"log-log slope {s:.2f}, expected ~2 with loops only, no vectorising (timing is noisy: re-run once)"


check("1.1 two-body acceleration = 1", t_two_body)
check("1.1 softened acceleration = 0.7155", t_softened)
check("1.1 single particle: no self-force", t_single)
check("1.1 coincident particles: finite, zero", t_coincident)
check("1.1 three collinear masses (hand-worked)", t_collinear)
check("1.1 momentum: sum m*a = 0", t_momentum)
check("1.1 rotation / G / mass / length scaling", t_symmetries)
check("1.1 inputs not modified", t_no_mutation)
check("1.2 kinetic energy", t_kinetic)
check("1.2 potential energy (each pair once, softened)", t_potential)
check("1.2 total energy of circular orbit and figure-8", t_total)
check("1.3 Euler step", t_euler)
check("1.4 circular orbit: energy error and separation", t_circ)
check("1.4 error is first order in dt", t_order)
check("1.5 figure-8 recovers with 20000 steps", t_fig8)
check("1.6 cost scales as N^2", t_scaling)

print(f"\n{sum(results)}/{len(results)} checks passed")
sys.exit(0 if all(results) else 1)
