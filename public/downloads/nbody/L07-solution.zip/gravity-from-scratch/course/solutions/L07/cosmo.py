"""Reference solution, Lecture 7: cosmological PM N-body in a periodic box.

Units: comoving length in Mpc/h, H0 = 100 (so velocities are in km/s),
time in (Mpc/h)/(km/s).  Flat LCDM: H(a) = H0 sqrt(Om a^-3 + OL).
Canonical momentum p = a^2 dx/dt (x comoving), peculiar velocity v = p/a.
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "L06"))
import pm  # noqa: E402  (the learner uses their own L06 pm.py)

H0 = 100.0


# ---------------- 7.1 background ----------------
def hubble(a, Om=0.3, OL=0.7):
    a = np.asarray(a, dtype=float)
    return H0 * np.sqrt(Om * a**-3 + OL + (1 - Om - OL) * a**-2)


def growth_factor(a, Om=0.3, OL=0.7):
    """Linear growth D(a), normalised to D(1)=1 (flat cosmologies).
    D ~ H(a) * int_0^a da'/(a' H(a'))^3."""
    def raw(a_):
        x = np.linspace(0.0, a_, 4001)[1:]
        x = np.concatenate([[x[0] * 1e-3], x])
        y = 1.0 / (x * hubble(x, Om, OL)) ** 3
        y[0] = 0.0
        return hubble(a_, Om, OL) * np.trapezoid(y, x)
    a = np.atleast_1d(np.asarray(a, dtype=float))
    out = np.array([raw(ai) for ai in a]) / raw(1.0)
    return out if out.size > 1 else float(out[0])


def growth_rate(a, Om=0.3, OL=0.7):
    """f = dlnD/dlna by a centred difference in ln a."""
    e = 1e-3
    lo, hi = a * np.exp(-e), a * np.exp(e)
    return (np.log(growth_factor(hi, Om, OL)) - np.log(growth_factor(lo, Om, OL))) / (2 * e)


def _integral(fun, a0, a1, n=2000):
    x = np.linspace(a0, a1, n + 1)
    return np.trapezoid(fun(x), x)


def kick_factor(a0, a1, Om=0.3, OL=0.7):
    """int dt/a = int da / (a^2 H)."""
    return _integral(lambda a: 1.0 / (a**2 * hubble(a, Om, OL)), a0, a1)


def drift_factor(a0, a1, Om=0.3, OL=0.7):
    """int dt/a^2 = int da / (a^3 H)."""
    return _integral(lambda a: 1.0 / (a**3 * hubble(a, Om, OL)), a0, a1)


# ---------------- 7.2 Gaussian random field and P(k) ----------------
def bbks_pk(k, sigma8=0.8, ns=0.96, Om=0.3, h=0.7, box_for_norm=None):
    """BBKS linear power spectrum at z=0, normalised to sigma8 (k in h/Mpc)."""
    def raw(k):
        q = k / (Om * h)
        T = np.log(1 + 2.34 * q) / (2.34 * q) * (1 + 3.89 * q + (16.1 * q) ** 2 + (5.46 * q) ** 3 + (6.71 * q) ** 4) ** -0.25
        return k**ns * T**2
    kk = np.geomspace(1e-4, 1e2, 20000)
    x = kk * 8.0
    W = 3 * (np.sin(x) - x * np.cos(x)) / x**3
    s2 = np.trapezoid(raw(kk) * W**2 * kk**2, kk) / (2 * np.pi**2)
    return raw(k) * sigma8**2 / s2


def kgrid(n, box):
    k1 = 2 * np.pi * np.fft.fftfreq(n, d=box / n)
    return np.meshgrid(k1, k1, k1, indexing="ij")


def gaussian_field(n, box, pk, seed=0):
    """Real Gaussian field delta(x) with power spectrum pk(k); zero mean."""
    rng = np.random.default_rng(seed)
    w = rng.standard_normal((n, n, n))
    kx, ky, kz = kgrid(n, box)
    k = np.sqrt(kx**2 + ky**2 + kz**2)
    k[0, 0, 0] = 1.0
    amp = np.sqrt(pk(k) * n**3 / box**3)
    amp[0, 0, 0] = 0.0
    return np.fft.ifftn(np.fft.fftn(w) * amp).real


def measure_pk(delta, box, nbins=None):
    """Shell-averaged P(k) of a real field on an n^3 grid (no window correction)."""
    n = delta.shape[0]
    dk = np.fft.fftn(delta)
    p3 = np.abs(dk) ** 2 * box**3 / n**6
    kx, ky, kz = kgrid(n, box)
    k = np.sqrt(kx**2 + ky**2 + kz**2)
    kf = 2 * np.pi / box
    idx = np.rint(k / kf).astype(int)
    nb = n // 2
    sel = (idx >= 1) & (idx <= nb)
    cnt = np.bincount(idx[sel], minlength=nb + 1)
    ps = np.bincount(idx[sel], weights=p3[sel], minlength=nb + 1)
    ks = np.bincount(idx[sel], weights=k[sel], minlength=nb + 1)
    ok = cnt > 0
    return ks[ok] / cnt[ok], ps[ok] / cnt[ok], cnt[ok]


def particle_pk(pos, box, n, scheme="cic", shot=False):
    """P(k) of a particle set: CIC density, window deconvolved.
    shot=True subtracts V/N (only sensible for Poisson-like particle sets, NOT for a lattice)."""
    rho = pm.assign_density(pos, np.ones(len(pos)), n, box, scheme)
    delta = rho / rho.mean() - 1.0
    kx, ky, kz = kgrid(n, box)
    h = box / n
    w = np.ones_like(kx)
    p = {"ngp": 1, "cic": 2, "tsc": 3}[scheme]
    for kk in (kx, ky, kz):
        w = w * np.sinc(kk * h / (2 * np.pi)) ** p
    dk = np.fft.fftn(delta) / w
    p3 = np.abs(dk) ** 2 * box**3 / n**6 - (box**3 / len(pos) if shot else 0.0)
    k = np.sqrt(kx**2 + ky**2 + kz**2)
    kf = 2 * np.pi / box
    idx = np.rint(k / kf).astype(int)
    nb = n // 2
    sel = (idx >= 1) & (idx <= nb)
    cnt = np.bincount(idx[sel], minlength=nb + 1)
    ps = np.bincount(idx[sel], weights=p3[sel], minlength=nb + 1)
    ks = np.bincount(idx[sel], weights=k[sel], minlength=nb + 1)
    ok = cnt > 0
    return ks[ok] / cnt[ok], ps[ok] / cnt[ok]


# ---------------- 7.3 Zel'dovich initial conditions ----------------
def displacement_field(delta0, box):
    """psi with -div psi = delta0: psi_k = i k delta_k / k^2. Shape (3,n,n,n)."""
    n = delta0.shape[0]
    kv = kgrid(n, box)
    k2 = kv[0] ** 2 + kv[1] ** 2 + kv[2] ** 2
    k2[0, 0, 0] = 1.0
    dk = np.fft.fftn(delta0)
    out = []
    for kk in kv:
        c = 1j * kk * dk / k2
        c[0, 0, 0] = 0.0
        if n % 2 == 0:
            c[n // 2, :, :] = 0.0
            c[:, n // 2, :] = 0.0
            c[:, :, n // 2] = 0.0
        out.append(np.fft.ifftn(c).real)
    return np.array(out)


def zeldovich_ics(psi, box, a, Om=0.3, OL=0.7):
    """Particles on a lattice displaced by D(a) psi; p = a^2 H f D psi."""
    n = psi.shape[1]
    q1 = (np.arange(n) + 0.0) * box / n
    q = np.stack(np.meshgrid(q1, q1, q1, indexing="ij"), axis=-1).reshape(-1, 3)
    D = growth_factor(a, Om, OL)
    f = growth_rate(a, Om, OL)
    psi_flat = psi.reshape(3, -1).T
    pos = (q + D * psi_flat) % box
    mom = a**2 * hubble(a, Om, OL) * f * D * psi_flat
    return pos, mom


# ---------------- 7.4 evolution in an expanding background ----------------
def comoving_accel(pos, box, ngrid, Om, scheme="cic", deriv="fd4"):
    """g = -grad(phi), del^2 phi = (3/2) Om H0^2 delta  (the 1/a is in the kick factor)."""
    N = len(pos)
    G = 3 * Om * H0**2 * box**3 / (8 * np.pi * N)
    return pm.pm_acceleration(pos, np.ones(N), G, 0.0, box, ngrid, scheme, deriv)


def evolve(pos, mom, a_start, a_end, nsteps, box, ngrid, Om=0.3, OL=0.7):
    """KDK leapfrog in ln a steps. Returns pos, mom."""
    ae = np.geomspace(a_start, a_end, nsteps + 1)
    pos, mom = pos.copy(), mom.copy()
    for a0, a1 in zip(ae[:-1], ae[1:]):
        am = np.sqrt(a0 * a1)
        mom += comoving_accel(pos, box, ngrid, Om) * kick_factor(a0, am, Om, OL)
        pos = (pos + mom * drift_factor(a0, a1, Om, OL)) % box
        mom += comoving_accel(pos, box, ngrid, Om) * kick_factor(am, a1, Om, OL)
    return pos, mom


# ---------------- 7.6 friends-of-friends ----------------
def friends_of_friends(pos, box, link):
    """Group labels (0..Ngroups-1) for particles closer than `link` (periodic)."""
    N = len(pos)
    nc = max(1, min(int(box / link), int(round(N ** (1 / 3)))))   # cell >= link, ~1 particle per cell
    cs = box / nc
    c = np.floor((pos % box) / cs).astype(int) % nc
    flat = (c[:, 0] * nc + c[:, 1]) * nc + c[:, 2]
    order = np.argsort(flat, kind="stable")
    fs = flat[order]
    start = np.searchsorted(fs, np.arange(nc**3))
    end = np.searchsorted(fs, np.arange(nc**3), side="right")
    cnt = end - start
    ii, jj = [], []
    offs = [(dx, dy, dz) for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1)]
    cells = np.arange(nc**3)
    cx, cy, cz = cells // (nc * nc), (cells // nc) % nc, cells % nc
    for dx, dy, dz in offs:
        nb = (((cx + dx) % nc) * nc + (cy + dy) % nc) * nc + (cz + dz) % nc
        if nc < 3 and (dx, dy, dz) != (0, 0, 0):
            pass
        # all (particle in cell, particle in neighbour cell) pairs, vectorised per offset
        n1, n2 = cnt, cnt[nb]
        npair = n1 * n2
        tot = npair.sum()
        if tot == 0:
            continue
        cell_of = np.repeat(cells, npair)
        local = np.arange(tot) - np.repeat(np.cumsum(npair) - npair, npair)
        n2r = n2[cell_of]
        a = order[start[cell_of] + local // np.maximum(n2r, 1)]
        b = order[start[nb[cell_of]] + local % np.maximum(n2r, 1)]
        keep = a < b
        a, b = a[keep], b[keep]
        d = pos[a] - pos[b]
        d -= box * np.rint(d / box)
        m = (d * d).sum(axis=1) < link * link
        ii.append(a[m])
        jj.append(b[m])
    if ii:
        ii, jj = np.concatenate(ii), np.concatenate(jj)
    else:
        ii = jj = np.array([], dtype=int)
    lab = np.arange(N)
    while True:
        m = np.minimum(lab[ii], lab[jj])
        new = lab.copy()
        np.minimum.at(new, ii, m)
        np.minimum.at(new, jj, m)
        new = new[new]
        if np.array_equal(new, lab):
            break
        lab = new
    _, lab = np.unique(lab, return_inverse=True)
    return lab
