"""Reference solution (held back until the learner passes)."""
import numpy as np


def acceleration(pos, mass, G=1.0, eps=0.0):
    N = len(mass)
    acc = np.zeros((N, 3))
    for i in range(N):
        for j in range(N):
            if i == j:
                continue
            d = np.zeros(3)
            r2 = eps**2
            for k in range(3):
                d[k] = pos[j, k] - pos[i, k]
                r2 += d[k] ** 2
            f = G * mass[j] / r2 ** 1.5
            for k in range(3):
                acc[i, k] += f * d[k]
    return acc


def kinetic_energy(vel, mass):
    ke = 0.0
    for i in range(len(mass)):
        ke += 0.5 * mass[i] * sum(vel[i, k] ** 2 for k in range(3))
    return ke


def potential_energy(pos, mass, G=1.0, eps=0.0):
    pe = 0.0
    N = len(mass)
    for i in range(N):
        for j in range(i + 1, N):
            r2 = eps**2 + sum((pos[j, k] - pos[i, k]) ** 2 for k in range(3))
            pe -= G * mass[i] * mass[j] / np.sqrt(r2)
    return pe


def total_energy(pos, vel, mass, G=1.0, eps=0.0):
    return kinetic_energy(vel, mass) + potential_energy(pos, mass, G, eps)


def euler_step(pos, vel, mass, dt, G=1.0, eps=0.0):
    acc = acceleration(pos, mass, G, eps)
    pos_new = pos + vel * dt
    vel_new = vel + acc * dt
    return pos_new, vel_new
