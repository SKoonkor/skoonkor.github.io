"""Checker for HW3. Run from the project folder:

    python course/codeHints/L03/check_hw3.py [--l01 DIR] [--l03 DIR]

Defaults: myOwnCode/L01 (direct.py) and myOwnCode/L03 (vectorised.py).
"""
import argparse
import sys
import time
import tracemalloc
from pathlib import Path

import numpy as np

root = Path(__file__).resolve().parents[3]
ap = argparse.ArgumentParser()
ap.add_argument("--l01", default=str(root / "myOwnCode" / "L01"))
ap.add_argument("--l03", default=str(root / "myOwnCode" / "L03"))
args = ap.parse_args()
sys.path.insert(0, args.l01)
sys.path.insert(0, args.l03)

results = []


def check(name, fn):
    try:
        ok, msg = fn()
    except NotImplementedError:
        ok, msg = False, "not implemented yet"
    except Exception as e:  # noqa: BLE001
        ok, msg = False, f"{type(e).__name__}: {e}"
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"   <- {msg}"))


try:
    import vectorised as v
except ImportError as e:
    sys.exit(f"Cannot import vectorised.py from {args.l03}: {e}")
try:
    import direct as loop
except ImportError:
    loop = None
    print("note: L01 direct.py not found; loop comparisons are skipped")

COLL = (np.array([[0., 0, 0], [1, 0, 0], [3, 0, 0]]), np.array([1., 2, 3]))


def rand_system(N, seed):
    rng = np.random.default_rng(seed)
    return rng.random((N, 3)), rng.random(N) + 0.5


# ---------------- 3.1 acceleration ----------------
def t_two_body():
    a = np.asarray(v.acceleration_np(np.array([[0., 0, 0], [1, 0, 0]]), np.ones(2)))
    return a.shape == (2, 3) and np.allclose(a, [[1, 0, 0], [-1, 0, 0]]), f"expected [[1,0,0],[-1,0,0]], got {a.tolist()}"


def t_collinear():
    a = np.asarray(v.acceleration_np(*COLL))[:, 0]
    exp = [2 + 3 / 9, -1 + 3 / 4, -1 / 9 - 2 / 4]
    return np.allclose(a, exp), f"expected {np.round(exp, 4).tolist()}, got {np.round(a, 4).tolist()}"


def t_no_nan():
    pos, m = rand_system(20, 0)
    a = np.asarray(v.acceleration_np(pos, m, 1.0, 0.0))
    b = np.asarray(v.acceleration_np(pos[:1], m[:1], 1.0, 0.1))
    return bool(np.all(np.isfinite(a)) and np.allclose(b, 0)), "eps=0 must not give nan/inf on the diagonal; one particle feels no force"


def t_vs_loop():
    if loop is None:
        return True, ""
    pos, m = rand_system(60, 1)
    worst = 0.0
    for G, eps in ((1.0, 0.0), (2.0, 0.1)):
        ref = np.asarray(loop.acceleration(pos, m, G, eps))
        worst = max(worst, np.abs(np.asarray(v.acceleration_np(pos, m, G, eps)) - ref).max() / np.abs(ref).max())
    return worst < 1e-10, f"differs from your loop version by relative {worst:.1e}"


def t_symmetries():
    pos, m = rand_system(15, 2)
    a = np.asarray(v.acceleration_np(pos, m, 1.0, 0.1))
    p = (m[:, None] * a).sum(axis=0)
    ok = (np.allclose(p, 0, atol=1e-10 * np.abs(a).max())
          and np.allclose(v.acceleration_np(pos, m, 2.0, 0.1), 2 * a)
          and np.allclose(v.acceleration_np(pos, 2 * m, 1.0, 0.1), 2 * a))
    return ok, "sum m*a should vanish and the result should scale with G and with mass"


def t_no_mutation():
    pos, m = rand_system(10, 3)
    p0, m0 = pos.copy(), m.copy()
    v.acceleration_np(pos, m, 1.0, 0.1)
    return np.array_equal(pos, p0) and np.array_equal(m, m0), "acceleration_np changed its inputs"


# ---------------- 3.2 energies ----------------
def t_energies():
    k = v.kinetic_energy_np(np.array([[1., 2, 2]]), np.array([2.0]))
    u3 = v.potential_energy_np(*COLL)
    u2 = v.potential_energy_np(np.array([[0., 0, 0], [2, 0, 0]]), np.ones(2), 1.0, 1.5)
    ok = np.isclose(k, 9) and np.isclose(u3, -6) and np.isclose(u2, -0.4)
    return ok, f"expected 9, -6, -0.4; got {k}, {u3}, {u2}"


def t_energy_vs_loop():
    if loop is None:
        return True, ""
    pos, m = rand_system(40, 4)
    vel = np.random.default_rng(5).normal(size=(40, 3))
    a = v.total_energy_np(pos, vel, m, 1.5, 0.05)
    b = loop.total_energy(pos, vel, m, 1.5, 0.05)
    return np.isclose(a, b, rtol=1e-10), f"total energy {a} vs your loop version {b}"


# ---------------- 3.3 chunking ----------------
def t_chunk_same():
    pos, m = rand_system(53, 6)
    ref = np.asarray(v.acceleration_np(pos, m, 1.3, 0.05))
    worst = max(np.abs(np.asarray(v.acceleration_chunked(pos, m, 1.3, 0.05, c)) - ref).max() for c in (1, 7, 53, 100))
    return worst < 1e-10, f"chunked result differs from full by {worst:.1e} (try chunk sizes that do not divide N)"


def t_chunk_memory():
    pos, m = rand_system(2000, 7)
    tracemalloc.start()
    v.acceleration_chunked(pos, m, 1.0, 0.05, 100)
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    full = 2000 * 2000 * 3 * 8
    return peak < 0.5 * full, f"peak memory {peak / 1e6:.0f} MB; an (N,N,3) array is {full / 1e6:.0f} MB, expected well below half of that"


# ---------------- 3.4 speed ----------------
def t_speed():
    if loop is None:
        return True, ""
    pos, m = rand_system(300, 8)
    t_loop = t_np = 1e9
    for _ in range(2):
        t0 = time.perf_counter(); loop.acceleration(pos, m, 1.0, 0.05); t_loop = min(t_loop, time.perf_counter() - t0)
        t0 = time.perf_counter(); v.acceleration_np(pos, m, 1.0, 0.05); t_np = min(t_np, time.perf_counter() - t0)
    return t_loop / t_np > 3, f"N=300: loops {t_loop:.3f}s, NumPy {t_np:.4f}s, speed-up {t_loop / t_np:.1f}x (a vectorised force should be several times faster than per-pair loops; is there a Python loop over particles?)"


# ---------------- 3.5 Plummer sphere ----------------
def t_plummer_basic():
    pos, vel, m = v.plummer_sphere(1000, a=1.0, seed=1)
    pos, vel, m = np.asarray(pos), np.asarray(vel), np.asarray(m)
    com = np.average(pos, axis=0, weights=m)
    comv = np.average(vel, axis=0, weights=m)
    ok = (pos.shape == (1000, 3) and vel.shape == (1000, 3) and m.shape == (1000,) and np.isclose(m.sum(), 1.0)
          and np.abs(com).max() < 1e-10 and np.abs(comv).max() < 1e-10)
    return ok, "shapes (N,3),(N,3),(N,); total mass 1; centre of mass and its velocity zero"


def t_plummer_seed():
    p1 = v.plummer_sphere(100, seed=3)[0]
    p2 = v.plummer_sphere(100, seed=3)[0]
    p3 = v.plummer_sphere(100, seed=4)[0]
    return np.array_equal(p1, p2) and not np.allclose(p1, p3), "same seed must give the same sphere; different seeds different ones"


def t_plummer_radii():
    a = 2.0
    pos, _, m = v.plummer_sphere(20000, a=a, seed=11)
    pos = np.asarray(pos)
    r = np.linalg.norm(pos - np.median(pos, axis=0), axis=1)   # robust to the long tail
    half = np.median(r)
    frac = np.mean(r < a)
    ok = abs(half / (1.3048 * a) - 1) < 0.04 and abs(frac - 2 ** -1.5) < 0.02
    return ok, f"a=2: half-mass radius {half:.3f} (expect 2.61), fraction inside r=a {frac:.3f} (expect 0.354)"


def t_plummer_virial():
    pos, vel, m = v.plummer_sphere(4000, a=2.0, seed=12)
    q = 2 * v.kinetic_energy_np(vel, m) / abs(v.potential_energy_np(pos, m))
    return 0.95 < q < 1.05, f"virial ratio 2K/|U| = {q:.3f}, expected 1.00 +- 0.03"


def t_plummer_bound():
    pos, vel, m = v.plummer_sphere(4000, a=2.0, seed=13)
    r = np.linalg.norm(pos, axis=1)
    speed = np.linalg.norm(vel, axis=1)
    vesc = np.sqrt(2.0) * (r**2 + 4.0) ** -0.25
    return bool(np.all(speed < vesc * 1.001)), f"largest v/v_esc = {(speed / vesc).max():.3f}; every particle must be bound (v < v_esc)"


def t_isotropy():
    pos, vel, m = v.plummer_sphere(20000, a=1.0, seed=15)
    up, _, _ = v.uniform_sphere(20000, 1.0, seed=16)
    fp = np.mean(np.abs(pos[:, 2]) / np.linalg.norm(pos, axis=1))
    fv = np.mean(np.abs(vel[:, 2]) / np.linalg.norm(vel, axis=1))
    fu = np.mean(np.abs(up[:, 2]) / np.linalg.norm(up, axis=1))
    ok = all(abs(x - 0.5) < 0.02 for x in (fp, fv, fu))
    return ok, (f"mean |z|/r should be 0.5 for isotropic directions; got positions {fp:.3f}, velocities {fv:.3f}, uniform sphere {fu:.3f} "
                "(uniform theta crowds the poles: use cos(theta) uniform in [-1,1])")


def t_G_M():
    pos, vel, m = v.plummer_sphere(3000, a=1.5, seed=17, G=2.0, M=3.0)
    r = np.linalg.norm(pos, axis=1)
    speed = np.linalg.norm(vel, axis=1)
    vesc = np.sqrt(2 * 2.0 * 3.0) * (r**2 + 1.5**2) ** -0.25
    _, _, mu = v.uniform_sphere(100, R=1.0, seed=1, M=3.0)
    q = 2 * v.kinetic_energy_np(vel, m) / abs(v.potential_energy_np(pos, m, 2.0))
    ok = np.isclose(np.sum(m), 3.0) and np.all(speed < vesc * 1.001) and np.isclose(np.sum(mu), 3.0) and 0.9 < q < 1.1
    return ok, f"with G=2, M=3: total mass must be 3 (both samplers), speeds below sqrt(2GM)(r^2+a^2)^(-1/4), and 2K/|U| = {q:.2f} must be about 1"


def t_uniform():
    pos, vel, m = v.uniform_sphere(20000, R=2.0, seed=1)
    r = np.linalg.norm(pos, axis=1)
    ok = r.max() <= 2.0 + 1e-12 and abs(np.median(r) / (2.0 * 0.5 ** (1 / 3)) - 1) < 0.03 and np.allclose(vel, 0) and np.isclose(np.sum(m), 1.0)
    return ok, f"uniform sphere R=2: max radius {r.max():.3f}, half-mass radius {np.median(r):.3f} (expect 1.587), zero velocities, total mass 1"


# ---------------- 3.6 Lagrangian radii and evolve ----------------
def t_lagrangian():
    pos = np.array([[1., 0, 0], [-1, 0, 0], [0, 2, 0], [0, -2, 0]])
    m = np.ones(4)
    got = np.asarray(v.lagrangian_radii(pos + 5.0, m, (0.3, 0.6, 0.9)))
    pp, _, mm = v.plummer_sphere(20000, a=1.0, seed=14)
    keep = np.linalg.norm(pp, axis=1) < np.percentile(np.linalg.norm(pp, axis=1), 99.9)   # drop the extreme tail
    pp, mm = pp[keep], mm[keep]
    lr = np.asarray(v.lagrangian_radii(pp, mm, (0.1, 0.5, 0.9)))
    exp = 1 / np.sqrt(np.array([0.1, 0.5, 0.9]) ** (-2 / 3) - 1)
    ok = np.allclose(got, [1, 2, 2]) and np.all(np.abs(lr / exp - 1) < 0.06)
    return ok, f"toy case expected [1,2,2] (radius of the smallest set of particles, ordered by radius, holding at least that mass fraction), got {got.tolist()}; Plummer radii {lr.round(3).tolist()} vs analytic {exp.round(3).tolist()}"


def t_evolve_force_used():
    pos, vel = np.array([[0., 0, 0], [1, 0, 0]]), np.array([[1., 0, 0], [0, 2, 0]])
    m = np.ones(2)
    p, w = v.evolve_kdk(pos, vel, m, 0.1, 10, 1.0, 0.0, force=lambda p, m, G, e: np.zeros_like(p))
    ok = np.allclose(p, pos + vel * 1.0) and np.allclose(w, vel)
    return ok, "with a zero force the particles must drift in straight lines: pos + vel*n*dt (is the 'force' argument used?)"


def t_evolve_no_mutation():
    pos, vel, m = v.plummer_sphere(30, seed=1)
    p0, v0 = pos.copy(), vel.copy()
    v.evolve_kdk(pos, vel, m, 0.01, 3, 1.0, 0.1)
    return np.array_equal(pos, p0) and np.array_equal(vel, v0), "evolve_kdk changed its inputs"


def t_evolve_reversible():
    pos, vel, m = v.plummer_sphere(30, seed=2)
    p, w = v.evolve_kdk(pos, vel, m, 0.01, 100, 1.0, 0.1)
    p2, _ = v.evolve_kdk(p, -w, m, 0.01, 100, 1.0, 0.1)
    dev = np.abs(p2 - pos).max()
    return dev < 1e-9, f"forward, flip velocities, forward again should return to the start; off by {dev:.1e}"


# ---------------- 3.7 equilibrium ----------------
def t_equilibrium():
    N, eps, dt = 300, 0.05, 0.01
    pos, vel, m = v.plummer_sphere(N, a=1.0, seed=21)
    E0 = v.total_energy_np(pos, vel, m, 1.0, eps)
    r0 = np.asarray(v.lagrangian_radii(pos, m, (0.5,)))[0]
    p, w = v.evolve_kdk(pos, vel, m, dt, 1000, 1.0, eps)
    E1 = v.total_energy_np(p, w, m, 1.0, eps)
    r1 = np.asarray(v.lagrangian_radii(p, m, (0.5,)))[0]
    q = 2 * v.kinetic_energy_np(w, m) / abs(v.potential_energy_np(p, m, 1.0, eps))
    ok = abs((E1 - E0) / E0) < 1e-3 and 0.75 < r1 / r0 < 1.4 and 0.85 < q < 1.15
    return ok, (f"after t=10: dE/E {abs((E1 - E0) / E0):.1e} (expect about 1e-5), half-mass radius ratio {r1 / r0:.2f} (expect 0.8-1.3; it depends on the random sample), "
                f"2K/|U| {q:.2f} (expect ~0.95-1.05)")


# ---------------- 3.8 cold collapse ----------------
def t_cold_collapse():
    N, eps, dt = 300, 0.05, 0.01
    pos, vel, m = v.uniform_sphere(N, 1.0, seed=31)
    E0 = v.total_energy_np(pos, vel, m, 1.0, eps)
    ts, rh, q = [], [], []
    p, w = pos, vel
    for k in range(40):
        p, w = v.evolve_kdk(p, w, m, dt, 10, 1.0, eps)
        ts.append(0.1 * (k + 1))
        rh.append(np.asarray(v.lagrangian_radii(p, m, (0.5,)))[0])
        q.append(2 * v.kinetic_energy_np(w, m) / abs(v.potential_energy_np(p, m, 1.0, eps)))
    ts, rh, q = np.array(ts), np.array(rh), np.array(q)
    t_min = ts[rh.argmin()]
    late = q[ts > 3].mean()
    ok = 0.9 <= t_min <= 1.5 and rh.min() < 0.2 and 0.8 < late < 1.4
    return ok, (f"smallest half-mass radius {rh.min():.3f} at t={t_min:.1f} (expect ~0.08 near t_ff=1.11); "
                f"mean 2K/|U| for t>3: {late:.2f} (expect ~1.1)")


check("3.1 two-body acceleration", t_two_body)
check("3.1 three collinear masses (hand-worked)", t_collinear)
check("3.1 no NaN at eps=0; single particle", t_no_nan)
check("3.1 agrees with your loop version (L01)", t_vs_loop)
check("3.1 momentum, G and mass scaling", t_symmetries)
check("3.1 inputs not modified", t_no_mutation)
check("3.2 kinetic and potential energy", t_energies)
check("3.2 total energy agrees with your loop version", t_energy_vs_loop)
check("3.3 chunked result equals full", t_chunk_same)
check("3.3 chunked version uses little memory", t_chunk_memory)
check("3.4 speed-up over loops", t_speed)
check("3.5 Plummer: shapes, mass, centre of mass", t_plummer_basic)
check("3.5 Plummer: seed reproducibility", t_plummer_seed)
check("3.5 Plummer: radial distribution", t_plummer_radii)
check("3.5 Plummer: virial ratio", t_plummer_virial)
check("3.5 Plummer: all particles bound", t_plummer_bound)
check("3.5 directions are isotropic", t_isotropy)
check("3.5 samplers respect G and M", t_G_M)
check("3.5 uniform sphere", t_uniform)
check("3.6 Lagrangian radii", t_lagrangian)
check("3.6 evolve_kdk uses the given force", t_evolve_force_used)
check("3.6 evolve_kdk does not modify inputs", t_evolve_no_mutation)
check("3.6 evolve_kdk is time-reversible", t_evolve_reversible)
check("3.7 Plummer sphere stays in equilibrium", t_equilibrium)
check("3.8 cold collapse", t_cold_collapse)

print(f"\n{sum(results)}/{len(results)} checks passed")
sys.exit(0 if all(results) else 1)
