"""HW3 skeleton. Copy to myOwnCode/L03/vectorised.py and fill in.

No Python loops over particles in the force and energy functions.
"""
import numpy as np


def acceleration_np(pos, mass, G=1.0, eps=0.0):
    """pos (N,3), mass (N,) -> acc (N,3). Softened; no self-force; no NaN at eps=0."""
    raise NotImplementedError


def kinetic_energy_np(vel, mass):
    raise NotImplementedError


def potential_energy_np(pos, mass, G=1.0, eps=0.0):
    """Each pair once, softened."""
    raise NotImplementedError


def total_energy_np(pos, vel, mass, G=1.0, eps=0.0):
    raise NotImplementedError


def acceleration_chunked(pos, mass, G=1.0, eps=0.0, chunk=100):
    """Same result as acceleration_np; never builds an (N,N,3) array."""
    raise NotImplementedError


def plummer_sphere(N, a=1.0, seed=None, G=1.0, M=1.0):
    """-> pos (N,3), vel (N,3), mass (N,), each mass M/N. Centre of mass at rest at the origin."""
    raise NotImplementedError


def uniform_sphere(N, R=1.0, seed=None, M=1.0):
    """Uniform density, zero velocities. -> pos, vel, mass."""
    raise NotImplementedError


def lagrangian_radii(pos, mass, fractions=(0.1, 0.25, 0.5, 0.75, 0.9)):
    """Radius (about the centre of mass) of the smallest set of particles, ordered by radius,
    holding at least each mass fraction."""
    raise NotImplementedError


def evolve_kdk(pos, vel, mass, dt, n_steps, G=1.0, eps=0.0, force=acceleration_np):
    """Leapfrog KDK for n_steps -> (pos, vel) at the end. Inputs unchanged.

    force(pos, mass, G, eps) -> acc (N,3): any force with this signature can be passed in.
    """
    raise NotImplementedError
