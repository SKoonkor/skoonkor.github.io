"""HW3 experiment scaffold. Copy to myOwnCode/L03/ next to vectorised.py."""
import sys
import time
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

sys.path.append(str(Path(__file__).resolve().parent.parent / "L01"))
import direct  # your L01 loop code
from vectorised import (acceleration_np, acceleration_chunked, plummer_sphere,  # noqa: F401
                        uniform_sphere, lagrangian_radii, evolve_kdk,
                        kinetic_energy_np, potential_energy_np, total_energy_np)


def best_time(fn, repeats=3):
    """Smallest wall time of fn() over a few repeats (seconds)."""
    best = 1e9
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best


def virial_ratio(pos, vel, mass, eps):
    K = kinetic_energy_np(vel, mass)
    U = potential_energy_np(pos, mass, 1.0, eps)
    return 2 * K / abs(U)


if __name__ == "__main__":
    # HW 3.4: time direct.acceleration vs acceleration_np, N = 25 ... 400
    # TODO
    # HW 3.4: peak memory of full vs chunked force (tracemalloc), N = 2000
    # TODO
    # HW 3.7: Plummer N = 500, a = 1, eps = 0.05, dt = 0.01, t = 10
    #         record lagrangian_radii and the virial ratio every 0.25
    # TODO
    # HW 3.8: uniform sphere collapse, dt = 0.01 and 0.002
    # TODO
    plt.show()
