"""HW7 skeleton. Copy to myOwnCode/L07/cosmo.py and fill in.

Units: comoving length in Mpc/h, H0 = 100 (velocities in km/s), flat LCDM.
Canonical momentum p = a^2 dx/dt; particle index = flattened lattice index (i, j, k) in C order.
Uses YOUR Lecture 6 pm.py (pm_acceleration, assign_density).
"""
import sys
from pathlib import Path

import numpy as np

sys.path.append(str(Path(__file__).resolve().parents[1] / "L06"))   # finds myOwnCode/L06/pm.py
import pm  # noqa: E402

H0 = 100.0


# ---- given: the BBKS linear spectrum, normalised to sigma8 at z = 0 (k in h/Mpc) ----
def bbks_pk(k, sigma8=0.8, ns=0.96, Om=0.3, h=0.7):
    def raw(k):
        q = k / (Om * h)
        T = np.log(1 + 2.34 * q) / (2.34 * q) * (1 + 3.89 * q + (16.1 * q) ** 2 + (5.46 * q) ** 3 + (6.71 * q) ** 4) ** -0.25
        return k**ns * T**2
    kk = np.geomspace(1e-4, 1e2, 20000)
    x = kk * 8.0
    W = 3 * (np.sin(x) - x * np.cos(x)) / x**3
    s2 = np.trapezoid(raw(kk) * W**2 * kk**2, kk) / (2 * np.pi**2)
    return raw(k) * sigma8**2 / s2


# ---- 7.1 background ----
def hubble(a, Om=0.3, OL=0.7):
    """H(a) for flat LCDM, in km/s per Mpc/h."""
    raise NotImplementedError


def growth_factor(a, Om=0.3, OL=0.7):
    """D(a) with D(1) = 1; accepts a scalar or an array."""
    raise NotImplementedError


def growth_rate(a, Om=0.3, OL=0.7):
    """f = dlnD/dlna."""
    raise NotImplementedError


def kick_factor(a0, a1, Om=0.3, OL=0.7):
    """integral of dt/a from a0 to a1."""
    raise NotImplementedError


def drift_factor(a0, a1, Om=0.3, OL=0.7):
    """integral of dt/a^2 from a0 to a1."""
    raise NotImplementedError


# ---- 7.2 Gaussian random field and P(k) ----
def gaussian_field(n, box, pk, seed=0):
    """Real n^3 field whose (unnormalised) FFT obeys <|delta_m|^2> = n^6 P(k) / V; zero mean; pk is a function of |k|."""
    raise NotImplementedError


def measure_pk(delta, box):
    """Shell-averaged P(k) of a real n^3 field. Shell m = k in [(m-1/2) kf, (m+1/2) kf), m = 1..n/2.

    -> k (mean |k| per shell), P (and optionally the mode counts as a third value).
    """
    raise NotImplementedError


# ---- 7.3 Zel'dovich initial conditions ----
def displacement_field(delta0, box):
    """psi (3, n, n, n) with -div psi = delta0 (Nyquist planes zeroed)."""
    raise NotImplementedError


def zeldovich_ics(psi, box, a, Om=0.3, OL=0.7):
    """Lattice q = (i, j, k) box/n displaced by D(a) psi; momentum a^2 H f D psi. -> pos (N,3), mom (N,3)."""
    raise NotImplementedError


# ---- 7.4 evolution ----
def evolve(pos, mom, a_start, a_end, nsteps, box, ngrid, Om=0.3, OL=0.7):
    """KDK leapfrog with nsteps steps equally spaced in ln a; force from pm.pm_acceleration.

    Choose G for the PM call as explained in Lecture 7, Section 5; use CIC and the four-point gradient. -> pos, mom.
    """
    raise NotImplementedError


# ---- 7.5 P(k) of particles ----
def particle_pk(pos, box, n):
    """P(k) of a particle set on an n^3 grid: CIC density, divide by the CIC window, shell-average.

    Do not subtract shot noise. -> k, P.
    """
    raise NotImplementedError


# ---- 7.6 friends-of-friends ----
def friends_of_friends(pos, box, link):
    """Group label per particle (periodic box); particles closer than `link` (transitively) share a label."""
    raise NotImplementedError
