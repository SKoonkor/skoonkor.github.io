"""Checker for HW7. Run from the project folder:

    python course/codeHints/L07/check_hw7.py [--l06 DIR] [--l07 DIR]

Defaults: myOwnCode/L06 (pm.py) and myOwnCode/L07 (cosmo.py).
"""
import argparse
import sys
import time
from pathlib import Path

import numpy as np

root_dir = Path(__file__).resolve().parents[3]
ap = argparse.ArgumentParser()
ap.add_argument("--l06", default=str(root_dir / "myOwnCode" / "L06"))
ap.add_argument("--l07", default=str(root_dir / "myOwnCode" / "L07"))
args = ap.parse_args()
sys.path.insert(0, args.l07)
sys.path.insert(0, args.l06)

results = []


def check(name, fn):
    try:
        ok, msg = fn()
    except NotImplementedError:
        ok, msg = False, "not implemented yet"
    except Exception as e:  # noqa: BLE001
        ok, msg = False, f"{type(e).__name__}: {e}"
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"   <- {msg}"))


try:
    import pm  # noqa: F401
except ImportError as e:
    sys.exit(f"Cannot import your Lecture 6 pm.py from {args.l06}: {e}")
try:
    import cosmo as C
except ImportError as e:
    sys.exit(f"Cannot import cosmo.py from {args.l07}: {e}")

H0 = 100.0


# ---------------- reference helpers written independently of the learner ----------------
def ode_growth(a_targets, Om=0.3):
    """Solve D'' + (2 + dlnH/dlna) D' - 1.5 Om(a) D = 0 in x = ln a (RK4), return D(a)/D(1), f(a)."""
    OL = 1 - Om
    E2 = lambda a: Om * a**-3 + OL                                    # noqa: E731
    dlnH = lambda a: -1.5 * Om * a**-3 / E2(a)                        # noqa: E731
    Oma = lambda a: Om * a**-3 / E2(a)                                # noqa: E731

    def rhs(x, y):
        a = np.exp(x)
        return np.array([y[1], -(2 + dlnH(a)) * y[1] + 1.5 * Oma(a) * y[0]])

    x0 = np.log(1e-3)
    y = np.array([1e-3, 1e-3])                                        # matter era: D = a
    xs = np.linspace(x0, 0, 6001)
    dx = xs[1] - xs[0]
    D, Dp = [y[0]], [y[1]]
    for x in xs[:-1]:
        k1 = rhs(x, y); k2 = rhs(x + dx / 2, y + dx / 2 * k1); k3 = rhs(x + dx / 2, y + dx / 2 * k2); k4 = rhs(x + dx, y + dx * k3)  # noqa: E702
        y = y + dx / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        D.append(y[0]); Dp.append(y[1])                               # noqa: E702
    D, Dp = np.array(D), np.array(Dp)
    Dn = D / D[-1]
    at = np.log(np.asarray(a_targets))
    return np.interp(at, xs, Dn), np.interp(at, xs, Dp / D)


def shell_pk_reference(delta, box):
    n = delta.shape[0]
    k1 = 2 * np.pi * np.fft.fftfreq(n, d=box / n)
    kx, ky, kz = np.meshgrid(k1, k1, k1, indexing="ij")
    k = np.sqrt(kx**2 + ky**2 + kz**2)
    idx = np.rint(k / (2 * np.pi / box)).astype(int)
    p3 = np.abs(np.fft.fftn(delta)) ** 2 * box**3 / n**6
    sel = (idx >= 1) & (idx <= n // 2)
    cnt = np.bincount(idx[sel], minlength=n // 2 + 1)
    ps = np.bincount(idx[sel], weights=p3[sel], minlength=n // 2 + 1)
    return np.arange(1, n // 2 + 1) * 2 * np.pi / box, ps[1:] / cnt[1:], cnt[1:]


def shell_mean_of(pk, n, box):
    """Mean of pk(|k|) over the modes of each shell m = 1..n/2 (what a correct P(k) estimate converges to)."""
    k1 = 2 * np.pi * np.fft.fftfreq(n, d=box / n)
    kx, ky, kz = np.meshgrid(k1, k1, k1, indexing="ij")
    k = np.sqrt(kx**2 + ky**2 + kz**2)
    idx = np.rint(k / (2 * np.pi / box)).astype(int)
    kk = np.where(idx >= 1, k, 1.0)
    pv = pk(kk)
    sel = (idx >= 1) & (idx <= n // 2)
    return np.bincount(idx[sel], weights=pv[sel], minlength=n // 2 + 1)[1:] / np.bincount(idx[sel], minlength=n // 2 + 1)[1:]


def ref_gaussian(n, box, pk, seed):
    """Checker's own Gaussian field (so these tests do not depend on your random-number stream)."""
    w = np.random.default_rng(seed).standard_normal((n, n, n))
    k1 = 2 * np.pi * np.fft.fftfreq(n, d=box / n)
    kx, ky, kz = np.meshgrid(k1, k1, k1, indexing="ij")
    k = np.sqrt(kx**2 + ky**2 + kz**2)
    k[0, 0, 0] = 1.0
    amp = np.sqrt(pk(k) * n**3 / box**3)
    amp[0, 0, 0] = 0.0
    return np.fft.ifftn(np.fft.fftn(w) * amp).real


def bbks(k, sigma8=0.8, ns=0.96, Om=0.3, h=0.7):
    def raw(k):
        q = k / (Om * h)
        T = np.log(1 + 2.34 * q) / (2.34 * q) * (1 + 3.89 * q + (16.1 * q) ** 2 + (5.46 * q) ** 3 + (6.71 * q) ** 4) ** -0.25
        return k**ns * T**2
    kk = np.geomspace(1e-4, 1e2, 20000)
    x = kk * 8.0
    W = 3 * (np.sin(x) - x * np.cos(x)) / x**3
    return raw(k) * sigma8**2 / (np.trapezoid(raw(kk) * W**2 * kk**2, kk) / (2 * np.pi**2))


def lattice(n, box):
    q1 = np.arange(n) * box / n
    return np.stack(np.meshgrid(q1, q1, q1, indexing="ij"), axis=-1).reshape(-1, 3)


def wrap_diff(d, box):
    return d - box * np.rint(d / box)


# ---------------- 7.1 background ----------------
def t_hubble():
    a = np.array([0.25, 0.5, 1.0])
    h1 = np.asarray(C.hubble(a, 1.0, 0.0))
    h2 = np.asarray(C.hubble(a, 0.3, 0.7))
    e2 = np.asarray(C.hubble(0.5))
    ok = np.allclose(h1, H0 * a**-1.5) and np.allclose(h2, H0 * np.sqrt(0.3 * a**-3 + 0.7)) and np.isclose(e2, h2[1])
    return bool(ok), "H(a) = H0 sqrt(Om a^-3 + OL), H0 = 100; defaults Om = 0.3, OL = 0.7"


def t_growth():
    a = np.array([0.1, 0.3, 0.7, 1.0])
    d_eds = np.asarray(C.growth_factor(a, 1.0, 0.0))
    if not np.allclose(d_eds, a, rtol=2e-3):
        return False, f"Einstein-de Sitter must give D = a, got {d_eds}"
    D = np.asarray(C.growth_factor(a))
    Dr, _ = ode_growth(a)
    if not np.allclose(D, Dr, rtol=5e-3):
        return False, f"LCDM D(a) = {D.round(4)} but the ODE gives {Dr.round(4)} (D(1) = 1)"
    if not np.isclose(float(C.growth_factor(1.0)), 1.0, atol=1e-6):
        return False, "D(1) must be 1"
    return True, ""


def t_growth_rate():
    a = np.array([0.1, 0.3, 0.6, 1.0])
    f = np.array([float(C.growth_rate(x)) for x in a])
    _, fr = ode_growth(a)
    ok = np.allclose(f, fr, atol=0.01) and np.isclose(float(C.growth_rate(0.2, 1.0, 0.0)), 1.0, atol=0.01)
    return bool(ok), f"f = dlnD/dlna: expected {fr.round(3)} (LCDM), got {f.round(3)}; EdS gives 1"


def t_factors():
    a0, a1, a2 = 0.2, 0.45, 0.6
    kick = float(C.kick_factor(a0, a2, 1.0, 0.0))
    drift = float(C.drift_factor(a0, a2, 1.0, 0.0))
    k_ex = 2 * (np.sqrt(a2) - np.sqrt(a0)) / H0
    d_ex = 2 * (a0**-0.5 - a2**-0.5) / H0
    if not (np.isclose(kick, k_ex, rtol=1e-4) and np.isclose(drift, d_ex, rtol=1e-4)):
        return False, f"EdS: kick {kick:.6g} vs {k_ex:.6g} (int da/(a^2 H)); drift {drift:.6g} vs {d_ex:.6g} (int da/(a^3 H))"
    add = np.isclose(C.kick_factor(a0, a1) + C.kick_factor(a1, a2), C.kick_factor(a0, a2), rtol=1e-4) and \
        np.isclose(C.drift_factor(a0, a1) + C.drift_factor(a1, a2), C.drift_factor(a0, a2), rtol=1e-4)
    return bool(add), "factors must be additive over sub-intervals (integrate accurately enough: relative error below 1e-4)"


# ---------------- 7.2 Gaussian field and P(k) ----------------
def t_gaussian_basic():
    n, box = 16, 40.0
    pk = lambda k: 10.0 / (1 + k**2)                                   # noqa: E731
    d = np.asarray(C.gaussian_field(n, box, pk, 5))
    d2 = np.asarray(C.gaussian_field(n, box, pk, 5))
    d3 = np.asarray(C.gaussian_field(n, box, pk, 6))
    if d.shape != (n, n, n) or np.iscomplexobj(d):
        return False, "must return a real (n, n, n) array"
    if abs(d.mean()) > 1e-10:
        return False, "the k = 0 mode must be zero (mean delta = 0)"
    return bool(np.array_equal(d, d2) and not np.allclose(d, d3)), "same seed -> same field; different seed -> different field"


def t_gaussian_power():
    n = 32
    cases = [(64.0, lambda k: 200.0 / (1 + (k / 0.5) ** 2) ** 1.5), (150.0, lambda k: 30.0 * k**-1.0)]
    for box, pk in cases:
        acc_r, acc_c = 0.0, 0.0
        for s in range(6):
            d = np.asarray(C.gaussian_field(n, box, pk, 100 + s))
            kk, P, cnt = shell_pk_reference(d, box)
            acc_r = acc_r + P * cnt
            acc_c = acc_c + cnt
        P = acc_r / acc_c
        ratio = P / shell_mean_of(pk, n, box)
        lo, hi = ratio[2:7].mean(), ratio[8:15].mean()                # shells 3-7 and 9-15 (many modes)
        if not (0.94 < lo < 1.06 and 0.94 < hi < 1.06):
            return False, f"box {box}: measured/input P(k) = {lo:.2f} (low k), {hi:.2f} (high k); expected 1 +- 0.06. Check the n^3/V normalisation"
    return True, ""


def t_measure_pk():
    n, box = 32, 60.0
    rng = np.random.default_rng(3)
    sig = 0.7
    w = rng.normal(0, sig, (n, n, n))
    out = C.measure_pk(w, box)
    k, P = np.asarray(out[0]), np.asarray(out[1])
    if len(k) != n // 2:
        return False, f"expected {n // 2} shells (m = 1..n/2), got {len(k)}"
    exp = sig**2 * (box / n) ** 3
    if not (0.96 < P.mean() / exp < 1.04) or P.std() / exp > 0.2:
        return False, f"white noise: P should be flat at sigma^2 (V/N) = {exp:.4g}; got mean {P.mean():.4g}"
    kf = 2 * np.pi / box
    if not (np.all(np.diff(k) > 0) and 0.9 * kf < k[0] < 1.4 * kf and 2.5 * kf < k[2] < 3.6 * kf):
        return False, "the k returned for shell m should be the mean |k| of its modes, close to m * 2 pi / box"
    x = np.arange(n) * box / n
    X = np.meshgrid(x, x, x, indexing="ij")[0]
    out = C.measure_pk(np.cos(2 * np.pi * 3 * X / box), box)
    P3 = np.asarray(out[1])
    if not (P3.argmax() == 2 and np.delete(P3, 2).max() < 1e-12 * P3.max()):
        return False, "a single cosine of wavenumber 3 k_f must show up only in shell 3"
    return True, ""


# ---------------- 7.3 Zel'dovich ICs ----------------
def t_displacement():
    n, box = 16, 30.0
    x = np.arange(n) * box / n
    X, Y, Z = np.meshgrid(x, x, x, indexing="ij")
    kf = 2 * np.pi / box
    d = 1.5 * np.cos(2 * kf * X)
    psi = np.asarray(C.displacement_field(d, box))
    if psi.shape != (3, n, n, n):
        return False, "shape must be (3, n, n, n)"
    if not (np.abs(psi[0] + 1.5 * np.sin(2 * kf * X) / (2 * kf)).max() < 1e-9 and np.abs(psi[1]).max() < 1e-9 and np.abs(psi[2]).max() < 1e-9):
        return False, "for delta = A cos(kx): psi_x = -(A/k) sin(kx) (so that -div psi = delta), psi_y = psi_z = 0"
    d2 = np.cos(kf * (X + 2 * Y)) + 0.5 * np.sin(3 * kf * Z)
    p2 = np.asarray(C.displacement_field(d2, box))
    k1 = 2 * np.pi * np.fft.fftfreq(n, d=box / n)
    kv = np.meshgrid(k1, k1, k1, indexing="ij")
    div = sum(np.fft.ifftn(1j * kv[i] * np.fft.fftn(p2[i])).real for i in range(3))
    return bool(np.abs(-div - d2).max() < 1e-9), "-div psi must reproduce delta0 for a multi-mode field"


def t_ics():
    n, box, a = 8, 24.0, 0.1
    psi = np.zeros((3, n, n, n))
    pos, mom = C.zeldovich_ics(psi, box, a, 1.0, 0.0)
    pos, mom = np.asarray(pos), np.asarray(mom)
    q = lattice(n, box)
    if pos.shape != (n**3, 3) or not np.allclose(pos % box, q % box) or np.abs(mom).max() > 1e-12:
        return False, "psi = 0 gives the lattice q = (i, j, k) box/n, index = C-order flatten of (i, j, k), and zero momentum"
    rng = np.random.default_rng(0)
    psi = rng.normal(0, 0.3, (3, n, n, n))
    pos, mom = C.zeldovich_ics(psi, box, a, 1.0, 0.0)
    pos, mom = np.asarray(pos), np.asarray(mom)
    D, f, H = a, 1.0, H0 * a**-1.5
    pe = (q + D * psi.reshape(3, -1).T) % box
    me = a**2 * H * f * D * psi.reshape(3, -1).T
    if not np.allclose(wrap_diff(pos - pe, box), 0, atol=1e-9):
        return False, "positions: q + D(a) psi (wrapped into the box)"
    if not np.allclose(mom, me, rtol=2e-3, atol=1e-9):
        return False, "momentum: a^2 H(a) f(a) D(a) psi  (p = a^2 dx/dt, dx/dt = H f D psi)"
    # LCDM: momentum needs the true growth rate f(a) (not 1)
    a2 = 0.5
    Dr, fr = ode_growth([a2])
    pos_l, mom_l = C.zeldovich_ics(psi, box, a2)
    me2 = a2**2 * H0 * np.sqrt(0.3 * a2**-3 + 0.7) * fr[0] * Dr[0] * psi.reshape(3, -1).T
    if not np.allclose(np.asarray(mom_l), me2, rtol=0.03, atol=1e-9):
        return False, "LCDM at a = 0.5: momentum a^2 H f D psi with f = dlnD/dlna (about 0.87 there)"
    pos2, _ = C.zeldovich_ics(psi, box, 0.5)
    return bool(np.all((np.asarray(pos2) >= -1e-9) & (np.asarray(pos2) <= box + 1e-9))), "positions must lie in [0, box)"


# ---------------- 7.4 evolution ----------------
def pancake(nsteps=40, npart=32, ngrid=64, a_end=0.5, A=1.0):
    box = 100.0
    x = np.arange(npart) * box / npart
    X = np.meshgrid(x, x, x, indexing="ij")[0]
    kw = 2 * np.pi / box
    psi = np.asarray(C.displacement_field(A * np.cos(kw * X + 0.7), box))   # phase: particles cross the box edge
    pos, mom = C.zeldovich_ics(psi, box, 0.02, 1.0, 0.0)
    pos, mom = C.evolve(np.asarray(pos), np.asarray(mom), 0.02, a_end, nsteps, box, ngrid, 1.0, 0.0)
    q = lattice(npart, box)
    disp = wrap_diff(np.asarray(pos) - q, box)
    ana = a_end * psi.reshape(3, -1).T
    return box, kw, q, np.asarray(pos), np.asarray(mom), disp, ana


def t_pancake():
    box, kw, q, pos, mom, disp, ana = pancake()
    if not np.all((pos >= -1e-9) & (pos <= box + 1e-9)):
        return False, "evolve must return positions inside the box [0, box)"
    amp_ratio = (disp[:, 0] * ana[:, 0]).sum() / (ana[:, 0] ** 2).sum()
    dev = np.abs(disp - ana).max() / np.abs(ana).max()
    if not (0.965 < amp_ratio < 1.03):
        return False, f"Zel'dovich pancake (EdS, a = 0.02 -> 0.5): the displacement should grow by D(0.5)/D(0.02); amplitude ratio {amp_ratio:.3f} (expect ~0.99)"
    return bool(dev < 0.12), f"largest deviation from the Zel'dovich solution is {100 * dev:.1f}% of the displacement (expect ~5%)"


def t_conservation_steps():
    box, kw, q, pos, mom, disp, ana = pancake(nsteps=40)
    _, _, _, pos20, mom20, disp20, _ = pancake(nsteps=20)
    if np.abs(disp[:, 1:]).max() > 1e-6 * box:
        return False, "planar wave: no motion should appear in y and z (symmetry) -> check the force components/axes"
    pm_tot = np.abs(mom.sum(axis=0)).max() / np.abs(mom).sum(axis=0).max() if False else np.abs(mom.sum(axis=0)).max()
    scale = np.abs(mom[:, 0]).max() * len(mom)
    if pm_tot > 1e-9 * scale:
        return False, f"total momentum should stay zero: {pm_tot:.2e}"
    d = np.abs(disp - disp20).max() / np.abs(ana).max()
    return bool(d < 0.02), f"results must be converged in the step count (20 vs 40 steps differ by {100 * d:.1f}% of the displacement; steps uniform in ln a, KDK with CIC + four-point gradient)"


def t_lcdm_growth():
    n, ng, box = 32, 64, 100.0
    d0 = ref_gaussian(n, box, bbks, 6)                                   # fixed linear field
    kr, Pr, _ = shell_pk_reference(d0, box)
    psi = C.displacement_field(d0, box)
    pos, mom = C.zeldovich_ics(psi, box, 0.02)
    pos, mom = C.evolve(pos, mom, 0.02, 0.1, 15, box, ng)
    pos, mom = C.evolve(pos, mom, 0.1, 0.2, 12, box, ng)
    kk, P = (np.asarray(v) for v in C.particle_pk(pos, box, ng)[:2])
    ratio = P[:4] / (Pr[:4] * float(C.growth_factor(0.2)) ** 2)
    good = 0.93 < ratio.mean() < 1.07 and np.all((0.85 < ratio) & (ratio < 1.15))
    return bool(good), f"linear growth: P(k, a=0.2) / (D^2 P_linear) should be ~1 at the lowest k; got {ratio.round(2)} (shells 1-4)"


# ---------------- 7.5 P(k) of particles ----------------
def t_particle_pk():
    n, box, N = 32, 80.0, 200000
    exp = box**3 / N
    cnt = shell_pk_reference(np.random.default_rng(0).normal(size=(n, n, n)), box)[2]
    tot = 0.0
    for sd in (4, 5, 6):
        pos = np.random.default_rng(sd).random((N, 3)) * box
        kk, P = (np.asarray(v) for v in C.particle_pk(pos, box, n)[:2])
        lowk = kk < 0.35 * np.pi * n / box
        tot += (P[lowk] * cnt[lowk]).sum() / cnt[lowk].sum() / 3
    Pm = tot
    if not abs(Pm / exp - 1) < 0.10:
        return False, f"random (Poisson) particles: P(k) should be the shot noise V/N = {exp:.3g} at low k (many-mode average), got {Pm:.3g}"
    # displaced lattice = the Zel'dovich initial conditions
    d0 = ref_gaussian(32, 100.0, lambda k: 5000.0 / (1 + (k / 0.1) ** 2) ** 1.2, 9)
    psi = C.displacement_field(d0, 100.0)
    pos, _ = C.zeldovich_ics(psi, 100.0, 0.1, 1.0, 0.0)
    kr, Pr, _ = shell_pk_reference(d0, 100.0)
    kk, P = (np.asarray(v) for v in C.particle_pk(np.asarray(pos), 100.0, 32)[:2])
    ratio = P[:4] / (Pr[:4] * 0.1**2)
    return bool(np.all(np.abs(ratio - 1) < 0.12)), f"displaced lattice: measured P(k) / (D^2 P_delta0) should be ~1 for shells 1-4, got {ratio.round(3)}"


# ---------------- 7.6 friends-of-friends ----------------
def brute_labels(pos, box, link):
    N = len(pos)
    d = wrap_diff(pos[:, None] - pos[None], box)
    A = (d**2).sum(-1) < link**2
    lab = -np.ones(N, int)
    c = 0
    for i in range(N):
        if lab[i] < 0:
            st = [i]; lab[i] = c                                     # noqa: E702
            while st:
                u = st.pop()
                for v in np.nonzero(A[u])[0]:
                    if lab[v] < 0:
                        lab[v] = c; st.append(v)                    # noqa: E702
            c += 1
    return lab


def same_partition(a, b):
    a, b = np.asarray(a), np.asarray(b)
    if a.shape != b.shape:
        return False
    pairs = np.unique(np.stack([a, b]), axis=1)
    return pairs.shape[1] == len(np.unique(a)) == len(np.unique(b))


def t_fof():
    rng = np.random.default_rng(1)
    box, link = 10.0, 0.7
    pos = rng.random((500, 3)) * box
    lab = np.asarray(C.friends_of_friends(pos, box, link))
    if not same_partition(lab, brute_labels(pos, box, link)):
        return False, "groups differ from a brute-force friends-of-friends (check the linking distance, < not <=, transitivity, and periodic images)"
    p2 = np.array([[0.1, 5.0, 5.0], [9.9, 5.0, 5.0], [9.7, 5.4, 5.0], [5.0, 5.0, 5.0]])
    l2 = np.asarray(C.friends_of_friends(p2, 10.0, 0.5))
    if not (l2[0] == l2[1] == l2[2] != l2[3]):
        return False, "particles across the periodic boundary must be linked"
    l3 = np.asarray(C.friends_of_friends(np.array([[1.0, 1, 1], [1.4, 1, 1], [1.8, 1, 1]]), 10.0, 0.5))
    return bool(l3[0] == l3[1] == l3[2]), "friendship is transitive: a chain of neighbours forms one group"


def t_fof_speed():
    rng = np.random.default_rng(2)
    box, N = 100.0, 32768
    pos = rng.random((N, 3)) * box
    cl = rng.normal(0, 0.8, (3000, 3)) + rng.random(3) * box            # one dense clump
    pos[:3000] = (cl % box)
    t = time.time()
    lab = np.asarray(C.friends_of_friends(pos, box, 0.2 * box / 32))
    dt = time.time() - t
    ok = len(lab) == N and np.bincount(lab).max() >= 2000
    return bool(ok and dt < 20), f"N = 32768 took {dt:.1f} s (limit 20 s; no O(N^2) pair loops) or the dense clump was not found as one group"


check("7.1 Hubble rate H(a)", t_hubble)
check("7.1 growth factor D(a): EdS and LCDM vs ODE", t_growth)
check("7.1 growth rate f(a)", t_growth_rate)
check("7.1 kick and drift factors", t_factors)
check("7.2 Gaussian field: shape, mean, seeds", t_gaussian_basic)
check("7.2 Gaussian field: power spectrum normalisation", t_gaussian_power)
check("7.2 measure_pk: white noise, shells, single mode", t_measure_pk)
check("7.3 displacement field", t_displacement)
check("7.3 Zel'dovich initial conditions", t_ics)
check("7.4 Zel'dovich pancake vs analytic solution", t_pancake)
check("7.4 symmetry, momentum, step convergence", t_conservation_steps)
check("7.5 P(k) of particles (Poisson, lattice)", t_particle_pk)
check("7.5 LCDM run: linear growth of low-k P(k)", t_lcdm_growth)
check("7.6 friends-of-friends vs brute force", t_fof)
check("7.6 friends-of-friends speed", t_fof_speed)

print(f"\n{sum(results)}/{len(results)} checks passed")
sys.exit(0 if all(results) else 1)
