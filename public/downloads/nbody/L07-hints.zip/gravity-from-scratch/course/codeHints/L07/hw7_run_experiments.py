"""Scaffold for the HW7 experiments (plotting only). Copy next to your cosmo.py; fill in the TODOs."""
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.append(str(Path(__file__).resolve().parents[1] / "L06"))
import cosmo as C  # noqa: E402

BOX = 100.0


def run_lcdm(n_part=32, ngrid=64, seed=3, a_snaps=(0.1, 0.3, 1.0), a_init=0.02):
    """-> dict a -> pos, plus the linear field delta0 (for comparison)."""
    # TODO: delta0 = C.gaussian_field(...); psi = ...; pos, mom = C.zeldovich_ics(...)
    # TODO: loop over a_snaps calling C.evolve(...) and store pos.copy()
    raise NotImplementedError


def plot_slices(snaps):
    fig, ax = plt.subplots(1, len(snaps), figsize=(3.2 * len(snaps), 3.2))
    for axx, (a, pos) in zip(np.atleast_1d(ax), snaps.items()):
        m = pos[:, 2] < 10
        axx.plot(pos[m, 0], pos[m, 1], ",k")
        axx.set_title(f"a={a}")
    plt.savefig("slices.png", dpi=150)


def plot_pk_growth(delta0, snaps):
    # TODO: k, P0 = C.measure_pk(delta0, BOX)[:2]; for each a: C.particle_pk(...); plot P/(D^2 P0)
    raise NotImplementedError


def halo_counts(pos, n_part, b=0.2, nmin=20):
    # TODO: labels = C.friends_of_friends(pos, BOX, b * BOX / n_part); sizes = np.bincount(labels)
    raise NotImplementedError


if __name__ == "__main__":
    t = time.time()
    # TODO: call the functions above, print the timing and the number of halos
    print(f"done in {time.time() - t:.1f} s")
