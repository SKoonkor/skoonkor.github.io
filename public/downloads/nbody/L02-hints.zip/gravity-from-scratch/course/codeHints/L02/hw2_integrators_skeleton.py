"""HW2 skeleton. Copy to myOwnCode/L02/integrators.py and fill in.

Uses your own Lecture 1 code (myOwnCode/L01/direct.py).
"""
import sys
from pathlib import Path

import numpy as np

sys.path.append(str(Path(__file__).resolve().parent.parent / "L01"))
from direct import acceleration, total_energy  # your L01 code


def symplectic_euler_step(pos, vel, mass, dt, G=1.0, eps=0.0):
    """-> (new_pos, new_vel). Kick first, then drift with the NEW velocity."""
    raise NotImplementedError


def leapfrog_kdk_step(pos, vel, acc, mass, dt, G=1.0, eps=0.0):
    """acc = a(pos). -> (new_pos, new_vel, new_acc). One force call per step."""
    raise NotImplementedError


def leapfrog_dkd_step(pos, vel, mass, dt, G=1.0, eps=0.0):
    """-> (new_pos, new_vel). Drift, kick, drift."""
    raise NotImplementedError


def angular_momentum(pos, vel, mass):
    """-> array (3,): sum of m_i * (r_i x v_i)."""
    raise NotImplementedError


def timestep(acc, eps, eta):
    """-> float: eta * sqrt(eps / largest |a_i|)."""
    raise NotImplementedError


# Optional challenge (HW 2.3):
def rk4_step(pos, vel, mass, dt, G=1.0, eps=0.0):
    """-> (new_pos, new_vel), classical Runge-Kutta 4."""
    raise NotImplementedError
