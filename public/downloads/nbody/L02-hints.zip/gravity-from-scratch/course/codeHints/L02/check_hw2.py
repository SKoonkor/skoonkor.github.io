"""Checker for HW2. Run from the project folder:

    python course/codeHints/L02/check_hw2.py [--l01 DIR] [--l02 DIR]

Defaults: myOwnCode/L01 (direct.py) and myOwnCode/L02 (integrators.py).
"""
import argparse
import sys
from pathlib import Path

import numpy as np

root = Path(__file__).resolve().parents[3]
ap = argparse.ArgumentParser()
ap.add_argument("--l01", default=str(root / "myOwnCode" / "L01"))
ap.add_argument("--l02", default=str(root / "myOwnCode" / "L02"))
args = ap.parse_args()
sys.path.insert(0, args.l01)
sys.path.insert(0, args.l02)

results, optional_results = [], []


def check(name, fn, optional=False):
    try:
        ok, msg = fn()
    except NotImplementedError:
        ok, msg = False, "not implemented yet"
    except Exception as e:  # noqa: BLE001
        ok, msg = False, f"{type(e).__name__}: {e}"
    (optional_results if optional else results).append(ok)
    tag = "PASS" if ok else ("SKIP" if optional and "not implemented" in msg else "FAIL")
    print(f"{tag}  {name}{' (optional)' if optional else ''}" + ("" if ok else f"   <- {msg}"))


try:
    import direct as d
except ImportError as e:
    sys.exit(f"Cannot import direct.py (Lecture 1) from {args.l01}: {e}")
try:
    import integrators as it
except ImportError as e:
    sys.exit(f"Cannot import integrators.py from {args.l02}: {e}")


def kepler_ic(e):
    r = 1 + e
    v = np.sqrt(2 / r - 1)
    return (np.array([[r / 2, 0, 0], [-r / 2, 0, 0]]), np.array([[0, v / 2, 0], [0, -v / 2, 0]]),
            np.array([0.5, 0.5]), 2 * np.pi)


def euler(p, v, m, dt):
    a = np.asarray(d.acceleration(p, m))
    return p + v * dt, v + a * dt


def kdk_runner():
    def go(p, v, m, dt, n):
        acc = np.asarray(d.acceleration(p, m))
        for _ in range(n):
            p, v, acc = it.leapfrog_kdk_step(p, v, acc, m, dt)
            p, v, acc = np.asarray(p), np.asarray(v), np.asarray(acc)
            yield p, v
    return go


def stepper(name):
    def kdk(p, v, m, dt, n):
        yield from kdk_runner()(p, v, m, dt, n)

    def simple(fn):
        def go(p, v, m, dt, n):
            for _ in range(n):
                p, v = fn(p.copy(), v.copy(), m, dt)
                p, v = np.asarray(p, dtype=float), np.asarray(v, dtype=float)
                yield p, v
        return go
    return {"euler": simple(lambda p, v, m, dt: euler(p, v, m, dt)),
            "seuler": simple(it.symplectic_euler_step),
            "kdk": kdk,
            "dkd": simple(it.leapfrog_dkd_step),
            "rk4": simple(it.rk4_step)}[name]


def energy_errors(name, e, n_per, orbits=1):
    p0, v0, m, T = kepler_ic(e)
    E0 = d.total_energy(p0, v0, m)
    out = []
    for p, v in stepper(name)(p0.copy(), v0.copy(), m, T / n_per, int(n_per * orbits)):
        out.append(abs(d.total_energy(p, v, m) - E0) / abs(E0))
    return np.array(out)


def slope(name, ns):
    ns = np.array(ns)
    er = [energy_errors(name, 0.5, n).max() for n in ns]
    return np.polyfit(np.log(2 * np.pi / ns), np.log(er), 1)[0]


# ---------------- 2.1 one-step tests ----------------
P1 = np.array([[0., 0, 0], [1, 0, 0]])
V1 = np.array([[0., 1, 0], [0, -1, 0]])
M1 = np.ones(2)


def acc2(p):  # independent 2-body formula for unit masses
    dvec = p[1] - p[0]
    a = dvec / np.linalg.norm(dvec) ** 3
    return np.array([a, -a])


def t_seuler():
    p, v = it.symplectic_euler_step(P1.copy(), V1.copy(), M1, 0.1)
    ev = V1 + 0.1 * acc2(P1)
    ep = P1 + 0.1 * ev
    ok = np.allclose(p, ep) and np.allclose(v, ev)
    return ok, f"kick first (v += a dt), then drift with the NEW v; max deviation pos {np.abs(p - ep).max():.1e}, vel {np.abs(v - ev).max():.1e}"


def t_kdk():
    a0 = acc2(P1)
    p, v, a = it.leapfrog_kdk_step(P1.copy(), V1.copy(), a0.copy(), M1, 0.1)
    vh = V1 + 0.05 * a0
    ep = P1 + 0.1 * vh
    ea = acc2(ep)
    ev = vh + 0.05 * ea
    ok = np.allclose(p, ep) and np.allclose(v, ev) and np.allclose(a, ea)
    return ok, (f"half kick, full drift, new acc at new positions, half kick; return (pos, vel, acc); "
                f"max deviation pos {np.abs(p - ep).max():.1e}, vel {np.abs(v - ev).max():.1e}, acc {np.abs(a - ea).max():.1e}")


def t_dkd():
    ph = P1 + 0.05 * V1
    ev = V1 + 0.1 * acc2(ph)
    ep = ph + 0.05 * ev
    p, v = it.leapfrog_dkd_step(P1.copy(), V1.copy(), M1, 0.1)
    return (np.allclose(p, ep) and np.allclose(v, ev),
            f"half drift, full kick (acc at half-drifted pos), half drift; max deviation pos {np.abs(p - ep).max():.1e}, vel {np.abs(v - ev).max():.1e}")


def t_no_mutation():
    for fn, a in ((it.symplectic_euler_step, ()), (it.leapfrog_dkd_step, ())):
        p, v = P1.copy(), V1.copy()
        fn(p, v, M1, 0.1)
        if not (np.array_equal(p, P1) and np.array_equal(v, V1)):
            return False, f"{fn.__name__} modified its inputs"
    p, v, a = P1.copy(), V1.copy(), acc2(P1)
    a0 = a.copy()
    it.leapfrog_kdk_step(p, v, a, M1, 0.1)
    ok = np.array_equal(p, P1) and np.array_equal(v, V1) and np.array_equal(a, a0)
    return ok, "leapfrog_kdk_step modified its inputs"


def t_force_calls():
    counter = {"n": 0}
    orig = d.acceleration

    def counted(*a, **k):
        counter["n"] += 1
        return orig(*a, **k)
    patched = [(d, "acceleration")] + [(it, k) for k, val in vars(it).items() if val is orig]
    for mod, k in patched:
        setattr(mod, k, counted)
    try:
        p0, v0, m, T = kepler_ic(0.5)
        acc = np.asarray(orig(p0, m))
        counter["n"] = 0
        p, v = p0.copy(), v0.copy()
        for _ in range(50):
            p, v, acc = it.leapfrog_kdk_step(p, v, acc, m, T / 200)
        n = counter["n"]
    finally:
        for mod, k in patched:
            setattr(mod, k, orig)
    hint = " (integrators.py must call your L01 acceleration)" if n == 0 else ""
    return n == 50, f"{n} force evaluations in 50 steps; expected 50 (reuse the acc you are given){hint}"


def acc2g(p, G, eps):  # softened 2-body formula, unit masses
    dvec = p[1] - p[0]
    a = G * dvec / (dvec @ dvec + eps**2) ** 1.5
    return np.array([a, -a])


def t_G_eps():
    G, eps, dt = 2.0, 0.3, 0.1
    a0 = acc2g(P1, G, eps)
    ev = V1 + dt * a0
    ep_se = P1 + dt * ev                                     # symplectic Euler
    p, v = it.symplectic_euler_step(P1.copy(), V1.copy(), M1, dt, G, eps)
    if not (np.allclose(p, ep_se) and np.allclose(v, ev)):
        return False, "symplectic_euler_step must pass G and eps on to acceleration"
    vh = V1 + 0.5 * dt * a0                                  # KDK
    ep = P1 + dt * vh
    ea = acc2g(ep, G, eps)
    p, v, a = it.leapfrog_kdk_step(P1.copy(), V1.copy(), a0.copy(), M1, dt, G, eps)
    if not (np.allclose(p, ep) and np.allclose(v, vh + 0.5 * dt * ea) and np.allclose(a, ea)):
        return False, "leapfrog_kdk_step must pass G and eps on to acceleration"
    ph = P1 + 0.5 * dt * V1                                  # DKD
    evd = V1 + dt * acc2g(ph, G, eps)
    p, v = it.leapfrog_dkd_step(P1.copy(), V1.copy(), M1, dt, G, eps)
    if not (np.allclose(p, ph + 0.5 * dt * evd) and np.allclose(v, evd)):
        return False, "leapfrog_dkd_step must pass G and eps on to acceleration"
    return True, ""


# ---------------- 2.2 angular momentum ----------------
def t_L():
    v = np.sqrt(0.5)
    Lc = np.asarray(it.angular_momentum(np.array([[-.5, 0, 0], [.5, 0, 0]]),
                                        np.array([[0, -v, 0], [0, v, 0]]), np.ones(2)))
    p0, v0, m, T = kepler_ic(0.9)
    Lk = np.asarray(it.angular_momentum(p0, v0, m))
    ok = np.allclose(Lc, [0, 0, np.sqrt(0.5)]) and np.allclose(Lk, [0, 0, 0.10897247], atol=1e-7)
    return ok, f"expected (0,0,0.7071) and (0,0,0.10897), got {Lc.round(4).tolist()} {Lk.round(5).tolist()}"


def t_L_conserved():
    p0, v0, m, T = kepler_ic(0.5)
    L0 = np.asarray(it.angular_momentum(p0, v0, m))
    worst = 0.0
    for p, v in stepper("kdk")(p0.copy(), v0.copy(), m, T / 200, 1000):
        worst = max(worst, np.abs(np.asarray(it.angular_momentum(p, v, m)) - L0).max())
    return worst < 1e-10, f"leapfrog should conserve L to rounding error; drift {worst:.1e}"


# ---------------- 2.3 order of accuracy ----------------
def t_slope(name, ns, lo, hi):
    def f():
        s = slope(name, ns)
        return lo < s < hi, f"log-log slope of max energy error vs dt is {s:.2f}, expected in ({lo}, {hi})"
    return f


# ---------------- 2.4 long run ----------------
def per_orbit_max(name, n, orbits):
    er = energy_errors(name, 0.5, n, orbits)
    return np.array([er[k * n:(k + 1) * n].max() for k in range(orbits)])


def t_long_kdk():
    pm = per_orbit_max("kdk", 200, 50)
    ok = pm.max() < 5e-3 and pm[-1] < 1.5 * pm[0]
    return ok, f"leapfrog: per-orbit max error should stay ~2.6e-3 and not grow; first {pm[0]:.1e}, last {pm[-1]:.1e}"


def t_long_euler():
    pm = per_orbit_max("euler", 400, 10)
    return pm[-1] > 1.5 * pm[0], f"Euler error should keep growing orbit after orbit; first {pm[0]:.2f}, last {pm[-1]:.2f}"


def t_long_rk4():
    pm = per_orbit_max("rk4", 100, 50)
    return pm[-1] > 5 * pm[0], f"RK4 error should creep up (not stay flat); first {pm[0]:.1e}, last {pm[-1]:.1e}"


# ---------------- 2.5 reversibility ----------------
def t_reverse(name):
    def f():
        p0, v0, m, T = kepler_ic(0.5)
        n = 400
        *_, (p, v) = list(stepper(name)(p0.copy(), v0.copy(), m, T / n, n))
        *_, (p, v) = list(stepper(name)(p.copy(), -v, m, T / n, n))
        dev = np.abs(p - p0).max()
        return dev < 1e-9, f"forward n steps, flip v, n steps back should return to the start; off by {dev:.1e}"
    return f


# ---------------- 2.6 adaptive step ----------------
def t_timestep():
    acc = np.array([[3., 4, 0], [0, 0, 1]])
    val = it.timestep(acc, 0.05, 0.1)
    return np.isclose(val, 0.1 * np.sqrt(0.05 / 5)), f"expected 0.01, got {val}"


def adaptive_run(eta, eps=0.05):
    p0, v0, m, T = kepler_ic(0.9)
    E0 = d.total_energy(p0, v0, m)
    p, v = p0.copy(), v0.copy()
    acc = np.asarray(d.acceleration(p, m))
    t, n, mx = 0.0, 0, 0.0
    while t < T - 1e-12:
        dt = min(float(it.timestep(acc, eps, eta)), T - t)
        p, v, acc = it.leapfrog_kdk_step(p, v, acc, m, dt)
        p, v, acc = np.asarray(p), np.asarray(v), np.asarray(acc)
        t += dt
        n += 1
        mx = max(mx, abs(d.total_energy(p, v, m) - E0) / abs(E0))
    return n, mx


def t_adaptive():
    n, mx = adaptive_run(0.05)
    p0, v0, m, T = kepler_ic(0.9)
    E0 = d.total_energy(p0, v0, m)
    fx = max(abs(d.total_energy(p, v, m) - E0) / abs(E0)
             for p, v in stepper("kdk")(p0.copy(), v0.copy(), m, T / n, n))
    ok = 300 < n < 500 and mx < 1.5e-2 and fx > 10 * mx
    return ok, (f"eta=0.05: {n} steps (expect ~400), adaptive max error {mx:.1e} (expect ~4.6e-3), "
                f"fixed step with the same n: {fx:.1e} (expect >10x worse, ~0.5)")


check("2.1 symplectic Euler: one step", t_seuler)
check("2.1 leapfrog KDK: one step", t_kdk)
check("2.1 leapfrog DKD: one step", t_dkd)
check("2.1 steppers do not modify inputs", t_no_mutation)
check("2.1 KDK uses one force evaluation per step", t_force_calls)
check("2.1 steppers pass G and eps through", t_G_eps)
check("2.2 angular momentum values", t_L)
check("2.2 leapfrog conserves angular momentum", t_L_conserved)
check("2.3 Euler is first order", t_slope("euler", [400, 800, 1600, 3200], 0.7, 1.3))
check("2.3 symplectic Euler is first order", t_slope("seuler", [100, 200, 400, 800, 1600], 0.85, 1.2))
check("2.3 leapfrog KDK is second order", t_slope("kdk", [100, 200, 400, 800, 1600], 1.8, 2.2))
check("2.3 leapfrog DKD is second order", t_slope("dkd", [100, 200, 400, 800, 1600], 1.8, 2.2))
check("2.3 RK4 is fourth order", t_slope("rk4", [50, 100, 200, 400], 3.8, 5.2), optional=True)
check("2.4 leapfrog: energy error bounded over 50 orbits", t_long_kdk)
check("2.4 Euler: energy error keeps growing", t_long_euler)
check("2.4 RK4: energy error creeps up", t_long_rk4, optional=True)
check("2.5 leapfrog KDK is time-reversible", t_reverse("kdk"))
check("2.5 leapfrog DKD is time-reversible", t_reverse("dkd"))
check("2.6 timestep()", t_timestep)
check("2.6 adaptive step beats fixed step", t_adaptive)

print(f"\n{sum(results)}/{len(results)} required checks passed"
      + (f"; optional: {sum(optional_results)}/{len(optional_results)}" if optional_results else ""))
sys.exit(0 if all(results) else 1)
