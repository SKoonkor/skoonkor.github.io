"""HW2 experiment scaffold. Copy to myOwnCode/L02/ next to integrators.py.

Initial conditions and plotting helpers are given; the time loops are yours.
"""
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

sys.path.append(str(Path(__file__).resolve().parent.parent / "L01"))
from direct import acceleration, total_energy, euler_step  # your L01 code
from integrators import (symplectic_euler_step, leapfrog_kdk_step,  # noqa: F401
                         leapfrog_dkd_step, angular_momentum, timestep)


def kepler_ic(e, a=1.0):
    """Two bodies of mass 0.5 (G = 1, M = 1), start at apocentre.

    Returns pos, vel, mass, period.
    """
    r = a * (1 + e)
    v = np.sqrt(2 / r - 1 / a)
    pos = np.array([[r / 2, 0, 0], [-r / 2, 0, 0]])
    vel = np.array([[0, v / 2, 0], [0, -v / 2, 0]])
    return pos, vel, np.array([0.5, 0.5]), 2 * np.pi * np.sqrt(a**3)


def max_energy_error(errors):
    """Largest relative energy error seen during a run (list of floats)."""
    return max(errors)


def loglog_slope(x, y):
    return np.polyfit(np.log(x), np.log(y), 1)[0]


if __name__ == "__main__":
    pos0, vel0, mass, T = kepler_ic(0.5)
    E0 = total_energy(pos0, vel0, mass)
    # HW 2.3: max error over one orbit vs dt, for each integrator
    # TODO
    # HW 2.4: max error per orbit for 50 orbits
    # TODO
    # HW 2.5: forward n steps, flip velocities, n steps back
    # TODO
    # HW 2.6: adaptive dt on kepler_ic(0.9)
    # TODO
    plt.show()
