"""Checker for HW4. Run from the project folder:

    python course/codeHints/L04/check_hw4.py [--l03 DIR] [--l04 DIR]

Defaults: myOwnCode/L03 (vectorised.py) and myOwnCode/L04 (tree.py).
"""
import argparse
import sys
import time
from pathlib import Path

import numpy as np

root_dir = Path(__file__).resolve().parents[3]
ap = argparse.ArgumentParser()
ap.add_argument("--l03", default=str(root_dir / "myOwnCode" / "L03"))
ap.add_argument("--l04", default=str(root_dir / "myOwnCode" / "L04"))
args = ap.parse_args()
sys.path.insert(0, args.l03)
sys.path.insert(0, args.l04)
sys.setrecursionlimit(5000)

results = []


def check(name, fn):
    try:
        ok, msg = fn()
    except NotImplementedError:
        ok, msg = False, "not implemented yet"
    except Exception as e:  # noqa: BLE001
        ok, msg = False, f"{type(e).__name__}: {e}"
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"   <- {msg}"))


try:
    import tree as T
except ImportError as e:
    sys.exit(f"Cannot import tree.py from {args.l04}: {e}")
try:
    import vectorised as V
except ImportError as e:
    sys.exit(f"Cannot import vectorised.py (Lecture 3) from {args.l03}: {e}")


def walk(node, depth=0):
    yield node, depth
    if node.children is not None:
        for c in node.children:
            yield from walk(c, depth + 1)


def leaves(root):
    return [(n, d) for n, d in walk(root) if n.children is None]


def subtree_indices(node):
    if node.children is None:
        return list(node.indices)
    out = []
    for c in node.children:
        out += subtree_indices(c)
    return out


def clumps(N, dim, seed):
    rng = np.random.default_rng(seed)
    a = rng.normal(0.3, 0.05, (N // 2, dim))
    b = rng.random((N - N // 2, dim))
    return np.vstack([a, b])


def direct(p, m, G, eps):
    """Tiny independent direct sum (any dimension) used as the reference."""
    d = p[None, :, :] - p[:, None, :]
    r2 = (d**2).sum(axis=2) + eps**2
    np.fill_diagonal(r2, 1.0)
    w = m[None, :] / r2**1.5
    np.fill_diagonal(w, 0.0)
    return G * (w[:, :, None] * d).sum(axis=1)


# ---------------- 4.1 building ----------------
def t_partition(dim):
    def f():
        pos = clumps(200, dim, 1)
        m = np.ones(200)
        root = T.build_tree(pos, m)
        if np.ndim(root.half) != 0:
            return False, "half must be a single number: the root cell is a cube, not a box"
        for n, _ in walk(root):
            if n.children is not None and any(ch is None for ch in n.children):
                return False, "children must be a list of Nodes with no None entries (empty cells are not created)"
        idx = sorted(i for n, _ in leaves(root) for i in n.indices)
        if idx != list(range(200)):
            return False, "every particle must appear in exactly one leaf"
        for n, _ in leaves(root):
            p = pos[list(n.indices)]
            if np.any(np.abs(p - n.center) > n.half * (1 + 1e-9)):
                return False, "a leaf holds a particle outside its cell"
            if len(n.indices) > 1:
                return False, "the DEFAULT leaf_size of build_tree must be 1: a leaf then holds one particle (unless max_depth is reached)"
        return True, ""
    return f


def t_geometry():
    pos = clumps(150, 3, 2)
    root = T.build_tree(pos, np.ones(150))
    if np.any(np.abs(pos - root.center) > root.half * (1 + 1e-9)):
        return False, "root cell must contain all particles"
    for n, _ in walk(root):
        if n.children is None:
            continue
        if len(n.children) > 8:
            return False, "an octree node has at most 8 children"
        for c in n.children:
            off = np.abs(c.center - n.center)
            if not (np.isclose(c.half, n.half / 2) and np.allclose(off, n.half / 2)):
                return False, "child cells must be the octants: half size /2, centre offset +-half/2 in every coordinate"
    return True, ""


def t_leaf_size():
    pos = clumps(200, 3, 3)
    root = T.build_tree(pos, np.ones(200), leaf_size=5)
    lv = leaves(root)
    ok = all(len(n.indices) <= 5 for n, _ in lv) and sorted(i for n, _ in lv for i in n.indices) == list(range(200))
    return ok and len(lv) < 150, "leaf_size=5: leaves hold at most 5 particles (and the tree gets smaller)"


def t_duplicates():
    pos = np.vstack([np.full((30, 3), 0.5), np.random.default_rng(4).random((10, 3))])
    try:
        root = T.build_tree(pos, np.ones(40), leaf_size=1, max_depth=12)
    except RecursionError:
        return False, "recursion never ended: stop splitting at depth == max_depth (coincident particles cannot be separated)"
    idx = sorted(i for n, _ in leaves(root) for i in n.indices)
    depth = max(d for _, d in walk(root))
    return idx == list(range(40)) and depth <= 12, f"coincident particles must not recurse forever; deepest level {depth} (max_depth=12)"


def t_tiny():
    root = T.build_tree(np.array([[0.2, 0.3, 0.4]]), np.array([2.0]))
    ok = root.children is None and list(root.indices) == [0] and np.isclose(root.mass, 2.0)
    root2 = T.build_tree(np.array([[0., 0, 0], [1, 1, 1]]), np.ones(2))
    return ok and root2.children is not None and len(root2.children) == 2, "one particle: a leaf; two particles: a root with two children"


# ---------------- 4.2 mass and centre of mass ----------------
def t_com():
    rng = np.random.default_rng(5)
    for dim in (2, 3):
        pos = rng.random((120, dim))
        m = rng.random(120) + 0.5
        root = T.build_tree(pos, m)
        for n, _ in walk(root):
            ids = subtree_indices(n)
            mm = m[ids].sum()
            cc = (m[ids, None] * pos[ids]).sum(axis=0) / mm
            if not (np.isclose(n.mass, mm) and np.allclose(n.com, cc)):
                return False, f"dim={dim}: a node has the wrong mass or centre of mass"
    return True, ""


# ---------------- 4.3 forces ----------------
def plummer(N, seed):
    p, v, m = V.plummer_sphere(N, a=1.0, seed=seed)
    return np.asarray(p), np.asarray(v), np.asarray(m)


def rel_err(a, ref):
    return np.linalg.norm(a - ref, axis=1) / np.linalg.norm(ref, axis=1)


def t_theta0():
    for eps in (0.0, 0.05):
        p, _, m = plummer(150, 6)
        ref = np.asarray(V.acceleration_np(p, m, 1.5, eps))
        a = T.tree_acceleration(p, m, 1.5, eps, 0.0)
        e = np.abs(a - ref).max() / np.abs(ref).max()
        if e > 1e-10:
            return False, f"theta=0 must reproduce direct summation exactly; eps={eps}: relative difference {e:.1e}"
    return True, ""


def t_accuracy():
    p, _, m = plummer(500, 7)
    ref = np.asarray(V.acceleration_np(p, m, 1.0, 0.05))
    root = T.build_tree(p, m)
    med = {}
    for th in (0.2, 0.5, 1.0):
        med[th] = np.median(rel_err(T.tree_acceleration(p, m, 1.0, 0.05, th, root=root), ref))
    e5 = rel_err(T.tree_acceleration(p, m, 1.0, 0.05, 0.5, root=root), ref)
    ok = (med[0.2] < med[0.5] < med[1.0] and med[0.2] < 2e-3 and med[0.5] < 1.5e-2
          and np.percentile(e5, 99) < 0.1)
    return ok, (f"(s is the SIDE length of the cell = 2*half; accept when s^2 < theta^2 * d^2, d to the centre of mass) median errors {med[0.2]:.1e} / {med[0.5]:.1e} / {med[1.0]:.1e} for theta 0.2 / 0.5 / 1.0 "
                f"(expect ~2e-4, 3e-3, 2e-2, increasing); 99th percentile at 0.5: {np.percentile(e5, 99):.1e} (expect ~2e-2)")


def t_soft_cells():
    p, _, m = plummer(300, 14)
    ref = np.asarray(V.acceleration_np(p, m, 1.0, 0.4))
    e = rel_err(T.tree_acceleration(p, m, 1.0, 0.4, 0.3), ref)
    return np.median(e) < 6e-3, (f"eps=0.4, theta=0.3: median error {np.median(e):.1e} (expect about 1e-3). "
                                 "Cell (monopole) interactions need the softening too: use r^2 + eps^2")


def t_multi_leaf():
    for dim in (2, 3):
        rng = np.random.default_rng(20 + dim)
        p = rng.random((60, dim))
        m = rng.random(60) + 0.5
        for ls in (1, 6):
            root = T.build_tree(p, m, leaf_size=ls)
            st = {}
            a = T.tree_acceleration(p, m, 1.3, 0.05, 0.0, root=root, stats=st)
            e = np.abs(a - direct(p, m, 1.3, 0.05)).max() / np.abs(a).max()
            if e > 1e-10:
                return False, f"dim={dim}, leaf_size={ls}, unequal masses, theta=0: differs from direct summation by {e:.1e}"
            if st.get("interactions") != 60 * 59:
                return False, f"dim={dim}, leaf_size={ls}: {st.get('interactions')} interactions at theta=0, expected 3540"
    return True, ""


def t_contains():
    for dim in (2, 3):
        rng = np.random.default_rng(30 + dim)
        p = rng.random((50, dim))
        m = np.ones(50)
        root = T.build_tree(p, m, leaf_size=1)
        expected = 0
        for i in range(50):
            node = root
            while node.children is not None:
                expected += len(node.children) - 1
                node = next(ch for ch in node.children if i in subtree_indices(ch))
            expected += len(node.indices) - 1
        st = {}
        T.tree_acceleration(p, m, 1.0, 0.0, 1e3, root=root, stats=st)
        if st.get("interactions") != expected:
            return False, (f"dim={dim}: at theta=1000 expected {expected} interactions (a cell that contains the "
                           f"particle must still be opened), got {st.get('interactions')}")
    return True, ""


def t_stats_accumulate():
    p, _, m = plummer(30, 15)
    st = {}
    T.tree_acceleration(p, m, 1.0, 0.05, 0.0, stats=st)
    T.tree_acceleration(p, m, 1.0, 0.05, 0.0, stats=st)
    return st.get("interactions") == 2 * 30 * 29, f"stats must be added to: two calls at theta=0 give {2 * 30 * 29}, got {st.get('interactions')}"


def t_root_used():
    p, _, m = plummer(30, 16)
    root = T.build_tree(p, m)
    orig = T.build_tree

    def boom(*a, **k):
        raise AssertionError("build_tree was called although root= was given")
    T.build_tree = boom
    try:
        T.tree_acceleration(p, m, 1.0, 0.05, 0.5, root=root)
    finally:
        T.build_tree = orig
    return True, ""


def t_accept():
    node = T.Node(np.zeros(3), 0.5)                     # cell of side 1
    return bool(T.accept(node, 4.0, 0.6)) and not T.accept(node, 4.0, 0.4), \
        "accept(node, dd, theta): side s=1, d^2=4: s/d=0.5 < 0.6 is True, and 0.5 < 0.4 is False"


def t_stats():
    p, _, m = plummer(60, 8)
    st = {}
    T.tree_acceleration(p, m, 1.0, 0.05, 0.0, stats=st)
    return st.get("interactions") == 60 * 59, f"theta=0: every particle interacts with the 59 others, so 3540 interactions; got {st.get('interactions')}"


def t_scaling():
    per = {}
    for N in (200, 800):
        p, _, m = plummer(N, 9)
        st = {}
        T.tree_acceleration(p, m, 1.0, 0.05, 0.5, stats=st)
        per[N] = st["interactions"] / N
    growth = per[800] / per[200]
    ok = per[800] < 0.6 * 800 and growth < 3.7
    return ok, (f"interactions per particle at theta=0.5: {per[200]:.0f} (N=200), {per[800]:.0f} (N=800): growth x{growth:.1f}; "
                "direct summation would grow x4 (expect ~x2.6, and well below N)")


def t_inputs():
    p, _, m = plummer(50, 10)
    p0, m0 = p.copy(), m.copy()
    root = T.build_tree(p, m)
    T.tree_acceleration(p, m, 1.0, 0.05, 0.5, root=root)
    return np.array_equal(p, p0) and np.array_equal(m, m0), "build_tree / tree_acceleration changed their inputs"


def t_root_reuse():
    p, _, m = plummer(80, 11)
    a1 = T.tree_acceleration(p, m, 1.0, 0.05, 0.5)
    a2 = T.tree_acceleration(p, m, 1.0, 0.05, 0.5, root=T.build_tree(p, m))
    return np.allclose(a1, a2), "passing root= must give the same result as building the tree inside; with root=None build with build_tree's default arguments"


def t_G_eps():
    p, _, m = plummer(80, 12)
    a = T.tree_acceleration(p, m, 1.0, 0.0, 0.5)
    b = T.tree_acceleration(p, m, 2.0, 0.0, 0.5)
    c = T.tree_acceleration(p, m, 1.0, 0.5, 0.5)
    return bool(np.allclose(b, 2 * a) and not np.allclose(a, c, rtol=1e-3)), "the result must scale with G and depend on eps"


# ---------------- 4.6 dynamics ----------------
def t_dynamics():
    N, dt, n = 100, 0.02, 100
    p, v, m = plummer(N, 13)
    eps = 0.05
    E0 = V.total_energy_np(p, v, m, 1.0, eps)
    pt, vt = V.evolve_kdk(p, v, m, dt, n, 1.0, eps, force=lambda pp, mm, G, e: T.tree_acceleration(pp, mm, G, e, 0.5))
    pd, vd = V.evolve_kdk(p, v, m, dt, n, 1.0, eps)
    E1 = V.total_energy_np(pt, vt, m, 1.0, eps)
    dev = np.abs(pt - pd).max()
    dE = abs((E1 - E0) / E0)
    return dE < 5e-3 and dev < 0.05, f"tree vs direct after t=2: max position difference {dev:.1e} (expect about 3e-3), energy error {dE:.1e} (expect about 1e-4 to 5e-4)"


check("4.1 quadtree: every particle in exactly one leaf", t_partition(2))
check("4.1 octree: every particle in exactly one leaf", t_partition(3))
check("4.1 child cells are the octants of the parent", t_geometry)
check("4.1 leaf_size is respected", t_leaf_size)
check("4.1 coincident particles do not recurse forever", t_duplicates)
check("4.1 one and two particles", t_tiny)
check("4.2 mass and centre of mass in every node (2D and 3D)", t_com)
check("4.3 theta = 0 reproduces direct summation", t_theta0)
check("4.3 unequal masses, 2D and 3D, leaf_size 1 and 6", t_multi_leaf)
check("4.3 a cell containing the particle is always opened", t_contains)
check("4.3 accept() function", t_accept)
check("4.3 accuracy improves as theta decreases", t_accuracy)
check("4.3 inputs are not modified", t_inputs)
check("4.3 root= reuse", t_root_reuse)
check("4.3 root= means the tree is not rebuilt", t_root_used)
check("4.3 G scaling and softening", t_G_eps)
check("4.3 softening also applies to cell interactions", t_soft_cells)
check("4.5 interaction count at theta = 0", t_stats)
check("4.5 stats accumulate over calls", t_stats_accumulate)
check("4.5 cost grows slowly with N", t_scaling)
check("4.6 leapfrog with the tree force", t_dynamics)

print(f"\n{sum(results)}/{len(results)} checks passed")
sys.exit(0 if all(results) else 1)
