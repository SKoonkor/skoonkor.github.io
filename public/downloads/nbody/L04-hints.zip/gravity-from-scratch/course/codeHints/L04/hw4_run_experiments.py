"""HW4 experiment scaffold. Copy to myOwnCode/L04/ next to tree.py."""
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

sys.path.append(str(Path(__file__).resolve().parent.parent / "L03"))
from vectorised import acceleration_np, plummer_sphere, evolve_kdk  # your L03 code
from tree import build_tree, tree_acceleration


def plot_cells(node, ax, max_depth=99, depth=0):
    """Draw the cells of a 2D tree (recursive)."""
    ax.add_patch(Rectangle(node.center - node.half, 2 * node.half, 2 * node.half,
                           fill=False, lw=0.6))
    if node.children is not None and depth < max_depth:
        for child in node.children:
            plot_cells(child, ax, max_depth, depth + 1)


def relative_errors(acc, acc_ref):
    """Per-particle |a - a_ref| / |a_ref|."""
    return np.linalg.norm(acc - acc_ref, axis=1) / np.linalg.norm(acc_ref, axis=1)


if __name__ == "__main__":
    # HW 4.1: 2D points (uniform, and two Gaussian clumps): plot points and cells
    # TODO
    # HW 4.3/4.4: Plummer N = 1000, eps = 0.05: error percentiles and interactions vs theta
    # TODO
    # HW 4.5: interactions per particle vs N; time build and walk vs N
    # TODO
    # HW 4.6: evolve a Plummer sphere with the tree force (tree_acceleration inside evolve_kdk)
    # TODO
    plt.show()
