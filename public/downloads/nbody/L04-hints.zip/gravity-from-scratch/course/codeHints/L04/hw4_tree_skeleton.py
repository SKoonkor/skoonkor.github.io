"""HW4 skeleton. Copy to myOwnCode/L04/tree.py and fill in.

Node attributes are fixed: the checker reads them. One code path for 2D and 3D.
"""
import numpy as np


class Node:
    __slots__ = ("center", "half", "mass", "com", "children", "indices", "quad")

    def __init__(self, center, half):
        self.center = center      # (dim,) centre of the cubic cell
        self.half = half          # half the side length of the cell
        self.mass = 0.0           # total mass inside
        self.com = None           # (dim,) centre of mass
        self.children = None      # list of child Nodes; None for a leaf
        self.indices = None       # particle indices held by a leaf
        self.quad = None          # quadrupole moment (used from Lecture 5)


def build_tree(pos, mass, leaf_size=1, max_depth=40):
    """pos (N,dim), mass (N,) -> root Node.

    Cubic root cell around all particles. Split until a cell holds
    <= leaf_size particles or depth == max_depth.
    """
    # TODO 1: root cell (centre, half size) covering every particle
    # TODO 2: recursive function: fill mass and com, make a leaf or split
    # TODO 3: child number of a point = bits (x_k > centre_k); child centre = +-half/2
    raise NotImplementedError


def accept(node, dd, theta):
    """True if the cell may be used as a point mass.

    dd is the SQUARED distance from the particle to the cell's centre of mass.

    A separate function: Lecture 5 swaps in other criteria.
    """
    raise NotImplementedError


def tree_acceleration(pos, mass, G=1.0, eps=0.0, theta=0.5, root=None, stats=None):
    """-> acc (N,dim). Barnes-Hut walk for every particle.

    root: reuse a tree if given; None means build_tree(pos, mass) with its
    default arguments. stats: if a dict, add the number of
    interactions (node or particle) to stats["interactions"] (skipping
    a particle's own index is not an interaction).
    """
    # TODO 1: build the tree if root is None
    # TODO 2: for each particle, walk the tree from the root
    # TODO 3: leaf -> direct sum (skip itself); cell not containing i and accept() -> monopole;
    #         otherwise push its children
    raise NotImplementedError
