Copy course/codeHints/L04/hw4_tree_skeleton.py here and rename it to match the module
the checker imports (see that file's own docstring for the exact name).
If codeHints/L04 has a *_run_experiments.py file, copy that here too, next to
your own code, before running it.
