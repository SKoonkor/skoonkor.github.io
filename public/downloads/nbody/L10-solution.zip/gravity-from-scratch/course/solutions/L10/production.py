"""Reference solution, Lecture 10: Morton keys, key-sorted trees, domain decomposition, block time steps."""
import numpy as np


# ---------------- 10.1 Morton (Z-order) keys ----------------
def morton_keys(pos, box=1.0, bits=10):
    """3D Morton keys of positions in a periodic box: bit b of (ix, iy, iz) goes to bit 3b, 3b+1, 3b+2 of the key."""
    pos = np.asarray(pos, dtype=float)
    n = 1 << bits
    cell = np.clip(np.floor((pos % box) / box * n).astype(np.int64), 0, n - 1).astype(np.uint64)
    key = np.zeros(len(pos), dtype=np.uint64)
    one = np.uint64(1)
    for b in range(bits):
        sh = np.uint64(b)
        for axis in range(3):
            key |= ((cell[:, axis] >> sh) & one) << np.uint64(3 * b + axis)
    return key


# ---------------- 10.2 tree ranges and moments from sorted keys ----------------
def level_ranges(keys_sorted, bits, level):
    """Occupied cells of the octree at `level` (0 = root): prefixes, start and end index (end exclusive) in the sorted array."""
    prefix = keys_sorted >> np.uint64(3 * (bits - level))
    change = np.concatenate([[True], prefix[1:] != prefix[:-1]])
    start = np.nonzero(change)[0]
    end = np.concatenate([start[1:], [len(keys_sorted)]])
    return prefix[start], start, end


def range_moments(pos_sorted, mass_sorted, start, end):
    """Mass and centre of mass of the particle ranges [start, end) using cumulative sums."""
    cm = np.concatenate([[0.0], np.cumsum(mass_sorted)])
    cmx = np.concatenate([np.zeros((1, pos_sorted.shape[1])), np.cumsum(mass_sorted[:, None] * pos_sorted, axis=0)])
    m = cm[end] - cm[start]
    com = (cmx[end] - cmx[start]) / m[:, None]
    return m, com


# ---------------- 10.3 domain decomposition ----------------
def decompose(weights, nranks):
    """Split the (key-sorted) particles into nranks contiguous ranges of nearly equal total weight.
    -> boundaries (nranks + 1,) of indices; rank r owns [b[r], b[r+1])."""
    cw = np.cumsum(weights)
    total = cw[-1]
    targets = total * np.arange(1, nranks) / nranks
    cuts = np.searchsorted(cw, targets)
    return np.concatenate([[0], cuts, [len(weights)]]).astype(int)


# ---------------- 10.4 block (individual) time steps ----------------
def direct_acc(pos, mass, idx, G, eps):
    """Softened acceleration on the particles idx due to all particles."""
    d = pos[None, :, :] - pos[idx][:, None, :]
    r2 = (d**2).sum(-1) + eps**2
    r2[np.arange(len(idx)), idx] = np.inf
    return G * ((mass[None, :] / r2**1.5)[:, :, None] * d).sum(1)


def timestep_levels(acc, eps, eta, dt_max, kmax):
    """Level k of each particle: the largest step dt_max / 2^k not exceeding eta * sqrt(eps / |a|); k <= kmax."""
    dt_crit = eta * np.sqrt(eps / np.maximum(np.linalg.norm(acc, axis=1), 1e-300))
    k = np.ceil(np.log2(dt_max / dt_crit) - 1e-12)
    return np.clip(k, 0, kmax).astype(int)


def evolve_block(pos, vel, mass, G, eps, t_end, dt_max, eta, kmax):
    """KDK leapfrog with individual power-of-two steps; returns pos, vel (synchronised at t_end) and stats.

    stats['force_evals'] counts particle force evaluations (the initial one included), stats['steps'] the system steps.
    t_end must be a multiple of dt_max.
    """
    pos, vel = pos.copy(), vel.copy()
    N = len(mass)
    tick = dt_max / 2**kmax
    T_end = int(round(t_end / tick))
    all_idx = np.arange(N)
    acc = direct_acc(pos, mass, all_idx, G, eps)
    stats = {"force_evals": N, "steps": 0}
    k = timestep_levels(acc, eps, eta, dt_max, kmax)
    nt = 2 ** (kmax - k)                                     # step length in ticks
    ti = np.zeros(N, dtype=np.int64)
    vel += acc * (nt * tick / 2)[:, None]
    tsys = 0
    while tsys < T_end:
        tnext = int((ti + nt).min())
        pos += vel * ((tnext - tsys) * tick)                 # drift everybody (inactive: predicted positions)
        tsys = tnext
        active = np.nonzero(ti + nt == tnext)[0]
        a = direct_acc(pos, mass, active, G, eps)
        stats["force_evals"] += len(active)
        stats["steps"] += 1
        vel[active] += a * (nt[active] * tick / 2)[:, None]  # second half kick of the finished step
        ti[active] = tnext
        if tsys == T_end:
            break
        knew = timestep_levels(a, eps, eta, dt_max, kmax)
        kold = k[active]
        for j, i in enumerate(active):
            kn = knew[j]
            if kn < kold[j]:                                 # larger step: only in steps of 2 and on a synchronisation time
                kn = kold[j] - 1
                if tnext % 2 ** (kmax - kn) != 0:
                    kn = kold[j]
            k[i] = kn
        nt[active] = 2 ** (kmax - k[active])
        vel[active] += a * (nt[active] * tick / 2)[:, None]  # first half kick of the new step
    return pos, vel, stats


def total_energy(pos, vel, mass, G, eps):
    kin = 0.5 * (mass * (vel**2).sum(1)).sum()
    d = pos[:, None, :] - pos[None, :, :]
    r = np.sqrt((d**2).sum(-1) + eps**2)
    np.fill_diagonal(r, np.inf)
    return kin - 0.5 * G * (mass[:, None] * mass[None, :] / r).sum()
