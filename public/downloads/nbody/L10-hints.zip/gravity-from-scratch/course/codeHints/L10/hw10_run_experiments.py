"""Scaffold for the HW10 experiments. Copy next to your production.py; fill in the TODOs."""
import time

import matplotlib.pyplot as plt  # noqa: F401
import numpy as np  # noqa: F401

import production as P  # noqa: F401


def kepler_setup(e=0.9, eps=0.05):
    """A test mass (1e-8) on an orbit of eccentricity e around a unit mass, started at apocentre; G = 1, a = 1."""
    # TODO: pos, vel, mass
    raise NotImplementedError


def binary_swarm(seed=0, ns=30, sep=0.03):
    """Two unit masses on a circular orbit of separation sep, plus ns light particles on circular orbits at r = 2..6."""
    # TODO
    raise NotImplementedError


def fixed_step_kdk(pos, vel, mass, G, eps, dt, T):
    # TODO: the fixed-step reference (Lecture 2); returns pos, vel, number of force evaluations
    raise NotImplementedError


if __name__ == "__main__":
    t = time.time()
    # TODO: error and force evaluations against eta (block) and dt (fixed) for both test systems
    print(f"done in {time.time() - t:.1f} s")
