"""HW10 skeleton. Copy to myOwnCode/L10/production.py and fill in.

Space-filling-curve keys, key-sorted trees, domain decomposition and block (individual) time steps.
"""
import numpy as np  # noqa: F401


# ---- 10.1 Morton keys ----
def morton_keys(pos, box=1.0, bits=10):
    """Morton (Z-order) key of every particle, as a non-negative integer array (uint64).

    Cell coordinates i = floor(x / box * 2^bits) (positions wrapped into the box, clipped to 2^bits - 1).
    Bit b of ix, iy, iz goes to bit 3b, 3b+1, 3b+2 of the key. Must work for bits up to 21 and be vectorised over particles.
    """
    raise NotImplementedError


# ---- 10.2 the tree from sorted keys ----
def level_ranges(keys_sorted, bits, level):
    """Occupied cells of the octree at `level` (0 = root, `bits` = finest) for keys sorted in ascending order.

    -> prefix (cell keys), start, end: the particles of the cell k are keys_sorted[start[k]:end[k]]. No loop over particles.
    """
    raise NotImplementedError


def range_moments(pos_sorted, mass_sorted, start, end):
    """Total mass (n,) and centre of mass (n, 3) of the particle ranges [start, end). Use cumulative sums."""
    raise NotImplementedError


# ---- 10.3 domain decomposition ----
def decompose(weights, nranks):
    """Split key-sorted particles with per-particle work `weights` into nranks contiguous ranges of nearly equal weight.

    -> boundaries (nranks + 1,) integer array: rank r owns particles boundaries[r] .. boundaries[r+1]-1.
    """
    raise NotImplementedError


# ---- 10.4 block time steps ----
def direct_acc(pos, mass, idx, G, eps):
    """Softened acceleration on the particles idx (index array) from all particles (Lecture 3, for a subset of targets)."""
    raise NotImplementedError


def timestep_levels(acc, eps, eta, dt_max, kmax):
    """Level k (int array) of every particle: the largest step dt_max / 2^k not larger than eta * sqrt(eps / |a|), k <= kmax."""
    raise NotImplementedError


def evolve_block(pos, vel, mass, G, eps, t_end, dt_max, eta, kmax):
    """KDK leapfrog with individual power-of-two time steps. -> pos, vel at t_end (all synchronised), stats.

    stats['force_evals'] = number of particle force evaluations (the initial one for all particles included);
    stats['steps'] = number of system steps. t_end is a multiple of dt_max.

    Hint: keep the times as integers, in units of the smallest step dt_max / 2^kmax (float times fail 'is the step over?' tests).
    """
    raise NotImplementedError
