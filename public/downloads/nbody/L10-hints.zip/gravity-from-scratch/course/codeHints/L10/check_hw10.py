"""Checker for HW10. Run from the project folder:

    python course/codeHints/L10/check_hw10.py [--l10 DIR]

Default: myOwnCode/L10 (production.py).
"""
import argparse
import sys
import time
from pathlib import Path

import numpy as np

root_dir = Path(__file__).resolve().parents[3]
ap = argparse.ArgumentParser()
ap.add_argument("--l10", default=str(root_dir / "myOwnCode" / "L10"))
args = ap.parse_args()
sys.path.insert(0, args.l10)

results = []


def check(name, fn):
    try:
        ok, msg = fn()
    except NotImplementedError:
        ok, msg = False, "not implemented yet"
    except Exception as e:  # noqa: BLE001
        ok, msg = False, f"{type(e).__name__}: {e}"
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"   <- {msg}"))


try:
    import production as P
except ImportError as e:
    sys.exit(f"Cannot import production.py from {args.l10}: {e}")


# ---------------- references ----------------
def ref_keys(pos, box, bits):
    n = 1 << bits
    c = np.clip(np.floor((np.asarray(pos) % box) / box * n), 0, n - 1).astype(np.int64)
    out = []
    for x, y, z in c:
        k = 0
        for b in range(bits):
            k |= ((int(x) >> b) & 1) << (3 * b) | ((int(y) >> b) & 1) << (3 * b + 1) | ((int(z) >> b) & 1) << (3 * b + 2)
        out.append(k)
    return out


def as_int(a):
    return [int(v) for v in np.asarray(a)]


# ---------------- 10.1 Morton keys ----------------
def t_keys_known():
    k = as_int(P.morton_keys(np.array([[0.0, 0, 0], [0.9, 0.9, 0.9], [0.6, 0.1, 0.1], [0.1, 0.6, 0.1], [0.1, 0.1, 0.6]]), 1.0, 1))
    if k != [0, 7, 1, 2, 4]:
        return False, f"bits = 1: octant keys x -> bit 0, y -> bit 1, z -> bit 2; expected [0, 7, 1, 2, 4], got {k}"
    k2 = as_int(P.morton_keys(np.array([[0.75, 0.0, 0.0], [0.5, 0.25, 0.0]]), 1.0, 2))
    if k2 != [9, 10]:
        return False, f"bits = 2: (0.75, 0, 0) is cell (3, 0, 0) -> 0b001001 = 9 and (0.5, 0.25, 0) is cell (2, 1, 0) -> x bit 1 -> bit 3, y bit 0 -> bit 1: 0b001010 = 10; got {k2}"
    kw = as_int(P.morton_keys(np.array([[1.25, -0.5, 2.1], [0.25, 0.5, 0.1]]), 1.0, 3))
    if kw[0] != kw[1]:
        return False, "positions are wrapped periodically into the box"
    kb = as_int(P.morton_keys(np.array([[3.9999999, 3.9999999, 3.9999999]]), 4.0, 21))
    return bool(kb[0] == 2**63 - 1), "bits = 21: the largest cell has all 63 key bits set (2^63 - 1); use uint64 and avoid overflow"


def t_keys_random():
    rng = np.random.default_rng(1)
    for bits, box in ((10, 1.0), (21, 3.0)):
        pos = rng.random((300, 3)) * box
        pos[:3] = [[-1e-17, 0.5, 0.5] , [box, 0.0, box * (1 - 1e-16)], [0.0, 0.0, 0.0]]     # box edges (wrap and clip)
        if as_int(P.morton_keys(pos, box, bits)) != ref_keys(pos, box, bits):
            return False, f"bits = {bits}: keys differ from the bit-by-bit definition"
    return True, ""


def t_keys_speed():
    rng = np.random.default_rng(2)
    pos = rng.random((1_000_000, 3))
    t = time.time()
    k = P.morton_keys(pos, 1.0, 15)
    dt = time.time() - t
    return bool(len(k) == 1_000_000 and dt < 2.5), f"10^6 particles took {dt:.1f} s (limit 2.5 s): vectorise over the particles (loop over the bits only)"


# ---------------- 10.2 tree ranges ----------------
def sorted_set(seed, n=4000, bits=7, clustered=False):
    rng = np.random.default_rng(seed)
    if clustered:
        pos = (rng.random((6, 3))[rng.integers(0, 6, n)] + 0.03 * rng.normal(size=(n, 3))) % 1.0
    else:
        pos = rng.random((n, 3))
    m = rng.random(n) + 0.5
    key = np.asarray(P.morton_keys(pos, 1.0, bits)).astype(np.uint64)
    o = np.argsort(key, kind="stable")
    return pos[o], m[o], key[o], bits


def t_ranges():
    pos, m, key, bits = sorted_set(3)
    N = len(key)
    for level in (0, 1, 3, 5, 7):
        pre, st, en = (np.asarray(v) for v in P.level_ranges(key, bits, level))
        pre = pre.astype(np.uint64)
        if level == 0 and not (len(st) == 1 and st[0] == 0 and en[0] == N):
            return False, "level 0 is the root: one range [0, N)"
        if st[0] != 0 or en[-1] != N or not np.array_equal(st[1:], en[:-1]) or np.any(en <= st):
            return False, f"level {level}: the ranges must be non-empty, contiguous and cover [0, N)"
        if len(np.unique(pre)) != len(pre) or np.any(np.diff(pre.astype(np.int64)) <= 0):
            return False, f"level {level}: prefixes must be unique and increasing"
        if len(pre) > 8**level:
            return False, f"level {level}: at most 8^level cells"
        shift = np.uint64(3 * (bits - level))
        for p_, s_, e_ in list(zip(pre, st, en))[:50]:
            if not np.all((key[s_:e_] >> shift) == p_):
                return False, f"level {level}: all keys of a cell share the prefix key >> 3(bits - level)"
    return True, ""


def t_moments():
    for clustered in (False, True):
        pos, m, key, bits = sorted_set(4, clustered=clustered)
        for level in (2, 4, 6):
            pre, st, en = (np.asarray(v) for v in P.level_ranges(key, bits, level))
            mm, com = (np.asarray(v) for v in P.range_moments(pos, m, st, en))
            for j in np.linspace(0, len(st) - 1, min(len(st), 12)).astype(int):
                ms = m[st[j]:en[j]]
                c = (ms[:, None] * pos[st[j]:en[j]]).sum(0) / ms.sum()
                if abs(mm[j] - ms.sum()) > 1e-10 * ms.sum() or np.abs(com[j] - c).max() > 1e-10:
                    return False, f"level {level}: mass or centre of mass of a cell differs from the brute-force sum"
    return True, ""


def t_hierarchy():
    pos, m, key, bits = sorted_set(5)
    pre2, st2, en2 = (np.asarray(v) for v in P.level_ranges(key, bits, 4))
    mm2, com2 = (np.asarray(v) for v in P.range_moments(pos, m, st2, en2))
    pre1, st1, en1 = (np.asarray(v) for v in P.level_ranges(key, bits, 3))
    mm1, com1 = (np.asarray(v) for v in P.range_moments(pos, m, st1, en1))
    pre1, pre2 = pre1.astype(np.uint64), pre2.astype(np.uint64)
    parent = (pre2 >> np.uint64(3)).astype(np.int64)
    for j in range(0, len(pre1), max(1, len(pre1) // 20)):
        kids = np.nonzero(parent == int(pre1[j]))[0]
        if len(kids) == 0 or len(kids) > 8:
            return False, "every occupied cell has 1 to 8 occupied children (prefix >> 3 is the parent)"
        mk = mm2[kids].sum()
        ck = (mm2[kids][:, None] * com2[kids]).sum(0) / mk
        if abs(mk - mm1[j]) > 1e-10 * mk or np.abs(ck - com1[j]).max() > 1e-10:
            return False, "the moments of a cell must combine from its children"
    return True, ""


# ---------------- 10.3 decomposition ----------------
def t_decompose():
    rng = np.random.default_rng(6)
    for w in (rng.pareto(1.5, 5000) + 0.1, np.ones(1003), rng.lognormal(0, 0.7, 4000)):
        for nr in (1, 2, 7, 64):
            b = np.asarray(P.decompose(w, nr)).astype(int)
            if len(b) != nr + 1 or b[0] != 0 or b[-1] != len(w) or np.any(np.diff(b) < 0):
                return False, f"nranks = {nr}: boundaries must be non-decreasing, from 0 to N, length nranks + 1"
            loads = np.array([w[b[r]:b[r + 1]].sum() for r in range(nr)])
            if np.abs(loads - w.sum() / nr).max() > w.max() * 1.01 + 1e-9:
                return False, f"nranks = {nr}: every rank's work must be within one particle's weight of the mean; largest deviation {np.abs(loads - w.sum() / nr).max():.3g}"
    return True, ""


# ---------------- 10.4 block time steps ----------------
def t_direct_acc():
    rng = np.random.default_rng(13)
    N = 9
    pos = rng.normal(size=(N, 3))
    mass = rng.random(N) + 0.5
    idx = np.array([1, 4, 7])
    G, eps = 2.3, 0.3
    a = np.asarray(P.direct_acc(pos, mass, idx, G, eps))
    if a.shape != (3, 3):
        return False, "direct_acc returns the accelerations of the particles idx only: shape (len(idx), 3)"
    ref = np.zeros((3, 3))
    for row, i in enumerate(idx):
        for j in range(N):
            if j != i:
                d = pos[j] - pos[i]
                ref[row] += G * mass[j] * d / (d @ d + eps**2) ** 1.5
    return bool(np.allclose(a, ref, rtol=1e-10, atol=1e-12)), "softened acceleration G m_j d / (r^2 + eps^2)^(3/2), pointing towards particle j; no self-force"


def t_levels():
    acc = np.array([[1e-3, 0, 0], [0.5, 0.5, 0], [10.0, 0, 0], [1e4, 0, 0], [1e-12, 0, 0]])
    eps, eta, dtm, kmax = 0.01, 0.2, 0.1, 8
    k = np.asarray(P.timestep_levels(acc, eps, eta, dtm, kmax)).astype(int)
    crit = eta * np.sqrt(eps / np.linalg.norm(acc, axis=1))
    dt = dtm / 2.0**k
    ok = np.all((dt <= crit * (1 + 1e-9)) | (k == kmax)) and np.all((2 * dt > crit) | (k == 0)) and np.all((k >= 0) & (k <= kmax))
    return bool(ok), f"levels {k}: dt = dt_max / 2^k must be the largest power-of-two fraction <= eta sqrt(eps/|a|) (k = 0 if the step can be dt_max, k <= kmax)"


def fixed_kdk(pos, vel, mass, G, eps, dt, T):
    n = int(round(T / dt))
    p, v = pos.copy(), vel.copy()
    idx = np.arange(len(mass))
    a = P.direct_acc(p, mass, idx, G, eps)
    for _ in range(n):
        v += a * dt / 2
        p += v * dt
        a = P.direct_acc(p, mass, idx, G, eps)
        v += a * dt / 2
    return p, v, n * len(mass)


def t_single_level():
    rng = np.random.default_rng(7)
    N = 6
    pos = rng.normal(size=(N, 3))
    vel = 0.3 * rng.normal(size=(N, 3))
    mass = rng.random(N) + 0.5
    T, dtm = 0.8, 0.1
    p1, v1, st = P.evolve_block(pos, vel, mass, 1.0, 0.1, T, dtm, 1e6, 6)
    p2, v2, fe = fixed_kdk(pos, vel, mass, 1.0, 0.1, dtm, T)
    if np.abs(p1 - p2).max() > 1e-10 or np.abs(v1 - v2).max() > 1e-10:
        return False, "when every particle is on level 0 the scheme is plain KDK leapfrog with dt = dt_max (positions and velocities synchronised at t_end); keep the time as an integer number of smallest steps, not a float"
    if st.get("steps") != round(T / dtm):
        return False, f"stats['steps'] = {st.get('steps')} but there are {round(T / dtm)} system steps (times as integer ticks avoid floating-point trouble in 'while t < t_end')"
    return bool(st["force_evals"] == N * (round(T / dtm) + 1)), f"force_evals = {st['force_evals']} but a fixed-step run needs N (steps + 1) = {N * (round(T / dtm) + 1)}"


def tot_energy(pos, vel, mass, G, eps):
    kin = 0.5 * (mass * (vel**2).sum(1)).sum()
    d = pos[:, None, :] - pos[None, :, :]
    r = np.sqrt((d**2).sum(-1) + eps**2)
    np.fill_diagonal(r, np.inf)
    return kin - 0.5 * G * (mass[:, None] * mass[None, :] / r).sum()


def t_kepler():
    G, M, m, e, a, eps = 1.0, 1.0, 1e-8, 0.9, 1.0, 0.05
    ra = a * (1 + e)
    va = np.sqrt(G * M * (1 - e) / (a * (1 + e)))
    pos = np.array([[0, 0, 0], [ra, 0, 0]], float)
    vel = np.array([[0, 0, 0], [0, va, 0]], float)
    mass = np.array([M, m])
    E0 = tot_energy(pos, vel, mass, G, eps)
    p, v, st = P.evolve_block(pos, vel, mass, G, eps, 63.0, 0.25, 0.05, 12)
    err = abs(tot_energy(p, v, mass, G, eps) - E0) / abs(E0)
    if err > 2e-3:
        return False, f"eccentric orbit (e = 0.9, 10 orbits, eta = 0.05): energy error {err:.1e} (expect ~1.5e-5; block steps are not symplectic, but this should be small)"
    return bool(st["force_evals"] < 17000), f"force evaluations {st['force_evals']} (expect ~8000): the step must be large near apocentre"


def binary_swarm(seed=0, ns=30, sep=0.03):
    rng = np.random.default_rng(seed)
    vb = np.sqrt(2.0 / sep) / 2
    pos = [[-sep / 2, 0, 0], [sep / 2, 0, 0]]
    vel = [[0, -vb, 0], [0, vb, 0]]
    mass = [1.0, 1.0]
    for _ in range(ns):
        r, ph = rng.uniform(2, 6), rng.uniform(0, 2 * np.pi)
        pos.append([r * np.cos(ph), r * np.sin(ph), 0])
        vs = np.sqrt(2.0 / r)
        vel.append([-vs * np.sin(ph), vs * np.cos(ph), 0])
        mass.append(1e-3)
    return np.array(pos, float), np.array(vel, float), np.array(mass)


def t_binary():
    pos, vel, mass = binary_swarm()
    eps, T = 0.003, 2.0
    ref, _, _ = fixed_kdk(pos, vel, mass, 1.0, eps, 1e-4, T)
    rb = np.linalg.norm(ref[0] - ref[1])
    t = time.time()
    p, v, st = P.evolve_block(pos, vel, mass, 1.0, eps, T, 0.05, 0.4, 12)
    dt = time.time() - t
    sep = abs(np.linalg.norm(p[0] - p[1]) - rb)
    sw = np.median(np.linalg.norm(p[2:] - ref[2:], axis=1))
    if not (sep < 1e-3 and sw < 1e-4):
        return False, f"binary + swarm, eta = 0.4: binary separation error {sep:.1e} (expect ~2e-4), swarm median error {sw:.1e} (expect ~1e-5)"
    fixed = 32 * round(T / 4e-4)
    return bool(st["force_evals"] < 25000), f"force evaluations {st['force_evals']} (expect ~12000; a fixed step small enough for the binary needs {fixed}): only the particles that need a small step may be updated"


check("10.1 Morton keys: known values, wrap, 21 bits", t_keys_known)
check("10.1 Morton keys vs the bit-by-bit definition", t_keys_random)
check("10.1 Morton keys speed (10^6 particles)", t_keys_speed)
check("10.2 tree cells from sorted keys: ranges", t_ranges)
check("10.2 cell mass and centre of mass (cumulative sums)", t_moments)
check("10.2 moments combine from the children", t_hierarchy)
check("10.3 domain decomposition balance", t_decompose)
check("10.4 direct_acc for a subset of targets", t_direct_acc)
check("10.4 time-step levels", t_levels)
check("10.4 single level = fixed-step leapfrog", t_single_level)
check("10.4 eccentric Kepler orbit with block steps", t_kepler)
check("10.4 binary + swarm: accuracy and force evaluations", t_binary)

print(f"\n{sum(results)}/{len(results)} checks passed")
sys.exit(0 if all(results) else 1)
