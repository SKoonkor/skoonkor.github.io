"""Reference solution, Lecture 2. Uses the L01 direct.py."""
import sys
from pathlib import Path
import numpy as np

sys.path.append(str(Path(__file__).resolve().parent.parent / "L01"))  # L01 direct.py
from direct import acceleration, total_energy, kinetic_energy


def symplectic_euler_step(pos, vel, mass, dt, G=1.0, eps=0.0):
    acc = acceleration(pos, mass, G, eps)
    vel_new = vel + acc * dt
    pos_new = pos + vel_new * dt
    return pos_new, vel_new


def leapfrog_kdk_step(pos, vel, acc, mass, dt, G=1.0, eps=0.0):
    """One kick-drift-kick step; acc is a(pos). Returns pos, vel, acc at the new time."""
    vel_half = vel + 0.5 * dt * acc
    pos_new = pos + dt * vel_half
    acc_new = acceleration(pos_new, mass, G, eps)
    vel_new = vel_half + 0.5 * dt * acc_new
    return pos_new, vel_new, acc_new


def leapfrog_dkd_step(pos, vel, mass, dt, G=1.0, eps=0.0):
    pos_half = pos + 0.5 * dt * vel
    acc = acceleration(pos_half, mass, G, eps)
    vel_new = vel + dt * acc
    pos_new = pos_half + 0.5 * dt * vel_new
    return pos_new, vel_new


def rk4_step(pos, vel, mass, dt, G=1.0, eps=0.0):
    def f(p, v):
        return v, acceleration(p, mass, G, eps)
    k1p, k1v = f(pos, vel)
    k2p, k2v = f(pos + 0.5 * dt * k1p, vel + 0.5 * dt * k1v)
    k3p, k3v = f(pos + 0.5 * dt * k2p, vel + 0.5 * dt * k2v)
    k4p, k4v = f(pos + dt * k3p, vel + dt * k3v)
    pos_new = pos + dt / 6 * (k1p + 2 * k2p + 2 * k3p + k4p)
    vel_new = vel + dt / 6 * (k1v + 2 * k2v + 2 * k3v + k4v)
    return pos_new, vel_new


def angular_momentum(pos, vel, mass):
    L = np.zeros(3)
    for i in range(len(mass)):
        L += mass[i] * np.cross(pos[i], vel[i])
    return L


def timestep(acc, eps, eta):
    """Global step from the largest acceleration: eta * sqrt(eps / a_max)."""
    a_max = max(np.linalg.norm(a) for a in acc)
    return eta * np.sqrt(eps / a_max)
