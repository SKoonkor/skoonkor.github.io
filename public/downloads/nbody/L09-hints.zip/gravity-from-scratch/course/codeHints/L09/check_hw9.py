"""Checker for HW9. Run from the project folder:

    python course/codeHints/L09/check_hw9.py [--l04 DIR] [--l09 DIR]

Defaults: myOwnCode/L04 (tree.py) and myOwnCode/L09 (fmm2d.py).
"""
import argparse
import sys
import time
from pathlib import Path

import numpy as np

root_dir = Path(__file__).resolve().parents[3]
ap = argparse.ArgumentParser()
ap.add_argument("--l04", default=str(root_dir / "myOwnCode" / "L04"))
ap.add_argument("--l09", default=str(root_dir / "myOwnCode" / "L09"))
args = ap.parse_args()
sys.path.insert(0, args.l04)
sys.path.insert(0, args.l09)

results = []


def check(name, fn):
    try:
        ok, msg = fn()
    except NotImplementedError:
        ok, msg = False, "not implemented yet"
    except Exception as e:  # noqa: BLE001
        ok, msg = False, f"{type(e).__name__}: {e}"
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"   <- {msg}"))


try:
    import tree  # noqa: F401
except ImportError as e:
    sys.exit(f"Cannot import your Lecture 4 tree.py from {args.l04}: {e}")
try:
    import fmm2d as F
except ImportError as e:
    sys.exit(f"Cannot import fmm2d.py from {args.l09}: {e}")


# ---------------- references ----------------
def direct(zt, z, q, self_=False):
    d = zt[:, None] - z[None, :]
    if self_:
        np.fill_diagonal(d, np.inf)
    return (q[None, :] / d).sum(1)


def scale(z, q):
    d = np.abs(z[:, None] - z[None, :])
    np.fill_diagonal(d, np.inf)
    return (q[None, :] / d).sum(1)


def rand_z(rng, n, lo=0.0, hi=1.0):
    return lo + (hi - lo) * rng.random(n) + 1j * (lo + (hi - lo) * rng.random(n))


# ---------------- 9.1 operators ----------------
def t_known_values():
    c = np.asarray(F.p2m(np.array([1 + 0j, -1 + 0j]), np.array([1.0, 2.0]), 0j, 4))
    if not np.allclose(c, [3, -1, 3, -1]):
        return False, f"charges 1 at z=1 and 2 at z=-1, centre 0: c_k = sum q z^k = [3, -1, 3, -1], got {np.round(c, 6)}"
    v = complex(np.asarray(F.m2p(c, np.array([5 + 0j])))[0])
    if abs(v - (3 / 5 - 1 / 25 + 3 / 125 - 1 / 625)) > 1e-12:
        return False, "m2p: f = sum_k c_k / w^(k+1)"
    L = np.array([1, 2, 3], dtype=complex)
    if abs(complex(np.asarray(F.l2p(L, np.array([0.5 + 0j])))[0]) - 2.75) > 1e-12:
        return False, "l2p: sum_l L_l w^l"
    c2 = np.asarray(F.m2m(c, 0 - 2 + 0j))
    if not np.allclose(c2, [3, -7, 19, -55]):
        return False, f"m2m from centre 0 to centre 2 (d = -2): expected [3, -7, 19, -55], got {np.round(c2, 6)}"
    Lm = np.asarray(F.m2l(c, 10 + 0j))
    if not (abs(Lm[0] - (0.3 - 0.01 + 0.003 - 0.0001)) < 1e-12 and abs(Lm[1] + (0.03 - 0.002 + 0.0009 - 0.00004)) < 1e-12):
        return False, f"m2l to a target centre at 10: L_0 = 0.2929, L_1 = -0.02886, got {np.round(Lm[:2], 6)}"
    return True, ""


def t_multipole():
    rng = np.random.default_rng(1)
    z = rand_z(rng, 30, -0.3, 0.3) + 0.4 + 0.2j
    q = rng.random(30) + 0.5
    zc = (q * z).sum() / q.sum()
    r = np.abs(z - zc).max()
    R = 3.0
    zt = zc + R * np.exp(1j * rng.random(25) * 2 * np.pi)
    ex = direct(zt, z, q)
    for p in (4, 8, 14):
        c = np.asarray(F.p2m(z, q, zc, p))
        if p == 4 and (abs(c[0] - q.sum()) > 1e-12 or abs(c[1]) > 1e-12 * q.sum()):
            return False, "c_0 = total mass, and c_1 = 0 when the centre is the centre of mass"
        e = np.abs(np.asarray(F.m2p(c, zt - zc)) - ex).max()
        bound = q.sum() * (r / R) ** p / (R - r)
        if e > 1.001 * bound:
            return False, f"p = {p}: error {e:.2e} exceeds the bound sum(q) (r/R)^p / (R - r) = {bound:.2e}"
    return True, ""


def t_m2m():
    rng = np.random.default_rng(2)
    z = rand_z(rng, 20, 0.1, 0.3)
    q = rng.random(20) + 0.5
    zc, zn = 0.2 + 0.2j, 0.31 + 0.27j
    for p in (3, 10):
        c = np.asarray(F.p2m(z, q, zc, p))
        cn = np.asarray(F.m2m(c, zc - zn))
        ref = np.asarray(F.p2m(z, q, zn, p))
        if np.abs(cn - ref).max() > 1e-11 * np.abs(ref).max():
            return False, f"p = {p}: shifting the centre must reproduce p2m about the new centre exactly (d = old - new); max difference {np.abs(cn - ref).max():.1e}"
    return True, ""


def t_m2l():
    rng = np.random.default_rng(3)
    zs, zt = 0.5 + 0.5j, 3.5 + 1.5j                     # well separated boxes of width 1: D = (3, 1)
    src = zs + (rng.random(25) - 0.5) + 1j * (rng.random(25) - 0.5)
    q = rng.random(25) + 0.5
    tgt = zt + (rng.random(30) - 0.5) + 1j * (rng.random(30) - 0.5)
    ex = direct(tgt, src, q)
    err = {}
    for p in (6, 12, 18):
        L = np.asarray(F.m2l(np.asarray(F.p2m(src, q, zs, p)), zt - zs))
        err[p] = (np.abs(np.asarray(F.l2p(L, tgt - zt)) - ex) / np.abs(ex)).max()
    if err[18] > 1e-9 or err[12] > 1e-6 or err[6] > 1e-3:
        return False, f"m2l errors for p = 6, 12, 18: {err[6]:.1e}, {err[12]:.1e}, {err[18]:.1e} (expect ~1e-4, 2e-8, 3e-12 or better; d = target centre - source centre)"
    return bool(err[18] < err[12] < err[6]), "the error must fall with p"


def t_l2l():
    rng = np.random.default_rng(4)
    L = rng.normal(size=9) + 1j * rng.normal(size=9)
    s = 0.3 - 0.2j
    L2 = np.asarray(F.l2l(L, s))
    w = 0.1 * (rng.normal(size=6) + 1j * rng.normal(size=6))
    a = np.asarray(F.l2p(L2, w))
    b = np.asarray(F.l2p(L, w + s))
    return bool(np.abs(a - b).max() < 1e-11), "moving a polynomial to a new centre (s = new - old) is exact: L2(w) = L(w + s)"


# ---------------- 9.2 the tree ----------------
def t_lists():
    if len(F.interaction_list(3, 3, 3)) != 27 or len(F.interaction_list(0, 0, 3)) != 12 or len(F.interaction_list(0, 0, 2)) != 12:
        return False, "an interior box has 27 boxes in its list; the corner boxes (0,0) of levels 2 and 3 have 12 (only boxes inside the domain)"
    for level in (2, 3, 4):
        n = 2**level
        for ix in range(n):
            for iy in range(n):
                for jx, jy in F.interaction_list(ix, iy, level):
                    if max(abs(jx - ix), abs(jy - iy)) <= 1:
                        return False, f"level {level}: box ({jx},{jy}) is adjacent to ({ix},{iy}) but is in its list"
                    if max(abs(jx // 2 - ix // 2), abs(jy // 2 - iy // 2)) > 1:
                        return False, f"level {level}: the parent of ({jx},{jy}) is not a neighbour of the parent of ({ix},{iy})"
    # partition: every leaf pair is covered exactly once by (neighbour) + (interaction lists of the box and its ancestors)
    Lv = 4
    n = 2**Lv
    for ix, iy in ((0, 0), (5, 9), (7, 7), (15, 3), (8, 8)):
        cover = np.zeros((n, n), int)
        for jx in range(max(ix - 1, 0), min(ix + 2, n)):
            for jy in range(max(iy - 1, 0), min(iy + 2, n)):
                cover[jx, jy] += 1
        for l in range(2, Lv + 1):
            sh = Lv - l
            for jx, jy in F.interaction_list(ix >> sh, iy >> sh, l):
                cover[jx << sh:(jx + 1) << sh, jy << sh:(jy + 1) << sh] += 1
        if not np.all(cover == 1):
            return False, f"leaf ({ix},{iy}): near field + interaction lists of all ancestor levels must cover every leaf box exactly once ({(cover == 0).sum()} missing, {(cover > 1).sum()} doubled)"
    return True, ""


def fmm_err(z, q, p, levels, ref=None, sc=None):
    ex = direct(z, z, q, True) if ref is None else ref
    sc = scale(z, q) if sc is None else sc
    f = np.asarray(F.fmm_field(z, q, p, levels))
    e = np.abs(f - ex) / sc
    return np.median(e), e.max()


def t_fmm_uniform():
    rng = np.random.default_rng(5)
    z = rand_z(rng, 700)
    q = rng.random(700) + 0.5
    ex, sc = direct(z, z, q, True), scale(z, q)
    res = {}
    for lv in (2, 3, 4):
        res[lv] = fmm_err(z, q, 12, lv, ex, sc)
        if res[lv][1] > 5e-5 or res[lv][0] > 2e-6:
            return False, f"levels = {lv}, p = 12: median {res[lv][0]:.1e}, max {res[lv][1]:.1e} of the scaled error (expected ~1e-7 / 1e-5 or better)"
    st = {}
    np.asarray(F.fmm_field(z, q, 8, 3, st))
    if not (st.get('m2l', 0) > 0 and st.get('pp', 0) > 0):
        return False, "fmm_field(..., stats=dict) must set stats['m2l'] (number of M2L operations) and stats['pp'] (near-field pair evaluations)"
    e6 = fmm_err(z, q, 6, 3, ex, sc)[1]
    return bool(e6 > 10 * res[3][1]), "the error must fall quickly with p (p = 6 -> 12: at least 10x)"


def t_fmm_edge():
    rng = np.random.default_rng(6)
    a = 0.25 + 0.02 * (rng.normal(size=120) + 1j * rng.normal(size=120))
    b = 0.8 + 0.7j + 0.01 * (rng.normal(size=100) + 1j * rng.normal(size=100))
    edge = np.array([0.5 + 0.3j, 0.5 + 0.5j, 0.0 + 0.0j, 0.999999 + 0.999999j, 0.25 + 0.5j, 0.75 + 0.75j, 0.5 + 0.9j])
    z = np.concatenate([a, b])
    z = z + 1e-9 * (rng.normal(size=len(z)) + 1j * rng.normal(size=len(z)))
    z = np.clip(z.real, 0, 0.9999999) + 1j * np.clip(z.imag, 0, 0.9999999)
    z = np.concatenate([z, edge])                      # exact box-edge coordinates 0.25, 0.5, 0.75, 0.0
    q = rng.random(len(z)) + 0.5
    ex, sc = direct(z, z, q, True), scale(z, q)
    for lv in (3, 4):
        med, mx = fmm_err(z, q, 14, lv, ex, sc)
        if mx > 2e-4:
            return False, f"clustered particles, empty boxes, particles on box edges (levels = {lv}): max scaled error {mx:.1e}"
    return True, ""


def t_fmm_linear():
    rng = np.random.default_rng(7)
    z = rand_z(rng, 300)
    q1, q2 = rng.random(300) + 0.5, rng.random(300)
    f = lambda q: np.asarray(F.fmm_field(z, q, 10, 3))          # noqa: E731
    f12, f1, f2 = f(q1 + 2.5 * q2), f(q1), f(q2)
    if np.abs(f12 - (f1 + 2.5 * f2)).max() > 1e-9 * np.abs(f1).max():
        return False, "the field is linear in the masses"
    qq = np.array([2.0, 3.0])
    for zz, tol in ((np.array([0.30 + 0.30j, 0.34 + 0.37j]), 1e-12), (np.array([0.2 + 0.3j, 0.7 + 0.6j]), 1e-4)):
        f2b = np.asarray(F.fmm_field(zz, qq, 10, 2))
        if abs(f2b[0] - 3.0 / (zz[0] - zz[1])) > tol * abs(f2b[0]) or abs(f2b[1] - 2.0 / (zz[1] - zz[0])) > tol * abs(f2b[1]):
            return False, "two particles: f(z_1) = q_2 / (z_1 - z_2), no self-interaction (exact when in the same or neighbouring boxes)"
    return True, ""


def t_fmm_speed():
    rng = np.random.default_rng(8)
    N = 20000
    z = rand_z(rng, N)
    q = rng.random(N) + 0.5
    t = time.time()
    f = np.asarray(F.fmm_field(z, q, 8, 5))
    dt = time.time() - t
    idx = rng.choice(N, 150, replace=False)
    d = z[idx][:, None] - z[None, :]
    d[np.arange(150), idx] = np.inf
    ex = (q[None, :] / d).sum(1)
    sc = (q[None, :] / np.abs(d)).sum(1)
    e = (np.abs(f[idx] - ex) / sc).max()
    return bool(dt < 30 and e < 1e-3), f"N = 20000, 5 levels, p = 8: {dt:.1f} s (limit 30 s), max scaled error on 150 particles {e:.1e} (expect ~1e-4)"


# ---------------- 9.4 Barnes-Hut ----------------
def t_bh():
    rng = np.random.default_rng(9)
    z = rand_z(rng, 800)
    q = rng.random(800) + 0.5
    ex, sc = direct(z, z, q, True), scale(z, q)
    prev = None
    counts = []
    for th in (1.0, 0.5, 0.25):
        st = {}
        f = np.asarray(F.bh_field(z, q, th, st))
        e = np.abs(f - ex) / sc
        counts.append(st["interactions"])
        if prev is not None and not np.median(e) < prev:
            return False, "the error must decrease with theta"
        prev = np.median(e)
        if th == 0.5 and not (np.median(e) < 2e-3 and e.max() < 1.5e-2):
            return False, f"theta = 0.5: median {np.median(e):.1e}, max {e.max():.1e} (expected ~5e-4 / 3e-3)"
    return bool(counts[0] < counts[1] < counts[2]), "smaller theta means more interactions"


check("9.1 operators on a hand-checkable example", t_known_values)
check("9.1 P2M / M2P: multipole error bound, c_0 and c_1", t_multipole)
check("9.1 M2M reproduces P2M about the new centre", t_m2m)
check("9.1 M2L between well-separated boxes", t_m2l)
check("9.1 L2L is exact", t_l2l)
check("9.2 interaction lists partition the far field", t_lists)
check("9.3 FMM vs direct sum (levels 2, 3, 4)", t_fmm_uniform)
check("9.3 empty boxes, clusters, particles on box edges", t_fmm_edge)
check("9.3 linearity and two-body limit", t_fmm_linear)
check("9.3 N = 20000 speed and accuracy", t_fmm_speed)
check("9.4 Barnes-Hut in complex form vs direct", t_bh)

print(f"\n{sum(results)}/{len(results)} checks passed")
sys.exit(0 if all(results) else 1)
