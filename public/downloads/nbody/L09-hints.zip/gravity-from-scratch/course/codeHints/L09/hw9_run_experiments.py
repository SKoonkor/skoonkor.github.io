"""Scaffold for the HW9 experiments (plotting only). Copy next to your fmm2d.py; fill in the TODOs."""
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.append(str(Path(__file__).resolve().parent))
import fmm2d as F  # noqa: E402


def random_particles(N, seed=0):
    rng = np.random.default_rng(seed)
    return rng.random(N) + 1j * rng.random(N), rng.random(N) + 0.5


def direct_field(z, q):
    """O(N^2) reference in chunks of rows (memory!)."""
    # TODO
    raise NotImplementedError


def scaled_error(f, f_exact, z, q):
    """|f - f_exact| divided by sum_j |q_j / (z_i - z_j)| for every particle."""
    # TODO
    raise NotImplementedError


def error_vs_p():
    # TODO: N = 4000, levels = 4, p = 2..20: median / 90% / max of scaled_error
    raise NotImplementedError


def cost_vs_levels():
    # TODO: N = 8000, p = 8, levels = 2..7: near-field pair count, M2L count * p^2 + 2 N p, run time
    raise NotImplementedError


def scaling():
    # TODO: N = 500 .. 64000, levels ~ log4(N / 25): time of direct sum, bh_field, fmm_field
    raise NotImplementedError


if __name__ == "__main__":
    t = time.time()
    # TODO: call the functions above
    print(f"done in {time.time() - t:.1f} s")
