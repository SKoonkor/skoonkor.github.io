"""Reference solution, Lecture 6: particle-mesh gravity in a periodic cube (grid nodes at i*h)."""
import numpy as np


def _stencil(u, scheme):
    """1D stencil for positions u (in units of h): list of (node index array, weight array)."""
    if scheme == "ngp":
        return [(np.rint(u).astype(int), np.ones_like(u))]
    if scheme == "cic":
        i0 = np.floor(u).astype(int)
        d = u - i0
        return [(i0, 1 - d), (i0 + 1, d)]
    if scheme == "tsc":
        i0 = np.rint(u).astype(int)
        d = u - i0
        return [(i0 - 1, 0.5 * (0.5 - d) ** 2), (i0, 0.75 - d**2), (i0 + 1, 0.5 * (0.5 + d) ** 2)]
    raise ValueError(scheme)


def _cells(pos, box, ngrid, scheme):
    """Yield (flat node index, weight) arrays for every stencil point of every particle."""
    u = (np.asarray(pos) % box) / (box / ngrid)
    sx, sy, sz = (_stencil(u[:, k], scheme) for k in range(3))
    for ix, wx in sx:
        for iy, wy in sy:
            for iz, wz in sz:
                flat = ((ix % ngrid) * ngrid + (iy % ngrid)) * ngrid + (iz % ngrid)
                yield flat, wx * wy * wz


def assign_density(pos, mass, ngrid, box, scheme="cic"):
    rho = np.zeros(ngrid**3)
    for flat, w in _cells(pos, box, ngrid, scheme):
        rho += np.bincount(flat, weights=mass * w, minlength=ngrid**3)
    return rho.reshape(ngrid, ngrid, ngrid) / (box / ngrid) ** 3


def _kvectors(ngrid, box):
    k1 = 2 * np.pi * np.fft.fftfreq(ngrid, d=box / ngrid)
    return np.meshgrid(k1, k1, k1, indexing="ij")


def solve_potential(rho, box, G=1.0, kernel="spectral"):
    n = rho.shape[0]
    h = box / n
    kx, ky, kz = _kvectors(n, box)
    if kernel == "spectral":
        k2 = kx**2 + ky**2 + kz**2
    else:
        k2 = sum((2 / h * np.sin(k * h / 2)) ** 2 for k in (kx, ky, kz))
    k2[0, 0, 0] = 1.0
    phik = -4 * np.pi * G * np.fft.fftn(rho) / k2
    phik[0, 0, 0] = 0.0
    return np.real(np.fft.ifftn(phik))


def grid_force(phi, box, method="spectral"):
    n = phi.shape[0]
    h = box / n
    if method == "spectral":
        phik = np.fft.fftn(phi)
        out = []
        for k in _kvectors(n, box):
            kk = k.copy()
            if n % 2 == 0:
                kk[np.abs(np.abs(k) - np.pi / h) < 1e-9] = 0.0        # drop the Nyquist mode
            out.append(np.real(np.fft.ifftn(-1j * kk * phik)))
        return np.array(out)
    a = []
    for ax in range(3):
        d = (8 * (np.roll(phi, -1, ax) - np.roll(phi, 1, ax)) - (np.roll(phi, -2, ax) - np.roll(phi, 2, ax))) / (12 * h)
        a.append(-d)
    return np.array(a)


def interpolate(field, pos, box, scheme="cic"):
    """field (n,n,n) -> values (N,);  field (3,n,n,n) -> values (N,3). Same kernel as assign_density."""
    vec = field.ndim == 4
    n = field.shape[-1]
    flat_field = field.reshape(3, -1) if vec else field.reshape(1, -1)
    out = np.zeros((flat_field.shape[0], len(pos)))
    for flat, w in _cells(pos, box, n, scheme):
        out += flat_field[:, flat] * w
    return out.T if vec else out[0]


def pm_acceleration(pos, mass, G=1.0, eps=0.0, box=1.0, ngrid=32, scheme="cic", deriv="fd4", kernel="spectral"):
    """eps is ignored: the grid softens the force (kept so this matches force(pos, mass, G, eps))."""
    rho = assign_density(pos, mass, ngrid, box, scheme)
    phi = solve_potential(rho, box, G, kernel)
    return interpolate(grid_force(phi, box, deriv), pos, box, scheme)
